package client.manager;

import client.Client;
import client.events.DeathEvent;
import client.events.PacketEvent;
import client.modules.Feature;
import client.util.MathUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketUseEntity.Action;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class PacketManager extends Feature {
   private final List noEventPackets = new ArrayList();
   public final ConcurrentHashMap targets = new ConcurrentHashMap();
   private double totalDeaths;
   private double totalKills;
   private int currentKills;

   public void sendPacketNoEvent(Packet packet) {
      if (packet != null && !nullCheck()) {
         this.noEventPackets.add(packet);
         mc.field_71439_g.field_71174_a.func_147297_a(packet);
      }

   }

   public boolean shouldSendPacket(Packet packet) {
      if (this.noEventPackets.contains(packet)) {
         this.noEventPackets.remove(packet);
         return false;
      } else {
         return true;
      }
   }

   public int getCurrentKills() {
      return this.currentKills;
   }

   public String getKD() {
      return this.totalDeaths == 0.0D ? "" + this.totalKills : "" + MathUtil.round(this.totalKills / this.totalDeaths, 2);
   }

   public String getTotalKills() {
      return "" + this.totalKills;
   }

   public String getTotalDeaths() {
      return "" + this.totalDeaths;
   }

   public void addDeath() {
      ++this.totalDeaths;
      this.currentKills = 0;
   }

   public void onUpdate() {
      this.targets.forEach((name, timeout) -> {
         if (timeout.intValue() <= 0) {
            this.targets.remove(name);
         } else {
            this.targets.put(name, timeout.intValue() - 1);
         }

      });
   }

   @SubscribeEvent
   public void onAttackEntity(AttackEntityEvent event) {
      if (event.getTarget() instanceof EntityPlayer && !Client.friendManager.isFriend(event.getEntityPlayer().func_70005_c_())) {
         this.targets.put(event.getTarget().func_70005_c_(), Integer.valueOf(20));
      }

   }

   @SubscribeEvent
   public void onSendAttackPacket(PacketEvent.Send event) {
      CPacketUseEntity packet;
      if (event.getPacket() instanceof CPacketUseEntity && (packet = (CPacketUseEntity)event.getPacket()).func_149565_c() == Action.ATTACK && packet.func_149564_a(mc.field_71441_e) instanceof EntityPlayer && !Client.friendManager.isFriend(((Entity)Objects.requireNonNull(packet.func_149564_a(mc.field_71441_e))).func_70005_c_())) {
         this.targets.put(((Entity)Objects.requireNonNull(packet.func_149564_a(mc.field_71441_e))).func_70005_c_(), Integer.valueOf(20));
      }

   }

   @SubscribeEvent
   public void onEntityDeath(DeathEvent event) {
      if (this.targets.containsKey(event.player.func_70005_c_())) {
         ++this.totalKills;
         ++this.currentKills;
         this.targets.remove(event.player.func_70005_c_());
      }

   }
}
