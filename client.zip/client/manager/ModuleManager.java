package client.manager;

import client.events.Render2DEvent;
import client.events.Render3DEvent;
import client.gui.ClientGui;
import client.gui.impl.background.MenuToggler;
import client.modules.Feature;
import client.modules.Module;
import client.modules.client.ClickGui;
import client.modules.client.FontMod;
import client.modules.client.Hud;
import client.modules.client.Notify;
import client.modules.client.RPC;
import client.modules.combat.AntiCity;
import client.modules.combat.Aura;
import client.modules.combat.AutoArmor;
import client.modules.combat.AutoCrystal;
import client.modules.combat.AutoTrap;
import client.modules.combat.AutoWeb;
import client.modules.combat.Criticals;
import client.modules.combat.Flatten;
import client.modules.combat.Holefiller;
import client.modules.combat.Offhand;
import client.modules.combat.PistonAura;
import client.modules.combat.Surround;
import client.modules.miscellaneous.AutoRespawn;
import client.modules.miscellaneous.ChatModifications;
import client.modules.miscellaneous.ChorusPredict;
import client.modules.miscellaneous.FakePlayer;
import client.modules.miscellaneous.MCFriends;
import client.modules.miscellaneous.MiddleClickPearl;
import client.modules.miscellaneous.NoEntityTrace;
import client.modules.miscellaneous.PingSpoofer;
import client.modules.miscellaneous.Spammer;
import client.modules.miscellaneous.TabTweaks;
import client.modules.miscellaneous.TotemPopCounter;
import client.modules.movement.ElytraFlight;
import client.modules.movement.FastSwim;
import client.modules.movement.Jesus;
import client.modules.movement.NoFall;
import client.modules.movement.NoSlow;
import client.modules.movement.Phase;
import client.modules.movement.ReverseStep;
import client.modules.movement.Sprint;
import client.modules.movement.Step;
import client.modules.movement.Strafe;
import client.modules.movement.Velocity;
import client.modules.movement.YPort;
import client.modules.player.AntiRotate;
import client.modules.player.AutoEnderChest;
import client.modules.player.Blink;
import client.modules.player.Burrow;
import client.modules.player.FastPlace;
import client.modules.player.Freecam;
import client.modules.player.HotbarRefill;
import client.modules.player.Interactions;
import client.modules.player.KeyEXP;
import client.modules.player.Quiver;
import client.modules.player.Speedmine;
import client.modules.visual.AntiFog;
import client.modules.visual.BurrowESP;
import client.modules.visual.CityESP;
import client.modules.visual.CrystalChanger;
import client.modules.visual.ESP;
import client.modules.visual.FullBright;
import client.modules.visual.NameTags;
import client.modules.visual.PearlRender;
import client.modules.visual.PrestigeChams;
import client.modules.visual.ShulkerViewer;
import client.modules.visual.SwingAnimations;
import client.modules.visual.ThirdPerson;
import client.modules.visual.Viewmodel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import org.lwjgl.input.Keyboard;

public class ModuleManager extends Feature {
   public ArrayList modules = new ArrayList();
   public List sortedModules = new ArrayList();

   public void init() {
      this.modules.add(new ClickGui());
      this.modules.add(new FontMod());
      this.modules.add(new Hud());
      this.modules.add(new Notify());
      this.modules.add(new RPC());
      this.modules.add(new MenuToggler());
      this.modules.add(new AutoArmor());
      this.modules.add(new Holefiller());
      this.modules.add(new Offhand());
      this.modules.add(new Surround());
      this.modules.add(new AutoWeb());
      this.modules.add(new Flatten());
      this.modules.add(new AutoCrystal());
      this.modules.add(new PistonAura());
      this.modules.add(new AutoTrap());
      this.modules.add(new Aura());
      this.modules.add(new Criticals());
      this.modules.add(new AntiCity());
      this.modules.add(new FakePlayer());
      this.modules.add(new AutoRespawn());
      this.modules.add(new NoEntityTrace());
      this.modules.add(new MCFriends());
      this.modules.add(new Spammer());
      this.modules.add(new TotemPopCounter());
      this.modules.add(new ChatModifications());
      this.modules.add(new PingSpoofer());
      this.modules.add(new TabTweaks());
      this.modules.add(new MiddleClickPearl());
      this.modules.add(new ChorusPredict());
      this.modules.add(new ReverseStep());
      this.modules.add(new Sprint());
      this.modules.add(new YPort());
      this.modules.add(new Step());
      this.modules.add(new Phase());
      this.modules.add(new Velocity());
      this.modules.add(new NoSlow());
      this.modules.add(new ElytraFlight());
      this.modules.add(new Jesus());
      this.modules.add(new Strafe());
      this.modules.add(new NoFall());
      this.modules.add(new FastSwim());
      this.modules.add(new KeyEXP());
      this.modules.add(new Burrow());
      this.modules.add(new FastPlace());
      this.modules.add(new HotbarRefill());
      this.modules.add(new Quiver());
      this.modules.add(new Speedmine());
      this.modules.add(new AutoEnderChest());
      this.modules.add(new Interactions());
      this.modules.add(new Freecam());
      this.modules.add(new AntiRotate());
      this.modules.add(new Blink());
      this.modules.add(new CrystalChanger());
      this.modules.add(new FullBright());
      this.modules.add(new BurrowESP());
      this.modules.add(new ThirdPerson());
      this.modules.add(new Viewmodel());
      this.modules.add(new AntiFog());
      this.modules.add(new SwingAnimations());
      this.modules.add(new ShulkerViewer());
      this.modules.add(new PearlRender());
      this.modules.add(new PrestigeChams());
      this.modules.add(new NameTags());
      this.modules.add(new CityESP());
      this.modules.add(new ESP());
   }

   public Module getModuleByName(String name) {
      Iterator var2 = this.modules.iterator();

      Module module;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         module = (Module)var2.next();
      } while(!module.getName().equalsIgnoreCase(name));

      return module;
   }

   public Module getModuleByClass(Class clazz) {
      Iterator var2 = this.modules.iterator();

      Module module;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         module = (Module)var2.next();
      } while(!clazz.isInstance(module));

      return module;
   }

   public boolean isModuleEnabled(String name) {
      Module module = this.getModuleByName(name);
      return module != null && module.isOn();
   }

   public Module getModuleByDisplayName(String displayName) {
      Iterator var2 = this.modules.iterator();

      Module module;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         module = (Module)var2.next();
      } while(!module.getDisplayName().equalsIgnoreCase(displayName));

      return module;
   }

   public ArrayList getEnabledModules() {
      ArrayList enabledModules = new ArrayList();
      Iterator var2 = this.modules.iterator();

      while(var2.hasNext()) {
         Module module = (Module)var2.next();
         if (module.isEnabled()) {
            enabledModules.add(module);
         }
      }

      return enabledModules;
   }

   public ArrayList getModulesByCategory(Module.Category category) {
      ArrayList modulesCategory = new ArrayList();
      this.modules.forEach((module) -> {
         if (module.getCategory() == category) {
            modulesCategory.add(module);
         }

      });
      return modulesCategory;
   }

   public List getCategories() {
      return Arrays.asList(Module.Category.values());
   }

   public void onLoad() {
      this.modules.forEach(Module::onLoad);
   }

   public void onUpdate() {
      this.modules.stream().filter(Feature::isEnabled).forEach(Module::onUpdate);
   }

   public void onTick() {
      this.modules.stream().filter(Feature::isEnabled).forEach(Module::onTick);
   }

   public void onRender2D(Render2DEvent event) {
      this.modules.stream().filter(Feature::isEnabled).forEach((module) -> {
         module.onRender2D(event);
      });
   }

   public void onRender3D(Render3DEvent event) {
      this.modules.stream().filter(Feature::isEnabled).forEach((module) -> {
         module.onRender3D(event);
      });
   }

   public void sortModules(boolean reverse) {
      this.sortedModules = (List)this.getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing((module) -> {
         return this.renderer.getStringWidth(module.getFullArrayString()) * (reverse ? -1 : 1);
      })).collect(Collectors.toList());
   }

   public void onLogout() {
      this.modules.forEach(Module::onLogout);
   }

   public void onLogin() {
      this.modules.forEach(Module::onLogin);
      if (Strafe.getInstance().isEnabled()) {
         Strafe.getInstance().disable();
         Strafe.getInstance().enable();
      }

   }

   public void onUnload() {
      ArrayList var10000 = this.modules;
      EventBus var10001 = MinecraftForge.EVENT_BUS;
      MinecraftForge.EVENT_BUS.getClass();
      var10000.forEach(var10001::unregister);
      this.modules.forEach(Module::onUnload);
   }

   public void onUnloadPost() {
      Iterator var1 = this.modules.iterator();

      while(var1.hasNext()) {
         Module module = (Module)var1.next();
         module.enabled.setValue(false);
      }

   }

   public void onKeyPressed(int eventKey) {
      if (eventKey != 0 && Keyboard.getEventKeyState() && !(mc.field_71462_r instanceof ClientGui)) {
         this.modules.forEach((module) -> {
            if (module.getBind().getKey() == eventKey) {
               module.toggle();
            }

         });
      }
   }
}
