package client.util;

import client.modules.client.ClickGui;
import client.modules.client.Hud;
import java.awt.Color;
import org.lwjgl.opengl.GL11;

public class ColorUtil {
   private float hue;

   public static int toARGB(int r, int g, int b, int a) {
      return (new Color(r, g, b, a)).getRGB();
   }

   public static int toRGBA(int r, int g, int b) {
      return toRGBA(r, g, b, 255);
   }

   public static int toRGBA(int r, int g, int b, int a) {
      return (r << 16) + (g << 8) + b + (a << 24);
   }

   public static Color rainbow(int delay) {
      double rainbowState = Math.ceil((double)(System.currentTimeMillis() + (long)delay) / 20.0D);
      return Color.getHSBColor((float)(rainbowState % 360.0D / 360.0D), ((Float)ClickGui.getInstance().rainbowSaturation.getCurrentState()).floatValue() / 255.0F, ((Float)ClickGui.getInstance().rainbowBrightness.getCurrentState()).floatValue() / 255.0F);
   }

   public static Color rainbowHighDelay(int delay) {
      double rainbowState = Math.ceil((double)(System.currentTimeMillis() + (long)delay * 100L) / 20.0D);
      return Color.getHSBColor((float)(rainbowState % 360.0D / 360.0D), ((Float)ClickGui.getInstance().rainbowSaturation.getCurrentState()).floatValue() / 255.0F, ((Float)ClickGui.getInstance().rainbowBrightness.getCurrentState()).floatValue() / 255.0F);
   }

   public static Color rainbowHud(int delay) {
      double rainbowState = Math.ceil((double)(System.currentTimeMillis() + (long)delay) / 20.0D);
      return Color.getHSBColor((float)(rainbowState % 360.0D / 360.0D), ((Float)Hud.getInstance().rainbowSaturation.getCurrentState()).floatValue() / 255.0F, ((Float)Hud.getInstance().rainbowBrightness.getCurrentState()).floatValue() / 255.0F);
   }

   public static int toRGBA(Color color) {
      return toRGBA(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
   }

   public static int getRainbow(int speed, int offset, float s, float b) {
      float hue = (float)((System.currentTimeMillis() + (long)offset) % (long)speed);
      return Color.getHSBColor(hue / (float)speed, s, b).getRGB();
   }

   public static void setColor(Color color) {
      GL11.glColor4d((double)((float)color.getRed() / 255.0F), (double)((float)color.getGreen() / 255.0F), (double)((float)color.getBlue() / 255.0F), (double)((float)color.getAlpha() / 255.0F));
   }
}
