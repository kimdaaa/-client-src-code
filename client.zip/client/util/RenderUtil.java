package client.util;

import client.Client;
import java.awt.Color;
import java.util.Objects;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public class RenderUtil implements Util {
   public static Tessellator tessellator;
   public static RenderItem itemRender;
   public static ICamera camera;

   public static void drawFilledBox(AxisAlignedBB bb, int color) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      float alpha = (float)(color >> 24 & 255) / 255.0F;
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static AxisAlignedBB interpolateAxis(AxisAlignedBB bb) {
      return new AxisAlignedBB(bb.field_72340_a - mc.func_175598_ae().field_78730_l, bb.field_72338_b - mc.func_175598_ae().field_78731_m, bb.field_72339_c - mc.func_175598_ae().field_78728_n, bb.field_72336_d - mc.func_175598_ae().field_78730_l, bb.field_72337_e - mc.func_175598_ae().field_78731_m, bb.field_72334_f - mc.func_175598_ae().field_78728_n);
   }

   public static double interpolate(double previous, double current, float partialTicks) {
      return previous + (current - previous) * (double)partialTicks;
   }

   public static void drawTexturedRect(int x, int y, int textureX, int textureY, int width, int height, int zLevel) {
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder BufferBuilder2 = tessellator.func_178180_c();
      BufferBuilder2.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      BufferBuilder2.func_181662_b((double)x, (double)(y + height), (double)zLevel).func_187315_a((double)((float)textureX * 0.00390625F), (double)((float)(textureY + height) * 0.00390625F)).func_181675_d();
      BufferBuilder2.func_181662_b((double)(x + width), (double)(y + height), (double)zLevel).func_187315_a((double)((float)(textureX + width) * 0.00390625F), (double)((float)(textureY + height) * 0.00390625F)).func_181675_d();
      BufferBuilder2.func_181662_b((double)(x + width), (double)y, (double)zLevel).func_187315_a((double)((float)(textureX + width) * 0.00390625F), (double)((float)textureY * 0.00390625F)).func_181675_d();
      BufferBuilder2.func_181662_b((double)x, (double)y, (double)zLevel).func_187315_a((double)((float)textureX * 0.00390625F), (double)((float)textureY * 0.00390625F)).func_181675_d();
      tessellator.func_78381_a();
   }

   public static void drawRoundedRect(double x, double y, double width, double height, double radius, Color color) {
      GL11.glPushAttrib(0);
      GL11.glScaled(0.5D, 0.5D, 0.5D);
      x *= 2.0D;
      y *= 2.0D;
      width *= 2.0D;
      height *= 2.0D;
      width += x;
      height += y;
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glColor4f((float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
      GL11.glEnable(2848);
      GL11.glBegin(9);

      int i;
      for(i = 0; i <= 90; ++i) {
         GL11.glVertex2d(x + radius + Math.sin((double)i * 3.141592653589793D / 180.0D) * radius * -1.0D, y + radius + Math.cos((double)i * 3.141592653589793D / 180.0D) * radius * -1.0D);
      }

      for(i = 90; i <= 180; ++i) {
         GL11.glVertex2d(x + radius + Math.sin((double)i * 3.141592653589793D / 180.0D) * radius * -1.0D, height - radius + Math.cos((double)i * 3.141592653589793D / 180.0D) * radius * -1.0D);
      }

      for(i = 0; i <= 90; ++i) {
         GL11.glVertex2d(width - radius + Math.sin((double)i * 3.141592653589793D / 180.0D) * radius, height - radius + Math.cos((double)i * 3.141592653589793D / 180.0D) * radius);
      }

      for(i = 90; i <= 180; ++i) {
         GL11.glVertex2d(width - radius + Math.sin((double)i * 3.141592653589793D / 180.0D) * radius, y + radius + Math.cos((double)i * 3.141592653589793D / 180.0D) * radius);
      }

      GL11.glEnd();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glDisable(3042);
      GL11.glEnable(3553);
      GL11.glScaled(2.0D, 2.0D, 2.0D);
      GL11.glPopAttrib();
   }

   public static void drawBottomRoundedRect(double x, double y, double width, double height, double radius, Color color) {
      GL11.glPushAttrib(0);
      GL11.glScaled(0.5D, 0.5D, 0.5D);
      x *= 2.0D;
      y *= 2.0D;
      width *= 2.0D;
      height *= 2.0D;
      width += x;
      height += y;
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glColor4f((float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
      GL11.glEnable(2848);
      GL11.glBegin(9);

      int i;
      for(i = 90; i <= 180; ++i) {
         GL11.glVertex2d(x + radius + Math.sin((double)i * 3.141592653589793D / 180.0D) * radius * -1.0D, height - radius + Math.cos((double)i * 3.141592653589793D / 180.0D) * radius * -1.0D);
      }

      for(i = 0; i <= 90; ++i) {
         GL11.glVertex2d(width - radius + Math.sin((double)i * 3.141592653589793D / 180.0D) * radius, height - radius + Math.cos((double)i * 3.141592653589793D / 180.0D) * radius);
      }

      GL11.glEnd();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glDisable(3042);
      GL11.glEnable(3553);
      GL11.glScaled(2.0D, 2.0D, 2.0D);
      GL11.glPopAttrib();
   }

   public static void drawTopRoundedRect(double x, double y, double width, double height, double radius, Color color) {
      GL11.glPushAttrib(0);
      GL11.glScaled(0.5D, 0.5D, 0.5D);
      x *= 2.0D;
      y *= 2.0D;
      width *= 2.0D;
      height *= 2.0D;
      width += x;
      height += y;
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glColor4f((float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
      GL11.glEnable(2848);
      GL11.glBegin(9);

      int i;
      for(i = 0; i <= 90; ++i) {
         GL11.glVertex2d(x + radius + Math.sin((double)i * 3.141592653589793D / 180.0D) * radius * -1.0D, y + radius + Math.cos((double)i * 3.141592653589793D / 180.0D) * radius * -1.0D);
      }

      for(i = 90; i <= 180; ++i) {
         GL11.glVertex2d(x + 1.0D + Math.sin((double)i * 3.141592653589793D / 180.0D) * -1.0D, height - 1.0D + Math.cos((double)i * 3.141592653589793D / 180.0D) * -1.0D);
      }

      for(i = 0; i <= 90; ++i) {
         GL11.glVertex2d(width - 1.0D + Math.sin((double)i * 3.141592653589793D / 180.0D), height - 1.0D + Math.cos((double)i * 3.141592653589793D / 180.0D));
      }

      for(i = 90; i <= 180; ++i) {
         GL11.glVertex2d(width - radius + Math.sin((double)i * 3.141592653589793D / 180.0D) * radius, y + radius + Math.cos((double)i * 3.141592653589793D / 180.0D) * radius);
      }

      GL11.glEnd();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glDisable(3042);
      GL11.glEnable(3553);
      GL11.glScaled(2.0D, 2.0D, 2.0D);
      GL11.glPopAttrib();
   }

   public static void drawClawBox(BlockPos blockPos, double height, double length, double width, Color color) {
      BufferBuilder buffer = tessellator.func_178180_c();
      buffer.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      addChainedClawBoxVertices(buffer, (double)blockPos.func_177958_n(), (double)blockPos.func_177956_o(), (double)blockPos.func_177952_p(), (double)blockPos.func_177958_n() + length, (double)blockPos.func_177956_o() + height, (double)blockPos.func_177952_p() + width, color);
      tessellator.func_78381_a();
   }

   public static void addChainedClawBoxVertices(BufferBuilder buffer, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, Color color) {
      buffer.func_181662_b(minX, minY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(minX, minY, maxZ - 0.8D).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(minX, minY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(minX, minY, minZ + 0.8D).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(maxX, minY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(maxX, minY, maxZ - 0.8D).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(maxX, minY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(maxX, minY, minZ + 0.8D).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(minX, minY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(maxX - 0.8D, minY, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(minX, minY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(maxX - 0.8D, minY, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(maxX, minY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(minX + 0.8D, minY, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(maxX, minY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(minX + 0.8D, minY, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(minX, minY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(minX, minY + 0.2D, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(minX, minY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(minX, minY + 0.2D, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(maxX, minY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(maxX, minY + 0.2D, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(maxX, minY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(maxX, minY + 0.2D, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(minX, maxY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(minX, maxY, maxZ - 0.8D).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(minX, maxY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(minX, maxY, minZ + 0.8D).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(maxX, maxY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(maxX, maxY, maxZ - 0.8D).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(maxX, maxY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(maxX, maxY, minZ + 0.8D).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(minX, maxY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(maxX - 0.8D, maxY, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(minX, maxY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(maxX - 0.8D, maxY, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(maxX, maxY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(minX + 0.8D, maxY, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(maxX, maxY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(minX + 0.8D, maxY, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(minX, maxY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(minX, maxY - 0.2D, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(minX, maxY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(minX, maxY - 0.2D, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(maxX, maxY, minZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(maxX, maxY - 0.2D, minZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
      buffer.func_181662_b(maxX, maxY, maxZ).func_181666_a((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), 0.0F).func_181675_d();
      buffer.func_181662_b(maxX, maxY - 0.2D, maxZ).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).func_181675_d();
   }

   public static void drawRoundedRect(int x, int y, int width, int height, int color, int radius) {
      drawRect((float)x, (float)(y + radius), (float)(x + width), (float)(y + height - radius), color);
      drawRect((float)(x + radius), (float)y, (float)(x + width - radius), (float)(y + radius), color);
      drawRect((float)(x + radius), (float)(y + height - radius), (float)(x + width - radius), (float)(y + height), color);
      drawFilledCircle(x + radius, y + radius, (double)radius, color);
      drawFilledCircle(x + width - radius, y + radius, (double)radius, color);
      drawFilledCircle(x + radius, y + height - radius, (double)radius, color);
      drawFilledCircle(x + width - radius, y + height - radius, (double)radius, color);
   }

   public static void drawFilledCircle(int x, int y, double radius, int color) {
      GL11.glDisable(3042);
      GL11.glDisable(3008);
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glColor4f((float)(color >> 16 & 255) / 255.0F, (float)(color >> 8 & 255) / 255.0F, (float)(color & 255) / 255.0F, (float)(color >> 24 & 255) / 255.0F);
      GL11.glBegin(6);

      for(int i = 0; i <= 360; ++i) {
         GL11.glVertex2d((double)x + Math.sin((double)i * 3.141592653589793D / 180.0D) * radius, (double)y + Math.cos((double)i * 3.141592653589793D / 180.0D) * radius);
      }

      glEnd();
      GL11.glDisable(2848);
      GL11.glEnable(3553);
      GL11.glDisable(3042);
   }

   public static void drawLine(float x, float y, float x1, float y1, float thickness, int hex) {
      float red = (float)(hex >> 16 & 255) / 255.0F;
      float green = (float)(hex >> 8 & 255) / 255.0F;
      float blue = (float)(hex & 255) / 255.0F;
      float alpha = (float)(hex >> 24 & 255) / 255.0F;
      GlStateManager.func_179094_E();
      GlStateManager.func_179090_x();
      GlStateManager.func_179147_l();
      GlStateManager.func_179118_c();
      GlStateManager.func_179120_a(770, 771, 1, 0);
      GlStateManager.func_179103_j(7425);
      GL11.glLineWidth(thickness);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b((double)x, (double)y, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b((double)x1, (double)y1, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179103_j(7424);
      GL11.glDisable(2848);
      GlStateManager.func_179084_k();
      GlStateManager.func_179141_d();
      GlStateManager.func_179098_w();
      GlStateManager.func_179121_F();
   }

   public static void drawBlockOutline(AxisAlignedBB bb, Color color, float linewidth) {
      float red = (float)color.getRed() / 255.0F;
      float green = (float)color.getGreen() / 255.0F;
      float blue = (float)color.getBlue() / 255.0F;
      float alpha = (float)color.getAlpha() / 255.0F;
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(linewidth);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void setColor(Color color) {
      GL11.glColor4d((double)color.getRed() / 255.0D, (double)color.getGreen() / 255.0D, (double)color.getBlue() / 255.0D, (double)color.getAlpha() / 255.0D);
   }

   public static void drawText(BlockPos pos, String text) {
      GlStateManager.func_179094_E();
      glBillboardDistanceScaled((float)pos.func_177958_n() + 0.5F, (float)pos.func_177956_o() + 0.5F, (float)pos.func_177952_p() + 0.5F, mc.field_71439_g, 1.0F);
      GlStateManager.func_179097_i();
      GlStateManager.func_179137_b(-((double)Client.textManager.getStringWidth(text) / 2.0D), 0.0D, 0.0D);
      Client.textManager.drawStringWithShadow(text, 0.0F, 0.0F, -5592406);
      GlStateManager.func_179121_F();
   }

   public static void drawRect(float x, float y, float w, float h, int color) {
      float alpha = (float)(color >> 24 & 255) / 255.0F;
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      GlStateManager.func_179147_l();
      GlStateManager.func_179090_x();
      GlStateManager.func_179120_a(770, 771, 1, 0);
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b((double)x, (double)h, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b((double)w, (double)h, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b((double)w, (double)y, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b((double)x, (double)y, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
   }

   public static void glEnd() {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glPopMatrix();
      GL11.glEnable(2929);
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
   }

   public static void drawBox(BlockPos pos, Color color) {
      AxisAlignedBB bb = new AxisAlignedBB((double)pos.func_177958_n() - mc.func_175598_ae().field_78730_l, (double)pos.func_177956_o() - mc.func_175598_ae().field_78731_m, (double)pos.func_177952_p() - mc.func_175598_ae().field_78728_n, (double)(pos.func_177958_n() + 1) - mc.func_175598_ae().field_78730_l, (double)(pos.func_177956_o() + 1) - mc.func_175598_ae().field_78731_m, (double)(pos.func_177952_p() + 1) - mc.func_175598_ae().field_78728_n);
      camera.func_78547_a(((Entity)Objects.requireNonNull(mc.func_175606_aa())).field_70165_t, mc.func_175606_aa().field_70163_u, mc.func_175606_aa().field_70161_v);
      if (camera.func_78546_a(new AxisAlignedBB(bb.field_72340_a + mc.func_175598_ae().field_78730_l, bb.field_72338_b + mc.func_175598_ae().field_78731_m, bb.field_72339_c + mc.func_175598_ae().field_78728_n, bb.field_72336_d + mc.func_175598_ae().field_78730_l, bb.field_72337_e + mc.func_175598_ae().field_78731_m, bb.field_72334_f + mc.func_175598_ae().field_78728_n))) {
         GlStateManager.func_179094_E();
         GlStateManager.func_179147_l();
         GlStateManager.func_179097_i();
         GlStateManager.func_179120_a(770, 771, 0, 1);
         GlStateManager.func_179090_x();
         GlStateManager.func_179132_a(false);
         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
         RenderGlobal.func_189696_b(bb, (float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
         GL11.glDisable(2848);
         GlStateManager.func_179132_a(true);
         GlStateManager.func_179126_j();
         GlStateManager.func_179098_w();
         GlStateManager.func_179084_k();
         GlStateManager.func_179121_F();
      }

   }

   public static void drawBlockOutline(BlockPos pos, Color color, float linewidth, boolean air) {
      IBlockState iblockstate = mc.field_71441_e.func_180495_p(pos);
      if ((air || iblockstate.func_185904_a() != Material.field_151579_a) && mc.field_71441_e.func_175723_af().func_177746_a(pos)) {
         Vec3d interp = EntityUtil.interpolateEntity(mc.field_71439_g, mc.func_184121_ak());
         drawBlockOutline(iblockstate.func_185918_c(mc.field_71441_e, pos).func_186662_g(0.0020000000949949026D).func_72317_d(-interp.field_72450_a, -interp.field_72448_b, -interp.field_72449_c), color, linewidth);
      }

   }

   public static void drawBoxESP(BlockPos pos, Color color, boolean secondC, Color secondColor, float lineWidth, boolean outline, boolean box, int boxAlpha, boolean air) {
      if (box) {
         drawBox(pos, new Color(color.getRed(), color.getGreen(), color.getBlue(), boxAlpha));
      }

      if (outline) {
         drawBlockOutline(pos, secondC ? secondColor : color, lineWidth, air);
      }

   }

   public static void drawPerryESP(AxisAlignedBB a, Color boxColor, Color outlineColor, float lineWidth, boolean outline, boolean box, float alpha, float scale, float slab) {
      double f = 0.5D * (double)(1.0F - scale);
      AxisAlignedBB bb = interpolateAxis(new AxisAlignedBB(a.field_72340_a + f, a.field_72338_b + f + (double)(1.0F - slab), a.field_72339_c + f, a.field_72336_d - f, a.field_72337_e - f, a.field_72334_f - f));
      float rB = (float)boxColor.getRed() / 255.0F;
      float gB = (float)boxColor.getGreen() / 255.0F;
      float bB = (float)boxColor.getBlue() / 255.0F;
      float aB = (float)boxColor.getAlpha() / 255.0F;
      float rO = (float)outlineColor.getRed() / 255.0F;
      float gO = (float)outlineColor.getGreen() / 255.0F;
      float bO = (float)outlineColor.getBlue() / 255.0F;
      float aO = (float)outlineColor.getAlpha() / 255.0F;
      if (alpha > 1.0F) {
         alpha = 1.0F;
      }

      aB *= alpha;
      aO *= alpha;
      if (box) {
         GlStateManager.func_179094_E();
         GlStateManager.func_179147_l();
         GlStateManager.func_179097_i();
         GlStateManager.func_179120_a(770, 771, 0, 1);
         GlStateManager.func_179090_x();
         GlStateManager.func_179132_a(false);
         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
         RenderGlobal.func_189696_b(bb, rB, gB, bB, aB);
         GL11.glDisable(2848);
         GlStateManager.func_179132_a(true);
         GlStateManager.func_179126_j();
         GlStateManager.func_179098_w();
         GlStateManager.func_179084_k();
         GlStateManager.func_179121_F();
      }

      if (outline) {
         GlStateManager.func_179094_E();
         GlStateManager.func_179147_l();
         GlStateManager.func_179097_i();
         GlStateManager.func_179120_a(770, 771, 0, 1);
         GlStateManager.func_179090_x();
         GlStateManager.func_179132_a(false);
         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
         GL11.glLineWidth(lineWidth);
         Tessellator tessellator = Tessellator.func_178181_a();
         BufferBuilder bufferbuilder = tessellator.func_178180_c();
         bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
         bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
         bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(rO, gO, bO, aO).func_181675_d();
         tessellator.func_78381_a();
         GL11.glDisable(2848);
         GlStateManager.func_179132_a(true);
         GlStateManager.func_179126_j();
         GlStateManager.func_179098_w();
         GlStateManager.func_179084_k();
         GlStateManager.func_179121_F();
      }

   }

   public static void glBillboard(float x, float y, float z) {
      float scale = 0.02666667F;
      GlStateManager.func_179137_b((double)x - mc.func_175598_ae().field_78725_b, (double)y - mc.func_175598_ae().field_78726_c, (double)z - mc.func_175598_ae().field_78723_d);
      GlStateManager.func_187432_a(0.0F, 1.0F, 0.0F);
      GlStateManager.func_179114_b(-mc.field_71439_g.field_70177_z, 0.0F, 1.0F, 0.0F);
      GlStateManager.func_179114_b(mc.field_71439_g.field_70125_A, mc.field_71474_y.field_74320_O == 2 ? -1.0F : 1.0F, 0.0F, 0.0F);
      GlStateManager.func_179152_a(-scale, -scale, scale);
   }

   public static void glBillboardDistanceScaled(float x, float y, float z, EntityPlayer player, float scale) {
      glBillboard(x, y, z);
      int distance = (int)player.func_70011_f((double)x, (double)y, (double)z);
      float scaleDistance = (float)distance / 2.0F / (2.0F + (2.0F - scale));
      if (scaleDistance < 1.0F) {
         scaleDistance = 1.0F;
      }

      GlStateManager.func_179152_a(scaleDistance, scaleDistance, scaleDistance);
   }

   public static void drawBoxESPFlat(BlockPos pos, Color color, boolean secondC, Color secondColor, float lineWidth, boolean outline, boolean box, int boxAlpha, boolean air) {
      if (box) {
         drawBoxFlat(pos, new Color(color.getRed(), color.getGreen(), color.getBlue(), boxAlpha));
      }

      if (outline) {
         drawBlockOutlineFlat(pos, secondC ? secondColor : color, lineWidth, air);
      }

   }

   public static void drawBlockOutlineFlat(BlockPos pos, Color color, float linewidth, boolean air) {
      IBlockState iblockstate = mc.field_71441_e.func_180495_p(pos);
      if ((air || iblockstate.func_185904_a() != Material.field_151579_a) && mc.field_71441_e.func_175723_af().func_177746_a(pos)) {
         Vec3d interp = EntityUtil.interpolateEntity(mc.field_71439_g, mc.func_184121_ak());
         drawBlockOutlineFlat(iblockstate.func_185918_c(mc.field_71441_e, pos).func_186662_g(0.0020000000949949026D).func_72317_d(-interp.field_72450_a, -interp.field_72448_b, -interp.field_72449_c), color, linewidth);
      }

   }

   public static void drawBoxFlat(BlockPos pos, Color color) {
      AxisAlignedBB bb = new AxisAlignedBB((double)pos.func_177958_n() - mc.func_175598_ae().field_78730_l, (double)pos.func_177956_o() - mc.func_175598_ae().field_78731_m, (double)pos.func_177952_p() - mc.func_175598_ae().field_78728_n, (double)(pos.func_177958_n() + 1) - mc.func_175598_ae().field_78730_l, (double)pos.func_177956_o() - mc.func_175598_ae().field_78731_m, (double)(pos.func_177952_p() + 1) - mc.func_175598_ae().field_78728_n);
      camera.func_78547_a(((Entity)Objects.requireNonNull(mc.func_175606_aa())).field_70165_t, mc.func_175606_aa().field_70163_u, mc.func_175606_aa().field_70161_v);
      if (camera.func_78546_a(new AxisAlignedBB(bb.field_72340_a + mc.func_175598_ae().field_78730_l, bb.field_72338_b + mc.func_175598_ae().field_78731_m, bb.field_72339_c + mc.func_175598_ae().field_78728_n, bb.field_72336_d + mc.func_175598_ae().field_78730_l, bb.field_72337_e + mc.func_175598_ae().field_78731_m, bb.field_72334_f + mc.func_175598_ae().field_78728_n))) {
         GlStateManager.func_179094_E();
         GlStateManager.func_179147_l();
         GlStateManager.func_179097_i();
         GlStateManager.func_179120_a(770, 771, 0, 1);
         GlStateManager.func_179090_x();
         GlStateManager.func_179132_a(false);
         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
         RenderGlobal.func_189696_b(bb, (float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
         GL11.glDisable(2848);
         GlStateManager.func_179132_a(true);
         GlStateManager.func_179126_j();
         GlStateManager.func_179098_w();
         GlStateManager.func_179084_k();
         GlStateManager.func_179121_F();
      }

   }

   public static void drawBlockOutlineFlat(AxisAlignedBB bb, Color color, float linewidth) {
      float red = (float)color.getRed() / 255.0F;
      float green = (float)color.getGreen() / 255.0F;
      float blue = (float)color.getBlue() / 255.0F;
      float alpha = (float)color.getAlpha() / 255.0F;
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(linewidth);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   static {
      itemRender = mc.func_175599_af();
      camera = new Frustum();
   }
}
