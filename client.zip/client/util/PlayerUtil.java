package client.util;

import client.command.Command;
import client.events.MoveEvent;
import client.modules.movement.ElytraFlight;
import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.util.UUIDTypeAdapter;
import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;
import java.util.UUID;
import java.util.function.Predicate;
import javax.net.ssl.HttpsURLConnection;
import net.minecraft.advancements.AdvancementManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemShield;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class PlayerUtil implements Util {
   private static final JsonParser PARSER = new JsonParser();

   public static int getRoundedDamage(ItemStack stack) {
      return (int)getDamageInPercent(stack);
   }

   public static boolean hasDurability(ItemStack stack) {
      Item item = stack.func_77973_b();
      return item instanceof ItemArmor || item instanceof ItemSword || item instanceof ItemTool || item instanceof ItemShield;
   }

   public static void setMoveSpeed(MoveEvent event, double speed) {
      double forward = (double)ElytraFlight.mc.field_71439_g.field_71158_b.field_192832_b;
      double strafe = (double)ElytraFlight.mc.field_71439_g.field_71158_b.field_78902_a;
      float yaw = ElytraFlight.mc.field_71439_g.field_70177_z;
      if (forward == 0.0D && strafe == 0.0D) {
         event.setX(0.0D);
         event.setZ(0.0D);
         ElytraFlight.mc.field_71439_g.field_70159_w = 0.0D;
         ElytraFlight.mc.field_71439_g.field_70179_y = 0.0D;
      } else {
         if (forward != 0.0D) {
            if (strafe > 0.0D) {
               yaw += (float)(forward > 0.0D ? -45 : 45);
            } else if (strafe < 0.0D) {
               yaw += (float)(forward > 0.0D ? 45 : -45);
            }

            strafe = 0.0D;
            if (forward > 0.0D) {
               forward = 1.0D;
            } else if (forward < 0.0D) {
               forward = -1.0D;
            }
         }

         double x = forward * speed * -Math.sin(Math.toRadians((double)yaw)) + strafe * speed * Math.cos(Math.toRadians((double)yaw));
         double z = forward * speed * Math.cos(Math.toRadians((double)yaw)) - strafe * speed * -Math.sin(Math.toRadians((double)yaw));
         event.setX(x);
         event.setZ(z);
         ElytraFlight.mc.field_71439_g.field_70159_w = x;
         ElytraFlight.mc.field_71439_g.field_70179_y = z;
      }

   }

   public static double getDirection() {
      float rotationYaw = mc.field_71439_g.field_70177_z;
      if (mc.field_71439_g.field_191988_bg < 0.0F) {
         rotationYaw += 180.0F;
      }

      float forward = 1.0F;
      if (mc.field_71439_g.field_191988_bg < 0.0F) {
         forward = -0.5F;
      } else if (mc.field_71439_g.field_191988_bg > 0.0F) {
         forward = 0.5F;
      }

      if (mc.field_71439_g.field_70702_br > 0.0F) {
         rotationYaw -= 90.0F * forward;
      }

      if (mc.field_71439_g.field_70702_br < 0.0F) {
         rotationYaw += 90.0F * forward;
      }

      return Math.toRadians((double)rotationYaw);
   }

   public static boolean isMoving() {
      return (double)Minecraft.func_71410_x().field_71439_g.field_191988_bg != 0.0D || (double)Minecraft.func_71410_x().field_71439_g.field_70702_br != 0.0D;
   }

   public static double vanillaSpeed() {
      double baseSpeed = 0.272D;
      if (Minecraft.func_71410_x().field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
         int amplifier = ((PotionEffect)Objects.requireNonNull(Minecraft.func_71410_x().field_71439_g.func_70660_b(MobEffects.field_76424_c))).func_76458_c();
         baseSpeed *= 1.0D + 0.2D * (double)amplifier;
      }

      return baseSpeed;
   }

   public static boolean isArmorLow(EntityPlayer player, int durability) {
      Iterator var2 = player.field_71071_by.field_70460_b.iterator();

      ItemStack piece;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         piece = (ItemStack)var2.next();
      } while(piece != null && getDamageInPercent(piece) >= (float)durability);

      return true;
   }

   public static float getDamageInPercent(ItemStack stack) {
      float green = ((float)stack.func_77958_k() - (float)stack.func_77952_i()) / (float)stack.func_77958_k();
      float red = 1.0F - green;
      return (float)(100 - (int)(red * 100.0F));
   }

   public static Vec3d getCenter(double posX, double posY, double posZ) {
      return new Vec3d(Math.floor(posX) + 0.5D, Math.floor(posY), Math.floor(posZ) + 0.5D);
   }

   public static void faceVector(Vec3d vec, boolean normalizeAngle) {
      float[] rotations = RotationUtil.getLegitRotations(vec);
      RotationUtil.mc.field_71439_g.field_71174_a.func_147297_a(new Rotation(rotations[0], normalizeAngle ? (float)MathHelper.func_180184_b((int)rotations[1], 360) : rotations[1], RotationUtil.mc.field_71439_g.field_70122_E));
   }

   public static BlockPos getPlayerPos() {
      return new BlockPos(Math.floor(mc.field_71439_g.field_70165_t), Math.floor(mc.field_71439_g.field_70163_u), Math.floor(mc.field_71439_g.field_70161_v));
   }

   public static UUID getUUIDFromName(String name) {
      try {
         PlayerUtil.lookUpUUID process = new PlayerUtil.lookUpUUID(name);
         Thread thread = new Thread(process);
         thread.start();
         thread.join();
         return process.getUUID();
      } catch (Exception var3) {
         return null;
      }
   }

   public static int convertToMouse(int key) {
      switch(key) {
      case -6:
         return 4;
      case -5:
         return 3;
      case -4:
         return 2;
      case -3:
         return 1;
      case -2:
         return 0;
      default:
         return -1;
      }
   }

   public static EntityPlayer findClosestTarget(double rangeMax, EntityPlayer aimTarget) {
      rangeMax *= rangeMax;
      List playerList = mc.field_71441_e.field_73010_i;
      EntityPlayer closestTarget = null;
      Iterator var5 = playerList.iterator();

      while(true) {
         while(true) {
            EntityPlayer entityPlayer;
            do {
               if (!var5.hasNext()) {
                  return closestTarget;
               }

               entityPlayer = (EntityPlayer)var5.next();
            } while(EntityUtil.basicChecksEntity(entityPlayer));

            if (aimTarget == null && mc.field_71439_g.func_70068_e(entityPlayer) <= rangeMax) {
               closestTarget = entityPlayer;
            } else if (aimTarget != null && mc.field_71439_g.func_70068_e(entityPlayer) <= rangeMax && mc.field_71439_g.func_70068_e(entityPlayer) < mc.field_71439_g.func_70068_e(aimTarget)) {
               closestTarget = entityPlayer;
            }
         }
      }
   }

   public static EntityPlayer findClosestTarget() {
      List playerList = mc.field_71441_e.field_73010_i;
      EntityPlayer closestTarget = null;
      Iterator var2 = playerList.iterator();

      while(var2.hasNext()) {
         EntityPlayer entityPlayer = (EntityPlayer)var2.next();
         if (!EntityUtil.basicChecksEntity(entityPlayer)) {
            if (closestTarget == null) {
               closestTarget = entityPlayer;
            } else if (mc.field_71439_g.func_70068_e(entityPlayer) < mc.field_71439_g.func_70068_e(closestTarget)) {
               closestTarget = entityPlayer;
            }
         }
      }

      return closestTarget;
   }

   public static EntityPlayer findLookingPlayer(double rangeMax) {
      ArrayList listPlayer = new ArrayList();
      Iterator var3 = mc.field_71441_e.field_73010_i.iterator();

      while(var3.hasNext()) {
         EntityPlayer playerSin = (EntityPlayer)var3.next();
         if (!EntityUtil.basicChecksEntity(playerSin) && (double)mc.field_71439_g.func_70032_d(playerSin) <= rangeMax) {
            listPlayer.add(playerSin);
         }
      }

      EntityPlayer target = null;
      Vec3d positionEyes = mc.field_71439_g.func_174824_e(mc.func_184121_ak());
      Vec3d rotationEyes = mc.field_71439_g.func_70676_i(mc.func_184121_ak());
      int precision = 2;

      for(int i = 0; i < (int)rangeMax; ++i) {
         for(int j = precision; j > 0; --j) {
            Iterator var9 = listPlayer.iterator();

            while(var9.hasNext()) {
               EntityPlayer targetTemp = (EntityPlayer)var9.next();
               AxisAlignedBB playerBox = targetTemp.func_174813_aQ();
               double xArray = positionEyes.field_72450_a + rotationEyes.field_72450_a * (double)i + rotationEyes.field_72450_a / (double)j;
               double yArray = positionEyes.field_72448_b + rotationEyes.field_72448_b * (double)i + rotationEyes.field_72448_b / (double)j;
               double zArray = positionEyes.field_72449_c + rotationEyes.field_72449_c * (double)i + rotationEyes.field_72449_c / (double)j;
               if (playerBox.field_72337_e >= yArray && playerBox.field_72338_b <= yArray && playerBox.field_72336_d >= xArray && playerBox.field_72340_a <= xArray && playerBox.field_72334_f >= zArray && playerBox.field_72339_c <= zArray) {
                  target = targetTemp;
               }
            }
         }
      }

      return target;
   }

   public static String requestIDs(String data) {
      try {
         String query = "https://api.mojang.com/profiles/minecraft";
         URL url = new URL(query);
         HttpURLConnection conn = (HttpURLConnection)url.openConnection();
         conn.setConnectTimeout(5000);
         conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
         conn.setDoOutput(true);
         conn.setDoInput(true);
         conn.setRequestMethod("POST");
         OutputStream os = conn.getOutputStream();
         os.write(data.getBytes(StandardCharsets.UTF_8));
         os.close();
         InputStream in = new BufferedInputStream(conn.getInputStream());
         String res = convertStreamToString(in);
         in.close();
         conn.disconnect();
         return res;
      } catch (Exception var7) {
         return null;
      }
   }

   public static String convertStreamToString(InputStream is) {
      Scanner s = (new Scanner(is)).useDelimiter("\\A");
      return s.hasNext() ? s.next() : "/";
   }

   public static List getHistoryOfNames(UUID id) {
      try {
         JsonArray array = getResources(new URL("https://api.mojang.com/user/profiles/" + getIdNoHyphens(id) + "/names"), "GET").getAsJsonArray();
         List temp = Lists.newArrayList();
         Iterator var3 = array.iterator();

         while(var3.hasNext()) {
            JsonElement e = (JsonElement)var3.next();
            JsonObject node = e.getAsJsonObject();
            String name = node.get("name").getAsString();
            long changedAt = node.has("changedToAt") ? node.get("changedToAt").getAsLong() : 0L;
            temp.add(name + "Ã‚Â§8" + new Date(changedAt));
         }

         Collections.sort(temp);
         return temp;
      } catch (Exception var9) {
         return null;
      }
   }

   public static String getIdNoHyphens(UUID uuid) {
      return uuid.toString().replaceAll("-", "");
   }

   private static JsonElement getResources(URL url, String request) throws Exception {
      return getResources(url, request, (JsonElement)null);
   }

   private static JsonElement getResources(URL url, String request, JsonElement element) throws Exception {
      HttpsURLConnection connection = null;

      try {
         connection = (HttpsURLConnection)url.openConnection();
         connection.setDoOutput(true);
         connection.setRequestMethod(request);
         connection.setRequestProperty("Content-Type", "application/json");
         if (element != null) {
            DataOutputStream output = new DataOutputStream(connection.getOutputStream());
            output.writeBytes(AdvancementManager.field_192783_b.toJson(element));
            output.close();
         }

         Scanner scanner = new Scanner(connection.getInputStream());
         StringBuilder builder = new StringBuilder();

         while(scanner.hasNextLine()) {
            builder.append(scanner.nextLine());
            builder.append('\n');
         }

         scanner.close();
         String json = builder.toString();
         JsonElement var7 = PARSER.parse(json);
         return var7;
      } finally {
         if (connection != null) {
            connection.disconnect();
         }

      }
   }

   public static class lookUpUUID implements Runnable {
      private final String name;
      private volatile UUID uuid;

      public lookUpUUID(String name) {
         this.name = name;
      }

      public void run() {
         NetworkPlayerInfo profile;
         try {
            ArrayList infoMap = new ArrayList(((NetHandlerPlayClient)Objects.requireNonNull(Util.mc.func_147114_u())).func_175106_d());
            profile = (NetworkPlayerInfo)infoMap.stream().filter((networkPlayerInfo) -> {
               return networkPlayerInfo.func_178845_a().getName().equalsIgnoreCase(this.name);
            }).findFirst().orElse((Object)null);

            assert profile != null;

            this.uuid = profile.func_178845_a().getId();
         } catch (Exception var6) {
            profile = null;
         }

         if (profile == null) {
            Command.sendMessage("Player isn't online. Looking up UUID..");
            String s = PlayerUtil.requestIDs("[\"" + this.name + "\"]");
            if (s != null && !s.isEmpty()) {
               JsonElement element = (new JsonParser()).parse(s);
               if (element.getAsJsonArray().size() == 0) {
                  Command.sendMessage("Couldn't find player ID. (1)");
               } else {
                  try {
                     String id = element.getAsJsonArray().get(0).getAsJsonObject().get("id").getAsString();
                     this.uuid = UUIDTypeAdapter.fromString(id);
                  } catch (Exception var5) {
                     var5.printStackTrace();
                     Command.sendMessage("Couldn't find player ID. (2)");
                  }
               }
            } else {
               Command.sendMessage("Couldn't find player ID. Are you connected to the internet? (0)");
            }
         }

      }

      public UUID getUUID() {
         return this.uuid;
      }

      public String getName() {
         return this.name;
      }
   }
}
