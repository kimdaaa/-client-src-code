package client.util;

import client.Client;
import client.command.Command;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockDeadBush;
import net.minecraft.block.BlockFire;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockSnow;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class BlockUtil implements Util {
   public static final List unSafeBlocks;
   public static Vec3d[] holeOffsets;
   public static final List blackList;
   public static final List shulkerList;
   public static List unSolidBlocks;
   public static final Vec3d[] antiDropOffsetList;
   public static final Vec3d[] platformOffsetList;
   public static final Vec3d[] legOffsetList;
   public static final Vec3d[] offsetList;
   public static final Vec3d[] antiStepOffsetList;
   public static final Vec3d[] antiScaffoldOffsetList;

   public static void placeCrystalOnBlockHacker(BlockPos pos, EnumHand hand) {
      RayTraceResult result = mc.field_71441_e.func_72933_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + (double)mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d((double)pos.func_177958_n() + 0.5D, (double)pos.func_177956_o() - 0.5D, (double)pos.func_177952_p() + 0.5D));
      EnumFacing facing = result != null && result.field_178784_b != null ? result.field_178784_b : EnumFacing.UP;
      mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(pos, facing, hand, 0.0F, 0.0F, 0.0F));
   }

   public static List possiblePlacePositions(float placeRange) {
      NonNullList positions = NonNullList.func_191196_a();
      positions.addAll((Collection)getSphere(EntityUtil.getPlayerPos(mc.field_71439_g), placeRange, (int)placeRange, false, true, 0).stream().filter(BlockUtil::canPlaceCrystal).collect(Collectors.toList()));
      return positions;
   }

   public static List possiblePlacePositions(float placeRange, boolean specialEntityCheck, boolean oneDot15) {
      NonNullList positions = NonNullList.func_191196_a();
      positions.addAll((Collection)getSphere(EntityUtil.getPlayerPos(mc.field_71439_g), placeRange, (int)placeRange, false, true, 0).stream().filter((pos) -> {
         return canPlaceCrystal(pos, specialEntityCheck, oneDot15);
      }).collect(Collectors.toList()));
      return positions;
   }

   public static boolean canPlaceCrystal(BlockPos blockPos) {
      BlockPos boost = blockPos.func_177982_a(0, 1, 0);
      BlockPos boost2 = blockPos.func_177982_a(0, 2, 0);

      try {
         return (mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150357_h || mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150343_Z) && mc.field_71441_e.func_180495_p(boost).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(boost2).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost)).isEmpty() && mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost2)).isEmpty();
      } catch (Exception var4) {
         return false;
      }
   }

   public static boolean canPlaceCrystal(BlockPos blockPos, boolean specialEntityCheck, boolean oneDot15) {
      BlockPos boost = blockPos.func_177982_a(0, 1, 0);
      BlockPos boost2 = blockPos.func_177982_a(0, 2, 0);

      try {
         if (mc.field_71441_e.func_180495_p(blockPos).func_177230_c() != Blocks.field_150357_h && mc.field_71441_e.func_180495_p(blockPos).func_177230_c() != Blocks.field_150343_Z) {
            return false;
         } else if ((mc.field_71441_e.func_180495_p(boost).func_177230_c() != Blocks.field_150350_a || mc.field_71441_e.func_180495_p(boost2).func_177230_c() != Blocks.field_150350_a) && !oneDot15) {
            return false;
         } else if (!specialEntityCheck) {
            return mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost)).isEmpty() && (oneDot15 || mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost2)).isEmpty());
         } else {
            Iterator var5 = mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost)).iterator();

            Entity entity;
            while(var5.hasNext()) {
               entity = (Entity)var5.next();
               if (!(entity instanceof EntityEnderCrystal)) {
                  return false;
               }
            }

            if (!oneDot15) {
               var5 = mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost2)).iterator();

               while(var5.hasNext()) {
                  entity = (Entity)var5.next();
                  if (!(entity instanceof EntityEnderCrystal)) {
                     return false;
                  }
               }
            }

            return true;
         }
      } catch (Exception var7) {
         return false;
      }
   }

   public static boolean isValidBlock(BlockPos pos) {
      Block block = mc.field_71441_e.func_180495_p(pos).func_177230_c();
      return !(block instanceof BlockLiquid) && block.func_149688_o((IBlockState)null) != Material.field_151579_a;
   }

   public static boolean isScaffoldPos(BlockPos pos) {
      return mc.field_71441_e.func_175623_d(pos) || mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150431_aC || mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150329_H || mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof BlockLiquid;
   }

   public static Boolean isPosInFov(BlockPos pos) {
      int dirnumber = RotationUtil.getDirection4D();
      if (dirnumber == 0 && (double)pos.func_177952_p() - mc.field_71439_g.func_174791_d().field_72449_c < 0.0D) {
         return false;
      } else if (dirnumber == 1 && (double)pos.func_177958_n() - mc.field_71439_g.func_174791_d().field_72450_a > 0.0D) {
         return false;
      } else {
         return dirnumber == 2 && (double)pos.func_177952_p() - mc.field_71439_g.func_174791_d().field_72449_c > 0.0D ? false : dirnumber != 3 || (double)pos.func_177958_n() - mc.field_71439_g.func_174791_d().field_72450_a >= 0.0D;
      }
   }

   public static boolean isBlockUnSafe(Block block) {
      return unSafeBlocks.contains(block);
   }

   public static boolean isBlockSolid(BlockPos pos) {
      return !isBlockUnSolid(pos);
   }

   public static boolean isBlockUnSolid(BlockPos pos) {
      return isBlockUnSolid(mc.field_71441_e.func_180495_p(pos).func_177230_c());
   }

   public static boolean isBlockUnSolid(Block block) {
      return unSolidBlocks.contains(block);
   }

   public static List getNearbyBlocks(EntityPlayer player, double blockRange, boolean motion) {
      List nearbyBlocks = new ArrayList();
      int range = (int)MathUtil.roundDouble(blockRange, 0);
      if (motion) {
         player.func_180425_c().func_177971_a(new Vec3i(player.field_70159_w, player.field_70181_x, player.field_70179_y));
      }

      for(int x = -range; x <= range; ++x) {
         for(int y = -range; y <= range - range / 2; ++y) {
            for(int z = -range; z <= range; ++z) {
               nearbyBlocks.add(player.func_180425_c().func_177982_a(x, y, z));
            }
         }
      }

      return nearbyBlocks;
   }

   public static boolean canBreak(BlockPos pos) {
      IBlockState blockState = mc.field_71441_e.func_180495_p(pos);
      Block block = blockState.func_177230_c();
      return block.func_176195_g(blockState, mc.field_71441_e, pos) != -1.0F;
   }

   public static EntityPlayer getTarget(float range) {
      EntityPlayer currentTarget = null;
      Iterator var2 = mc.field_71441_e.field_73010_i.iterator();

      while(var2.hasNext()) {
         EntityPlayer player = (EntityPlayer)var2.next();
         if (!EntityUtil.isntValid(player, (double)range)) {
            if (currentTarget == null) {
               currentTarget = player;
            } else if (mc.field_71439_g.func_70068_e(player) < mc.field_71439_g.func_70068_e(currentTarget)) {
               currentTarget = player;
            }
         }
      }

      return currentTarget;
   }

   public static boolean isInHole(EntityPlayer entity) {
      return isBlockValid(new BlockPos(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v));
   }

   public static boolean isBlockValid(BlockPos blockPos) {
      return isBedrockHole(blockPos) || isObbyHole(blockPos) || isBothHole(blockPos);
   }

   public static boolean isObbyHole(BlockPos blockPos) {
      BlockPos[] array = new BlockPos[]{blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b()};
      BlockPos[] var3 = array;
      int var4 = array.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         BlockPos pos = var3[var5];
         IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
         if (touchingState.func_177230_c() != Blocks.field_150343_Z) {
            return false;
         }
      }

      return true;
   }

   public static boolean isBedrockHole(BlockPos blockPos) {
      BlockPos[] array = new BlockPos[]{blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b()};
      BlockPos[] var3 = array;
      int var4 = array.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         BlockPos pos = var3[var5];
         IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
         if (touchingState.func_177230_c() != Blocks.field_150357_h) {
            return false;
         }
      }

      return true;
   }

   public static boolean isBothHole(BlockPos blockPos) {
      BlockPos[] array = new BlockPos[]{blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b()};
      BlockPos[] var3 = array;
      int var4 = array.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         BlockPos pos = var3[var5];
         IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
         if (touchingState.func_177230_c() != Blocks.field_150357_h && touchingState.func_177230_c() != Blocks.field_150343_Z) {
            return false;
         }
      }

      return true;
   }

   public static List getSphere(double radius, boolean ignoreAir) {
      ArrayList sphere = new ArrayList();
      BlockPos pos = new BlockPos(mc.field_71439_g.func_174791_d());
      int posX = pos.func_177958_n();
      int posY = pos.func_177956_o();
      int posZ = pos.func_177952_p();
      int radiuss = (int)radius;

      for(int x = posX - radiuss; (double)x <= (double)posX + radius; ++x) {
         for(int z = posZ - radiuss; (double)z <= (double)posZ + radius; ++z) {
            for(int y = posY - radiuss; (double)y < (double)posY + radius; ++y) {
               double dist = (double)((posX - x) * (posX - x) + (posZ - z) * (posZ - z) + (posY - y) * (posY - y));
               BlockPos position;
               if (dist < radius * radius && (mc.field_71441_e.func_180495_p(position = new BlockPos(x, y, z)).func_177230_c() != Blocks.field_150350_a || !ignoreAir)) {
                  sphere.add(position);
               }
            }
         }
      }

      return sphere;
   }

   public static boolean placeBlockSmartRotate(BlockPos pos, EnumHand hand, boolean rotate, boolean packet, boolean isSneaking) {
      boolean sneaking = false;
      EnumFacing side = getFirstFacing(pos);
      Command.sendMessage(((EnumFacing)Objects.requireNonNull(side)).toString());
      if (side == null) {
         return isSneaking;
      } else {
         BlockPos neighbour = pos.func_177972_a(side);
         EnumFacing opposite = side.func_176734_d();
         Vec3d hitVec = (new Vec3d(neighbour)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(opposite.func_176730_m())).func_186678_a(0.5D));
         Block neighbourBlock = mc.field_71441_e.func_180495_p(neighbour).func_177230_c();
         if (!mc.field_71439_g.func_70093_af() && (blackList.contains(neighbourBlock) || shulkerList.contains(neighbourBlock))) {
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.START_SNEAKING));
            sneaking = true;
         }

         if (rotate) {
            Client.rotationManager.lookAtVec3d(hitVec);
         }

         rightClickBlock(neighbour, hitVec, hand, opposite, packet);
         mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
         mc.field_71467_ac = 4;
         return sneaking || isSneaking;
      }
   }

   public static void placeCrystalOnBlock(BlockPos pos, EnumHand hand, boolean swing) {
      RayTraceResult result = mc.field_71441_e.func_72933_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + (double)mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d((double)pos.func_177958_n() + 0.5D, (double)pos.func_177956_o() - 0.5D, (double)pos.func_177952_p() + 0.5D));
      EnumFacing facing = result != null && result.field_178784_b != null ? result.field_178784_b : EnumFacing.UP;
      mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(pos, facing, hand, 0.0F, 0.0F, 0.0F));
      if (swing) {
         mc.field_71439_g.field_71174_a.func_147297_a(new CPacketAnimation(hand));
      }

   }

   public static void faceVectorPacketInstant(Vec3d vec) {
      float[] rotations = getNeededRotations2(vec);
      mc.field_71439_g.field_71174_a.func_147297_a(new Rotation(rotations[0], rotations[1], mc.field_71439_g.field_70122_E));
   }

   private static float[] getNeededRotations2(Vec3d vec) {
      Vec3d eyesPos = getEyesPos();
      double diffX = vec.field_72450_a - eyesPos.field_72450_a;
      double diffY = vec.field_72448_b - eyesPos.field_72448_b;
      double diffZ = vec.field_72449_c - eyesPos.field_72449_c;
      double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
      float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
      float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
      return new float[]{mc.field_71439_g.field_70177_z + MathHelper.func_76142_g(yaw - mc.field_71439_g.field_70177_z), mc.field_71439_g.field_70125_A + MathHelper.func_76142_g(pitch - mc.field_71439_g.field_70125_A)};
   }

   public static Vec3d getEyesPos() {
      return new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + (double)mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v);
   }

   public static List getCircle(BlockPos loc, int y, float r, boolean hollow) {
      List circleblocks = new ArrayList();
      int cx = loc.func_177958_n();
      int cz = loc.func_177952_p();

      for(int x = cx - (int)r; (float)x <= (float)cx + r; ++x) {
         for(int z = cz - (int)r; (float)z <= (float)cz + r; ++z) {
            double dist = (double)((cx - x) * (cx - x) + (cz - z) * (cz - z));
            if (dist < (double)(r * r) && (!hollow || dist >= (double)((r - 1.0F) * (r - 1.0F)))) {
               BlockPos l = new BlockPos(x, y, z);
               circleblocks.add(l);
            }
         }
      }

      return circleblocks;
   }

   public static EnumFacing getPlaceableSide(BlockPos pos) {
      EnumFacing[] var1 = EnumFacing.values();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         EnumFacing side = var1[var3];
         BlockPos neighbour = pos.func_177972_a(side);
         if (mc.field_71441_e.func_180495_p(neighbour).func_177230_c().func_176209_a(mc.field_71441_e.func_180495_p(neighbour), false)) {
            IBlockState blockState = mc.field_71441_e.func_180495_p(neighbour);
            if (!blockState.func_185904_a().func_76222_j()) {
               return side;
            }
         }
      }

      return null;
   }

   public static BlockUtil.BlockSafety isBlockSafe(Block block) {
      if (block == Blocks.field_150357_h) {
         return BlockUtil.BlockSafety.UNBREAKABLE;
      } else {
         return block != Blocks.field_150343_Z && block != Blocks.field_150477_bB && block != Blocks.field_150467_bQ ? BlockUtil.BlockSafety.BREAKABLE : BlockUtil.BlockSafety.RESISTANT;
      }
   }

   public static List getSphereSecondary(float radius, boolean ignoreAir) {
      List sphere = new ArrayList();
      BlockPos pos = new BlockPos(mc.field_71439_g.func_174791_d());
      int posX = pos.func_177958_n();
      int posY = pos.func_177956_o();
      int posZ = pos.func_177952_p();
      int radiuss = (int)radius;

      for(int x = posX - radiuss; (float)x <= (float)posX + radius; ++x) {
         for(int z = posZ - radiuss; (float)z <= (float)posZ + radius; ++z) {
            for(int y = posY - radiuss; (float)y < (float)posY + radius; ++y) {
               if ((float)((posX - x) * (posX - x) + (posZ - z) * (posZ - z) + (posY - y) * (posY - y)) < radius * radius) {
                  BlockPos position = new BlockPos(x, y, z);
                  if (!ignoreAir || mc.field_71441_e.func_180495_p(position).func_177230_c() != Blocks.field_150350_a) {
                     sphere.add(position);
                  }
               }
            }
         }
      }

      return sphere;
   }

   public static boolean canPlaceCrystal(BlockPos blockPos, boolean check) {
      BlockPos boost = blockPos.func_177982_a(0, 1, 0);
      if (mc.field_71441_e.func_180495_p(blockPos).func_177230_c() != Blocks.field_150357_h && mc.field_71441_e.func_180495_p(blockPos).func_177230_c() != Blocks.field_150343_Z) {
         return false;
      } else {
         BlockPos boost2 = blockPos.func_177982_a(0, 2, 0);
         if (mc.field_71441_e.func_180495_p(boost).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(boost2).func_177230_c() == Blocks.field_150350_a) {
            Iterator var4 = mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost)).iterator();

            Entity entity;
            while(var4.hasNext()) {
               entity = (Entity)var4.next();
               if (!entity.field_70128_L && !(entity instanceof EntityEnderCrystal)) {
                  return false;
               }
            }

            if (check) {
               var4 = mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost2)).iterator();

               while(var4.hasNext()) {
                  entity = (Entity)var4.next();
                  if (!entity.field_70128_L && !(entity instanceof EntityEnderCrystal)) {
                     return false;
                  }
               }
            }

            return true;
         } else {
            return false;
         }
      }
   }

   public static BlockUtil.HoleInfo isHole(BlockPos centreBlock, boolean onlyOneWide, boolean ignoreDown) {
      BlockUtil.HoleInfo output = new BlockUtil.HoleInfo();
      HashMap unsafeSides = getUnsafeSides(centreBlock);
      if (unsafeSides.containsKey(BlockUtil.BlockOffset.DOWN) && unsafeSides.remove(BlockUtil.BlockOffset.DOWN, BlockUtil.BlockSafety.BREAKABLE) && !ignoreDown) {
         output.setSafety(BlockUtil.BlockSafety.BREAKABLE);
         return output;
      } else {
         int size = unsafeSides.size();
         unsafeSides.entrySet().removeIf((entry) -> {
            return entry.getValue() == BlockUtil.BlockSafety.RESISTANT;
         });
         if (unsafeSides.size() != size) {
            output.setSafety(BlockUtil.BlockSafety.RESISTANT);
         }

         size = unsafeSides.size();
         if (size == 0) {
            output.setType(BlockUtil.HoleType.SINGLE);
            output.setCentre(new AxisAlignedBB(centreBlock));
            return output;
         } else if (size == 1 && !onlyOneWide) {
            return isDoubleHole(output, centreBlock, (BlockUtil.BlockOffset)unsafeSides.keySet().stream().findFirst().get());
         } else {
            output.setSafety(BlockUtil.BlockSafety.BREAKABLE);
            return output;
         }
      }
   }

   private static BlockUtil.HoleInfo isDoubleHole(BlockUtil.HoleInfo info, BlockPos centreBlock, BlockUtil.BlockOffset weakSide) {
      BlockPos unsafePos = weakSide.offset(centreBlock);
      HashMap unsafeSides = getUnsafeSides(unsafePos);
      int size = unsafeSides.size();
      unsafeSides.entrySet().removeIf((entry) -> {
         return entry.getValue() == BlockUtil.BlockSafety.RESISTANT;
      });
      if (unsafeSides.size() != size) {
         info.setSafety(BlockUtil.BlockSafety.RESISTANT);
      }

      if (unsafeSides.containsKey(BlockUtil.BlockOffset.DOWN)) {
         info.setType(BlockUtil.HoleType.CUSTOM);
         unsafeSides.remove(BlockUtil.BlockOffset.DOWN);
      }

      if (unsafeSides.size() > 1) {
         info.setType(BlockUtil.HoleType.NONE);
         return info;
      } else {
         double minX = (double)Math.min(centreBlock.func_177958_n(), unsafePos.func_177958_n());
         double maxX = (double)(Math.max(centreBlock.func_177958_n(), unsafePos.func_177958_n()) + 1);
         double minZ = (double)Math.min(centreBlock.func_177952_p(), unsafePos.func_177952_p());
         double maxZ = (double)(Math.max(centreBlock.func_177952_p(), unsafePos.func_177952_p()) + 1);
         info.setCentre(new AxisAlignedBB(minX, (double)centreBlock.func_177956_o(), minZ, maxX, (double)(centreBlock.func_177956_o() + 1), maxZ));
         if (info.getType() != BlockUtil.HoleType.CUSTOM) {
            info.setType(BlockUtil.HoleType.DOUBLE);
         }

         return info;
      }
   }

   public static HashMap getUnsafeSides(BlockPos pos) {
      HashMap output = new HashMap();
      BlockUtil.BlockSafety temp = isBlockSafe(mc.field_71441_e.func_180495_p(BlockUtil.BlockOffset.DOWN.offset(pos)).func_177230_c());
      if (temp != BlockUtil.BlockSafety.UNBREAKABLE) {
         output.put(BlockUtil.BlockOffset.DOWN, temp);
      }

      temp = isBlockSafe(mc.field_71441_e.func_180495_p(BlockUtil.BlockOffset.NORTH.offset(pos)).func_177230_c());
      if (temp != BlockUtil.BlockSafety.UNBREAKABLE) {
         output.put(BlockUtil.BlockOffset.NORTH, temp);
      }

      temp = isBlockSafe(mc.field_71441_e.func_180495_p(BlockUtil.BlockOffset.SOUTH.offset(pos)).func_177230_c());
      if (temp != BlockUtil.BlockSafety.UNBREAKABLE) {
         output.put(BlockUtil.BlockOffset.SOUTH, temp);
      }

      temp = isBlockSafe(mc.field_71441_e.func_180495_p(BlockUtil.BlockOffset.EAST.offset(pos)).func_177230_c());
      if (temp != BlockUtil.BlockSafety.UNBREAKABLE) {
         output.put(BlockUtil.BlockOffset.EAST, temp);
      }

      temp = isBlockSafe(mc.field_71441_e.func_180495_p(BlockUtil.BlockOffset.WEST.offset(pos)).func_177230_c());
      if (temp != BlockUtil.BlockSafety.UNBREAKABLE) {
         output.put(BlockUtil.BlockOffset.WEST, temp);
      }

      return output;
   }

   public static BlockPos getRoundedBlockPos(Entity entity) {
      return new BlockPos(MathUtil.roundVec(entity.func_174791_d(), 0));
   }

   public static boolean isSafe(Entity entity, int height, boolean floor) {
      return getUnsafeBlocks(entity, height, floor).size() == 0;
   }

   public static List getUnsafeBlocks(Entity entity, int height, boolean floor) {
      return getUnsafeBlocksFromVec3d(entity.func_174791_d(), height, floor);
   }

   public static List getUnsafeBlocksFromVec3d(Vec3d pos, int height, boolean floor) {
      ArrayList vec3ds = new ArrayList();
      Vec3d[] var4 = getOffsets(height, floor);
      int var5 = var4.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         Vec3d vector = var4[var6];
         BlockPos targetPos = (new BlockPos(pos)).func_177963_a(vector.field_72450_a, vector.field_72448_b, vector.field_72449_c);
         Block block = Util.mc.field_71441_e.func_180495_p(targetPos).func_177230_c();
         if (block instanceof BlockAir || block instanceof BlockLiquid || block instanceof BlockTallGrass || block instanceof BlockFire || block instanceof BlockDeadBush || block instanceof BlockSnow) {
            vec3ds.add(vector);
         }
      }

      return vec3ds;
   }

   public static Vec3d[] getUnsafeBlockArray(Vec3d vec3d, int height, boolean floor) {
      List list = getUnsafeBlocksFromVec3d(vec3d, height, floor);
      Vec3d[] array = new Vec3d[list.size()];
      return (Vec3d[])list.toArray(array);
   }

   private static boolean hasNeighbour(BlockPos blockPos) {
      EnumFacing[] var1 = EnumFacing.values();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         EnumFacing side = var1[var3];
         BlockPos neighbour = blockPos.func_177972_a(side);
         if (!mc.field_71441_e.func_180495_p(neighbour).func_185904_a().func_76222_j()) {
            return true;
         }
      }

      return false;
   }

   public static boolean checkForNeighbours(BlockPos blockPos) {
      if (!hasNeighbour(blockPos)) {
         EnumFacing[] var1 = EnumFacing.values();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            EnumFacing side = var1[var3];
            BlockPos neighbour = blockPos.func_177972_a(side);
            if (hasNeighbour(neighbour)) {
               return true;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   public static EnumFacing getFirstFacing(BlockPos pos) {
      Iterator iterator = getPossibleSides(pos).iterator();
      if (iterator.hasNext()) {
         EnumFacing facing = (EnumFacing)iterator.next();
         return facing;
      } else {
         return null;
      }
   }

   public static void rightClickBlock(BlockPos pos, Vec3d vec, EnumHand hand, EnumFacing direction, boolean packet) {
      if (packet) {
         float f = (float)(vec.field_72450_a - (double)pos.func_177958_n());
         float f1 = (float)(vec.field_72448_b - (double)pos.func_177956_o());
         float f2 = (float)(vec.field_72449_c - (double)pos.func_177952_p());
         mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(pos, direction, hand, f, f1, f2));
      } else {
         mc.field_71442_b.func_187099_a(mc.field_71439_g, mc.field_71441_e, pos, direction, vec, hand);
      }

      mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
      mc.field_71467_ac = 4;
   }

   public static boolean placeBlock(BlockPos pos, EnumHand hand, boolean rotate, boolean packet, boolean isSneaking) {
      boolean sneaking = false;
      EnumFacing side = getFirstFacing(pos);
      if (side == null) {
         return isSneaking;
      } else {
         BlockPos neighbour = pos.func_177972_a(side);
         EnumFacing opposite = side.func_176734_d();
         Vec3d hitVec = (new Vec3d(neighbour)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(opposite.func_176730_m())).func_186678_a(0.5D));
         Block neighbourBlock = mc.field_71441_e.func_180495_p(neighbour).func_177230_c();
         if (!mc.field_71439_g.func_70093_af() && (blackList.contains(neighbourBlock) || shulkerList.contains(neighbourBlock))) {
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.START_SNEAKING));
            mc.field_71439_g.func_70095_a(true);
            sneaking = true;
         }

         if (rotate) {
            PlayerUtil.faceVector(hitVec, true);
         }

         rightClickBlock(neighbour, hitVec, hand, opposite, packet);
         mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
         mc.field_71467_ac = 4;
         return sneaking || isSneaking;
      }
   }

   public static List getOffsetList(int y, boolean floor) {
      ArrayList offsets = new ArrayList();
      offsets.add(new Vec3d(-1.0D, (double)y, 0.0D));
      offsets.add(new Vec3d(1.0D, (double)y, 0.0D));
      offsets.add(new Vec3d(0.0D, (double)y, -1.0D));
      offsets.add(new Vec3d(0.0D, (double)y, 1.0D));
      if (floor) {
         offsets.add(new Vec3d(0.0D, (double)(y - 1), 0.0D));
      }

      return offsets;
   }

   public static Vec3d[] getOffsets(int y, boolean floor) {
      List offsets = getOffsetList(y, floor);
      Vec3d[] array = new Vec3d[offsets.size()];
      return (Vec3d[])offsets.toArray(array);
   }

   public static List getCock(float radius, boolean ignoreAir) {
      ArrayList sphere = new ArrayList();
      BlockPos pos = new BlockPos(mc.field_71439_g.func_174791_d());
      int posX = pos.func_177958_n();
      int posY = pos.func_177956_o();
      int posZ = pos.func_177952_p();
      int radiuss = (int)radius;

      for(int x = posX - radiuss; (float)x <= (float)posX + radius; ++x) {
         for(int z = posZ - radiuss; (float)z <= (float)posZ + radius; ++z) {
            for(int y = posY - radiuss; (float)y < (float)posY + radius; ++y) {
               double dist = (double)((posX - x) * (posX - x) + (posZ - z) * (posZ - z) + (posY - y) * (posY - y));
               BlockPos position;
               if (dist < (double)(radius * radius) && (mc.field_71441_e.func_180495_p(position = new BlockPos(x, y, z)).func_177230_c() != Blocks.field_150350_a || !ignoreAir)) {
                  sphere.add(position);
               }
            }
         }
      }

      return sphere;
   }

   public static List getPossibleSides(BlockPos pos) {
      ArrayList facings = new ArrayList();
      EnumFacing[] var2 = EnumFacing.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         EnumFacing side = var2[var4];
         BlockPos neighbour = pos.func_177972_a(side);
         if (mc.field_71441_e.func_180495_p(neighbour).func_177230_c().func_176209_a(mc.field_71441_e.func_180495_p(neighbour), false) && !mc.field_71441_e.func_180495_p(neighbour).func_185904_a().func_76222_j()) {
            facings.add(side);
         }
      }

      return facings;
   }

   public static int isPositionPlaceable(BlockPos pos, boolean rayTrace) {
      return isPositionPlaceable(pos, rayTrace, true);
   }

   public static int isPositionPlaceable(BlockPos pos, boolean rayTrace, boolean entityCheck) {
      Block block = mc.field_71441_e.func_180495_p(pos).func_177230_c();
      if (!(block instanceof BlockAir) && !(block instanceof BlockLiquid) && !(block instanceof BlockTallGrass) && !(block instanceof BlockFire) && !(block instanceof BlockDeadBush) && !(block instanceof BlockSnow)) {
         return 0;
      } else if (!rayTracePlaceCheck(pos, rayTrace, 0.0F)) {
         return -1;
      } else {
         Iterator var4;
         if (entityCheck) {
            var4 = mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(pos)).iterator();

            while(var4.hasNext()) {
               Entity entity = (Entity)var4.next();
               if (!(entity instanceof EntityItem) && !(entity instanceof EntityXPOrb)) {
                  return 1;
               }
            }
         }

         var4 = getPossibleSides(pos).iterator();

         EnumFacing side;
         do {
            if (!var4.hasNext()) {
               return 2;
            }

            side = (EnumFacing)var4.next();
         } while(!canBeClicked(pos.func_177972_a(side)));

         return 3;
      }
   }

   public static Vec3d[] getHelpingBlocks(Vec3d vec3d) {
      return new Vec3d[]{new Vec3d(vec3d.field_72450_a, vec3d.field_72448_b - 1.0D, vec3d.field_72449_c), new Vec3d(vec3d.field_72450_a != 0.0D ? vec3d.field_72450_a * 2.0D : vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72450_a != 0.0D ? vec3d.field_72449_c : vec3d.field_72449_c * 2.0D), new Vec3d(vec3d.field_72450_a == 0.0D ? vec3d.field_72450_a + 1.0D : vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72450_a == 0.0D ? vec3d.field_72449_c : vec3d.field_72449_c + 1.0D), new Vec3d(vec3d.field_72450_a == 0.0D ? vec3d.field_72450_a - 1.0D : vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72450_a == 0.0D ? vec3d.field_72449_c : vec3d.field_72449_c - 1.0D), new Vec3d(vec3d.field_72450_a, vec3d.field_72448_b + 1.0D, vec3d.field_72449_c)};
   }

   public static List getSphere(BlockPos pos, float r, int h, boolean hollow, boolean sphere, int plus_y) {
      ArrayList circleblocks = new ArrayList();
      int cx = pos.func_177958_n();
      int cy = pos.func_177956_o();
      int cz = pos.func_177952_p();

      for(int x = cx - (int)r; (float)x <= (float)cx + r; ++x) {
         for(int z = cz - (int)r; (float)z <= (float)cz + r; ++z) {
            int y = sphere ? cy - (int)r : cy;

            while(true) {
               float f = (float)y;
               float f2 = sphere ? (float)cy + r : (float)(cy + h);
               if (f >= f2) {
                  break;
               }

               double dist = (double)((cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? (cy - y) * (cy - y) : 0));
               if (dist < (double)(r * r) && (!hollow || dist >= (double)((r - 1.0F) * (r - 1.0F)))) {
                  BlockPos l = new BlockPos(x, y + plus_y, z);
                  circleblocks.add(l);
               }

               ++y;
            }
         }
      }

      return circleblocks;
   }

   public static boolean canBeClicked(BlockPos pos) {
      return getBlock(pos).func_176209_a(getState(pos), false);
   }

   private static Block getBlock(BlockPos pos) {
      return getState(pos).func_177230_c();
   }

   private static IBlockState getState(BlockPos pos) {
      return mc.field_71441_e.func_180495_p(pos);
   }

   public static BlockPos[] toBlockPos(Vec3d[] vec3ds) {
      BlockPos[] list = new BlockPos[vec3ds.length];

      for(int i = 0; i < vec3ds.length; ++i) {
         list[i] = new BlockPos(vec3ds[i]);
      }

      return list;
   }

   public static boolean rayTracePlaceCheck(BlockPos pos, boolean shouldCheck, float height) {
      return !shouldCheck || mc.field_71441_e.func_147447_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + (double)mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d((double)pos.func_177958_n(), (double)((float)pos.func_177956_o() + height), (double)pos.func_177952_p()), false, true, false) == null;
   }

   static {
      unSafeBlocks = Arrays.asList(Blocks.field_150343_Z, Blocks.field_150357_h, Blocks.field_150477_bB, Blocks.field_150467_bQ);
      holeOffsets = new Vec3d[]{new Vec3d(-1.0D, 0.0D, 0.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(0.0D, 0.0D, 1.0D), new Vec3d(0.0D, -1.0D, 0.0D)};
      blackList = Arrays.asList(Blocks.field_150477_bB, Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150462_ai, Blocks.field_150467_bQ, Blocks.field_150382_bo, Blocks.field_150438_bZ, Blocks.field_150409_cd, Blocks.field_150367_z, Blocks.field_150415_aT, Blocks.field_150381_bn);
      shulkerList = Arrays.asList(Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA);
      unSolidBlocks = Arrays.asList(Blocks.field_150356_k, Blocks.field_150457_bL, Blocks.field_150433_aE, Blocks.field_150404_cg, Blocks.field_185764_cQ, Blocks.field_150465_bP, Blocks.field_150457_bL, Blocks.field_150473_bD, Blocks.field_150479_bC, Blocks.field_150471_bO, Blocks.field_150442_at, Blocks.field_150430_aB, Blocks.field_150468_ap, Blocks.field_150441_bU, Blocks.field_150455_bV, Blocks.field_150413_aR, Blocks.field_150416_aS, Blocks.field_150437_az, Blocks.field_150429_aA, Blocks.field_150488_af, Blocks.field_150350_a, Blocks.field_150427_aO, Blocks.field_150384_bq, Blocks.field_150355_j, Blocks.field_150358_i, Blocks.field_150353_l, Blocks.field_150356_k, Blocks.field_150345_g, Blocks.field_150328_O, Blocks.field_150327_N, Blocks.field_150338_P, Blocks.field_150337_Q, Blocks.field_150464_aj, Blocks.field_150459_bM, Blocks.field_150469_bN, Blocks.field_185773_cZ, Blocks.field_150436_aH, Blocks.field_150393_bb, Blocks.field_150394_bc, Blocks.field_150392_bi, Blocks.field_150388_bm, Blocks.field_150375_by, Blocks.field_185766_cS, Blocks.field_185765_cR, Blocks.field_150329_H, Blocks.field_150330_I, Blocks.field_150395_bd, Blocks.field_150480_ab, Blocks.field_150448_aq, Blocks.field_150408_cc, Blocks.field_150319_E, Blocks.field_150318_D, Blocks.field_150478_aa);
      antiDropOffsetList = new Vec3d[]{new Vec3d(0.0D, -2.0D, 0.0D)};
      platformOffsetList = new Vec3d[]{new Vec3d(0.0D, -1.0D, 0.0D), new Vec3d(0.0D, -1.0D, -1.0D), new Vec3d(0.0D, -1.0D, 1.0D), new Vec3d(-1.0D, -1.0D, 0.0D), new Vec3d(1.0D, -1.0D, 0.0D)};
      legOffsetList = new Vec3d[]{new Vec3d(-1.0D, 0.0D, 0.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(0.0D, 0.0D, 1.0D)};
      offsetList = new Vec3d[]{new Vec3d(1.0D, 1.0D, 0.0D), new Vec3d(-1.0D, 1.0D, 0.0D), new Vec3d(0.0D, 1.0D, 1.0D), new Vec3d(0.0D, 1.0D, -1.0D), new Vec3d(0.0D, 2.0D, 0.0D)};
      antiStepOffsetList = new Vec3d[]{new Vec3d(-1.0D, 2.0D, 0.0D), new Vec3d(1.0D, 2.0D, 0.0D), new Vec3d(0.0D, 2.0D, 1.0D), new Vec3d(0.0D, 2.0D, -1.0D)};
      antiScaffoldOffsetList = new Vec3d[]{new Vec3d(0.0D, 3.0D, 0.0D)};
   }

   public static enum ValidResult {
      NoEntityCollision,
      AlreadyBlockThere,
      NoNeighbors,
      Ok;
   }

   public static enum BlockOffset {
      DOWN(0, -1, 0),
      UP(0, 1, 0),
      NORTH(0, 0, -1),
      EAST(1, 0, 0),
      SOUTH(0, 0, 1),
      WEST(-1, 0, 0);

      private final int x;
      private final int y;
      private final int z;

      private BlockOffset(int x, int y, int z) {
         this.x = x;
         this.y = y;
         this.z = z;
      }

      public BlockPos offset(BlockPos pos) {
         return pos.func_177982_a(this.x, this.y, this.z);
      }

      public BlockPos forward(BlockPos pos, int scale) {
         return pos.func_177982_a(this.x * scale, 0, this.z * scale);
      }

      public BlockPos backward(BlockPos pos, int scale) {
         return pos.func_177982_a(-this.x * scale, 0, -this.z * scale);
      }

      public BlockPos left(BlockPos pos, int scale) {
         return pos.func_177982_a(this.z * scale, 0, -this.x * scale);
      }

      public BlockPos right(BlockPos pos, int scale) {
         return pos.func_177982_a(-this.z * scale, 0, this.x * scale);
      }
   }

   public static class HoleInfo {
      private BlockUtil.HoleType type;
      private BlockUtil.BlockSafety safety;
      private AxisAlignedBB centre;

      public HoleInfo() {
         this(BlockUtil.BlockSafety.UNBREAKABLE, BlockUtil.HoleType.NONE);
      }

      public HoleInfo(BlockUtil.BlockSafety safety, BlockUtil.HoleType type) {
         this.type = type;
         this.safety = safety;
      }

      public void setType(BlockUtil.HoleType type) {
         this.type = type;
      }

      public void setSafety(BlockUtil.BlockSafety safety) {
         this.safety = safety;
      }

      public void setCentre(AxisAlignedBB centre) {
         this.centre = centre;
      }

      public BlockUtil.HoleType getType() {
         return this.type;
      }

      public BlockUtil.BlockSafety getSafety() {
         return this.safety;
      }

      public AxisAlignedBB getCentre() {
         return this.centre;
      }
   }

   public static enum HoleType {
      SINGLE,
      DOUBLE,
      CUSTOM,
      NONE;
   }

   public static enum BlockSafety {
      UNBREAKABLE,
      RESISTANT,
      BREAKABLE;
   }
}
