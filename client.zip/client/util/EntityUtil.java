package client.util;

import client.Client;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockDeadBush;
import net.minecraft.block.BlockFire;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockSnow;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.entity.passive.EntityAmbientCreature;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.entity.projectile.EntityShulkerBullet;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.CombatRules;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.MovementInput;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraft.world.Explosion;

public class EntityUtil implements Util {
   public static final Vec3d[] antiDropOffsetList = new Vec3d[]{new Vec3d(0.0D, -2.0D, 0.0D)};
   public static final Vec3d[] platformOffsetList = new Vec3d[]{new Vec3d(0.0D, -1.0D, 0.0D), new Vec3d(0.0D, -1.0D, -1.0D), new Vec3d(0.0D, -1.0D, 1.0D), new Vec3d(-1.0D, -1.0D, 0.0D), new Vec3d(1.0D, -1.0D, 0.0D)};
   public static final Vec3d[] legOffsetList = new Vec3d[]{new Vec3d(-1.0D, 0.0D, 0.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(0.0D, 0.0D, 1.0D)};
   public static final Vec3d[] OffsetList = new Vec3d[]{new Vec3d(1.0D, 1.0D, 0.0D), new Vec3d(-1.0D, 1.0D, 0.0D), new Vec3d(0.0D, 1.0D, 1.0D), new Vec3d(0.0D, 1.0D, -1.0D), new Vec3d(0.0D, 2.0D, 0.0D)};
   public static final Vec3d[] antiStepOffsetList = new Vec3d[]{new Vec3d(-1.0D, 3.0D, 0.0D), new Vec3d(1.0D, 3.0D, 0.0D), new Vec3d(0.0D, 3.0D, 1.0D), new Vec3d(0.0D, 3.0D, -1.0D)};
   public static final Vec3d[] antiScaffoldOffsetList = new Vec3d[]{new Vec3d(1.0D, -1.0D, 0.0D), new Vec3d(-1.0D, -1.0D, 0.0D), new Vec3d(0.0D, -1.0D, 1.0D), new Vec3d(0.0D, -1.0D, -1.0D), new Vec3d(0.0D, 3.0D, 0.0D)};

   public static Color getColor(Entity entity, int red, int green, int blue, int alpha, boolean colorFriends) {
      Color color = new Color((float)red / 255.0F, (float)green / 255.0F, (float)blue / 255.0F, (float)alpha / 255.0F);
      if (entity instanceof EntityPlayer && colorFriends && Client.friendManager.isFriend((EntityPlayer)entity)) {
         color = new Color(0.33333334F, 1.0F, 1.0F, (float)alpha / 255.0F);
      }

      return color;
   }

   public static boolean onMovementInput() {
      return mc.field_71439_g.field_71158_b.field_192832_b != 0.0F || mc.field_71439_g.field_71158_b.field_78902_a != 0.0F;
   }

   public double getSpeed() {
      return Math.hypot(mc.field_71439_g.field_70159_w, mc.field_71439_g.field_70179_y);
   }

   public void setSpeed(double speed) {
      EntityPlayerSP player = mc.field_71439_g;
      player.field_70159_w = -(Math.sin(getDirection()) * speed);
      player.field_70179_y = Math.cos(getDirection()) * speed;
   }

   public static double getMovementSpeed() {
      return !mc.field_71439_g.func_70644_a(MobEffects.field_76424_c) ? getBaseMovementSpeed() : getBaseMovementSpeed() * 1.0D + 0.06D * (double)(((PotionEffect)Objects.requireNonNull(mc.field_71439_g.func_70660_b(MobEffects.field_76424_c))).func_76458_c() + 1);
   }

   public static double getBaseMovementSpeed() {
      if (mc.field_71439_g.func_70093_af()) {
         return 0.064755D;
      } else {
         return mc.field_71439_g.func_70051_ag() ? 0.2806D : 0.21585D;
      }
   }

   public static double getDirection() {
      EntityPlayerSP player = mc.field_71439_g;
      float direction = player.field_70177_z;
      if (player.field_191988_bg < 0.0F) {
         direction += 180.0F;
      }

      float forward = player.field_191988_bg < 0.0F ? -0.5F : (player.field_191988_bg > 0.0F ? 0.5F : 1.0F);
      if (player.field_70702_br > 0.0F) {
         direction -= 90.0F * forward;
      } else if (player.field_70702_br < 0.0F) {
         direction += 90.0F * forward;
      }

      return (double)(direction * 0.017453292F);
   }

   public static boolean isInLiquid() {
      if (mc.field_71439_g == null) {
         return false;
      } else if (mc.field_71439_g.field_70143_R >= 3.0F) {
         return false;
      } else {
         boolean inLiquid = false;
         AxisAlignedBB bb = mc.field_71439_g.func_184187_bx() != null ? mc.field_71439_g.func_184187_bx().func_174813_aQ() : mc.field_71439_g.func_174813_aQ();
         int y = (int)bb.field_72338_b;

         for(int x = MathHelper.func_76128_c(bb.field_72340_a); x < MathHelper.func_76128_c(bb.field_72336_d) + 1; ++x) {
            for(int z = MathHelper.func_76128_c(bb.field_72339_c); z < MathHelper.func_76128_c(bb.field_72334_f) + 1; ++z) {
               Block block = mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
               if (!(block instanceof BlockAir)) {
                  if (!(block instanceof BlockLiquid)) {
                     return false;
                  }

                  inLiquid = true;
               }
            }
         }

         return inLiquid;
      }
   }

   public static boolean isOnLiquid(double offset) {
      if (mc.field_71439_g.field_70143_R >= 3.0F) {
         return false;
      } else {
         AxisAlignedBB bb = mc.field_71439_g.func_184187_bx() != null ? mc.field_71439_g.func_184187_bx().func_174813_aQ().func_191195_a(0.0D, 0.0D, 0.0D).func_72317_d(0.0D, -offset, 0.0D) : mc.field_71439_g.func_174813_aQ().func_191195_a(0.0D, 0.0D, 0.0D).func_72317_d(0.0D, -offset, 0.0D);
         boolean onLiquid = false;
         int y = (int)bb.field_72338_b;

         for(int x = MathHelper.func_76128_c(bb.field_72340_a); x < MathHelper.func_76128_c(bb.field_72336_d + 1.0D); ++x) {
            for(int z = MathHelper.func_76128_c(bb.field_72339_c); z < MathHelper.func_76128_c(bb.field_72334_f + 1.0D); ++z) {
               Block block = mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
               if (block != Blocks.field_150350_a) {
                  if (!(block instanceof BlockLiquid)) {
                     return false;
                  }

                  onLiquid = true;
               }
            }
         }

         return onLiquid;
      }
   }

   public static boolean checkCollide() {
      return !mc.field_71439_g.func_70093_af() && (mc.field_71439_g.func_184187_bx() == null || mc.field_71439_g.func_184187_bx().field_70143_R < 3.0F) && mc.field_71439_g.field_70143_R < 3.0F;
   }

   public static int getItemDamage(ItemStack stack) {
      return stack.func_77958_k() - stack.func_77952_i();
   }

   public static float getDamageInPercent(ItemStack stack) {
      return (float)getItemDamage(stack) / (float)stack.func_77958_k() * 100.0F;
   }

   public static int getRoundedDamage(ItemStack stack) {
      return (int)getDamageInPercent(stack);
   }

   public static float calculateDamage(double posX, double posY, double posZ, Entity entity) {
      float doubleExplosionSize = 12.0F;
      double distancedsize = entity.func_70011_f(posX, posY, posZ) / 12.0D;
      Vec3d vec3d = new Vec3d(posX, posY, posZ);
      double blockDensity = 0.0D;

      try {
         blockDensity = (double)entity.field_70170_p.func_72842_a(vec3d, entity.func_174813_aQ());
      } catch (Exception var18) {
         ;
      }

      double v = (1.0D - distancedsize) * blockDensity;
      float damage = (float)((int)((v * v + v) / 2.0D * 7.0D * 12.0D + 1.0D));
      double finald = 1.0D;
      if (entity instanceof EntityLivingBase) {
         finald = (double)getBlastReduction((EntityLivingBase)entity, getDamageMultiplied(damage), new Explosion(mc.field_71441_e, (Entity)null, posX, posY, posZ, 6.0F, false, true));
      }

      return (float)finald;
   }

   public static BlockPos getPlayerPosWithEntity() {
      return new BlockPos(mc.field_71439_g.func_184187_bx() != null ? mc.field_71439_g.func_184187_bx().field_70165_t : mc.field_71439_g.field_70165_t, mc.field_71439_g.func_184187_bx() != null ? mc.field_71439_g.func_184187_bx().field_70163_u : mc.field_71439_g.field_70163_u, mc.field_71439_g.func_184187_bx() != null ? mc.field_71439_g.func_184187_bx().field_70161_v : mc.field_71439_g.field_70161_v);
   }

   public static boolean isMobAggressive(Entity entity) {
      if (entity instanceof EntityPigZombie) {
         if (((EntityPigZombie)entity).func_184734_db() || ((EntityPigZombie)entity).func_175457_ck()) {
            return true;
         }
      } else {
         if (entity instanceof EntityWolf) {
            return ((EntityWolf)entity).func_70919_bu() && !mc.field_71439_g.equals(((EntityWolf)entity).func_70902_q());
         }

         if (entity instanceof EntityEnderman) {
            return ((EntityEnderman)entity).func_70823_r();
         }
      }

      return isHostileMob(entity);
   }

   public static boolean isNeutralMob(Entity entity) {
      return entity instanceof EntityPigZombie || entity instanceof EntityWolf || entity instanceof EntityEnderman;
   }

   public static boolean isProjectile(Entity entity) {
      return entity instanceof EntityShulkerBullet || entity instanceof EntityFireball;
   }

   public static boolean isVehicle(Entity entity) {
      return entity instanceof EntityBoat || entity instanceof EntityMinecart;
   }

   public static boolean isHostileMob(Entity entity) {
      return entity.isCreatureType(EnumCreatureType.MONSTER, false) && !isNeutralMob(entity);
   }

   public static boolean isPassive(Entity entity) {
      if (entity instanceof EntityWolf && ((EntityWolf)entity).func_70919_bu()) {
         return false;
      } else if (!(entity instanceof EntityAgeable) && !(entity instanceof EntityAmbientCreature) && !(entity instanceof EntitySquid)) {
         return entity instanceof EntityIronGolem && ((EntityIronGolem)entity).func_70643_av() == null;
      } else {
         return true;
      }
   }

   public static boolean canEntityFeetBeSeen(Entity entityIn) {
      return mc.field_71441_e.func_147447_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70165_t + (double)mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(entityIn.field_70165_t, entityIn.field_70163_u, entityIn.field_70161_v), false, true, false) == null;
   }

   public static int getCooldownByWeapon(EntityPlayer player) {
      Item item = player.func_184614_ca().func_77973_b();
      if (item instanceof ItemSword) {
         return 600;
      } else if (item instanceof ItemPickaxe) {
         return 850;
      } else if (item == Items.field_151036_c) {
         return 1100;
      } else if (item == Items.field_151018_J) {
         return 500;
      } else if (item == Items.field_151019_K) {
         return 350;
      } else if (item != Items.field_151053_p && item != Items.field_151049_t) {
         return !(item instanceof ItemSpade) && item != Items.field_151006_E && item != Items.field_151056_x && item != Items.field_151017_I && item != Items.field_151013_M ? 250 : 1000;
      } else {
         return 1250;
      }
   }

   public static boolean holdingWeapon(EntityPlayer player) {
      return player.func_184614_ca().func_77973_b() instanceof ItemSword || player.func_184614_ca().func_77973_b() instanceof ItemAxe;
   }

   public static boolean isTrapped(EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
      return getUntrappedBlocks(player, antiScaffold, antiStep, legs, platform, antiDrop).size() == 0;
   }

   public static Vec3d[] getTrapOffsets(boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
      List offsets = getTrapOffsetsList(antiScaffold, antiStep, legs, platform, antiDrop);
      Vec3d[] array = new Vec3d[offsets.size()];
      return (Vec3d[])offsets.toArray(array);
   }

   public static List getTrapOffsetsList(boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
      ArrayList offsets = new ArrayList(getOffsetList(1, false));
      offsets.add(new Vec3d(0.0D, 2.0D, 0.0D));
      if (antiScaffold) {
         offsets.add(new Vec3d(0.0D, 3.0D, 0.0D));
      }

      if (antiStep) {
         offsets.addAll(getOffsetList(2, false));
      }

      if (legs) {
         offsets.addAll(getOffsetList(0, false));
      }

      if (platform) {
         offsets.addAll(getOffsetList(-1, false));
         offsets.add(new Vec3d(0.0D, -1.0D, 0.0D));
      }

      if (antiDrop) {
         offsets.add(new Vec3d(0.0D, -2.0D, 0.0D));
      }

      return offsets;
   }

   public static List getUntrappedBlocks(EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
      ArrayList vec3ds = new ArrayList();
      if (!antiStep && getUnsafeBlocks(player, 2, false).size() == 4) {
         vec3ds.addAll(getUnsafeBlocks(player, 2, false));
      }

      for(int i = 0; i < getTrapOffsets(antiScaffold, antiStep, legs, platform, antiDrop).length; ++i) {
         Vec3d vector = getTrapOffsets(antiScaffold, antiStep, legs, platform, antiDrop)[i];
         BlockPos targetPos = (new BlockPos(player.func_174791_d())).func_177963_a(vector.field_72450_a, vector.field_72448_b, vector.field_72449_c);
         Block block = mc.field_71441_e.func_180495_p(targetPos).func_177230_c();
         if (block instanceof BlockAir || block instanceof BlockLiquid || block instanceof BlockTallGrass || block instanceof BlockFire || block instanceof BlockDeadBush || block instanceof BlockSnow) {
            vec3ds.add(vector);
         }
      }

      return vec3ds;
   }

   public static Vec3d[] convertVec3ds(Vec3d vec3d, Vec3d[] input) {
      Vec3d[] output = new Vec3d[input.length];

      for(int i = 0; i < input.length; ++i) {
         output[i] = vec3d.func_178787_e(input[i]);
      }

      return output;
   }

   public static List targets(Vec3d vec3d, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
      ArrayList placeTargets = new ArrayList();
      if (antiDrop) {
         Collections.addAll(placeTargets, convertVec3ds(vec3d, antiDropOffsetList));
      }

      if (platform) {
         Collections.addAll(placeTargets, convertVec3ds(vec3d, platformOffsetList));
      }

      if (legs) {
         Collections.addAll(placeTargets, convertVec3ds(vec3d, legOffsetList));
      }

      Collections.addAll(placeTargets, convertVec3ds(vec3d, OffsetList));
      if (antiStep) {
         Collections.addAll(placeTargets, convertVec3ds(vec3d, antiStepOffsetList));
      } else {
         List vec3ds = getUnsafeBlocksFromVec3d(vec3d, 2, false);
         if (vec3ds.size() == 4) {
            Iterator var9 = vec3ds.iterator();

            while(var9.hasNext()) {
               Vec3d vector = (Vec3d)var9.next();
               BlockPos position = (new BlockPos(vec3d)).func_177963_a(vector.field_72450_a, vector.field_72448_b, vector.field_72449_c);
               switch(BlockUtil.isPositionPlaceable(position, raytrace)) {
               case -1:
               case 1:
               case 2:
                  break;
               case 3:
                  placeTargets.add(vec3d.func_178787_e(vector));
               case 0:
               default:
                  if (antiScaffold) {
                     Collections.addAll(placeTargets, convertVec3ds(vec3d, antiScaffoldOffsetList));
                  }

                  return placeTargets;
               }
            }
         }
      }

      if (antiScaffold) {
         Collections.addAll(placeTargets, convertVec3ds(vec3d, antiScaffoldOffsetList));
      }

      return placeTargets;
   }

   public static void attackEntity(Entity entity, boolean packet, boolean swingArm) {
      if (packet) {
         mc.field_71439_g.field_71174_a.func_147297_a(new CPacketUseEntity(entity));
      } else {
         mc.field_71442_b.func_78764_a(mc.field_71439_g, entity);
      }

      if (swingArm) {
         mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
      }

   }

   public static Vec3d getInterpolatedRenderPos(Entity entity, float partialTicks) {
      return getInterpolatedPos(entity, partialTicks).func_178786_a(mc.func_175598_ae().field_78725_b, mc.func_175598_ae().field_78726_c, mc.func_175598_ae().field_78723_d);
   }

   public static Vec3d getInterpolatedPos(Entity entity, float partialTicks) {
      return (new Vec3d(entity.field_70142_S, entity.field_70137_T, entity.field_70136_U)).func_178787_e(getInterpolatedAmount(entity, partialTicks));
   }

   public static Vec3d getInterpolatedAmount(Entity entity, float partialTicks) {
      return getInterpolatedAmount(entity, (double)partialTicks, (double)partialTicks, (double)partialTicks);
   }

   public static Vec3d getInterpolatedAmount(Entity entity, double x, double y, double z) {
      return new Vec3d((entity.field_70165_t - entity.field_70142_S) * x, (entity.field_70163_u - entity.field_70137_T) * y, (entity.field_70161_v - entity.field_70136_U) * z);
   }

   public static float calculate(double posX, double posY, double posZ, EntityLivingBase entity) {
      double v = (1.0D - entity.func_70011_f(posX, posY, posZ) / 12.0D) * (double)getBlockDensity(new Vec3d(posX, posY, posZ), entity.func_174813_aQ());
      return getBlastReduction(entity, getDamageMultiplied((float)((v * v + v) / 2.0D * 85.0D + 1.0D)), new Explosion(mc.field_71441_e, (Entity)null, posX, posY, posZ, 6.0F, false, true));
   }

   public static float getBlastReduction(EntityLivingBase entity, float damageI, Explosion explosion) {
      DamageSource ds = DamageSource.func_94539_a(explosion);
      float damage = CombatRules.func_189427_a(damageI, (float)entity.func_70658_aO(), (float)entity.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
      int k = EnchantmentHelper.func_77508_a(entity.func_184193_aE(), ds);
      damage *= 1.0F - MathHelper.func_76131_a((float)k, 0.0F, 20.0F) / 25.0F;
      if (entity.func_70644_a(MobEffects.field_76429_m)) {
         damage -= damage / 4.0F;
      }

      return damage;
   }

   public static float getBlockDensity(Vec3d vec, AxisAlignedBB bb) {
      double d0 = 1.0D / ((bb.field_72336_d - bb.field_72340_a) * 2.0D + 1.0D);
      double d1 = 1.0D / ((bb.field_72337_e - bb.field_72338_b) * 2.0D + 1.0D);
      double d2 = 1.0D / ((bb.field_72334_f - bb.field_72339_c) * 2.0D + 1.0D);
      double d3 = (1.0D - Math.floor(1.0D / d0) * d0) / 2.0D;
      double d4 = (1.0D - Math.floor(1.0D / d2) * d2) / 2.0D;
      if (d0 >= 0.0D && d1 >= 0.0D && d2 >= 0.0D) {
         int j2 = 0;
         int k2 = 0;

         for(float f = 0.0F; f <= 1.0F; f = (float)((double)f + d0)) {
            for(float f1 = 0.0F; f1 <= 1.0F; f1 = (float)((double)f1 + d1)) {
               for(float f2 = 0.0F; f2 <= 1.0F; f2 = (float)((double)f2 + d2)) {
                  if (rayTraceBlocks(new Vec3d(bb.field_72340_a + (bb.field_72336_d - bb.field_72340_a) * (double)f + d3, bb.field_72338_b + (bb.field_72337_e - bb.field_72338_b) * (double)f1, bb.field_72339_c + (bb.field_72334_f - bb.field_72339_c) * (double)f2 + d4), vec, false, false, false) == null) {
                     ++j2;
                  }

                  ++k2;
               }
            }
         }

         return (float)j2 / (float)k2;
      } else {
         return 0.0F;
      }
   }

   public static RayTraceResult rayTraceBlocks(Vec3d vec31, Vec3d vec32, boolean stopOnLiquid, boolean ignoreBlockWithoutBoundingBox, boolean returnLastUncollidableBlock) {
      int i = MathHelper.func_76128_c(vec32.field_72450_a);
      int j = MathHelper.func_76128_c(vec32.field_72448_b);
      int k = MathHelper.func_76128_c(vec32.field_72449_c);
      int l = MathHelper.func_76128_c(vec31.field_72450_a);
      int i1 = MathHelper.func_76128_c(vec31.field_72448_b);
      int j1 = MathHelper.func_76128_c(vec31.field_72449_c);
      BlockPos blockpos = new BlockPos(l, i1, j1);
      IBlockState iblockstate = mc.field_71441_e.func_180495_p(blockpos);
      Block block = iblockstate.func_177230_c();
      if ((!ignoreBlockWithoutBoundingBox || iblockstate.func_185890_d(mc.field_71441_e, blockpos) != Block.field_185506_k) && block.func_176209_a(iblockstate, stopOnLiquid)) {
         return iblockstate.func_185910_a(mc.field_71441_e, blockpos, vec31, vec32);
      } else {
         RayTraceResult raytraceresult2 = null;
         int var15 = 200;

         while(var15-- >= 0) {
            if (Double.isNaN(vec31.field_72450_a) || Double.isNaN(vec31.field_72448_b) || Double.isNaN(vec31.field_72449_c)) {
               return null;
            }

            if (l == i && i1 == j && j1 == k) {
               return returnLastUncollidableBlock ? raytraceresult2 : null;
            }

            boolean flag2 = true;
            boolean flag = true;
            boolean flag1 = true;
            double d0 = 999.0D;
            double d1 = 999.0D;
            double d2 = 999.0D;
            if (i > l) {
               d0 = (double)l + 1.0D;
            } else if (i < l) {
               d0 = (double)l + 0.0D;
            } else {
               flag2 = false;
            }

            if (j > i1) {
               d1 = (double)i1 + 1.0D;
            } else if (j < i1) {
               d1 = (double)i1 + 0.0D;
            } else {
               flag = false;
            }

            if (k > j1) {
               d2 = (double)j1 + 1.0D;
            } else if (k < j1) {
               d2 = (double)j1 + 0.0D;
            } else {
               flag1 = false;
            }

            double d3 = 999.0D;
            double d4 = 999.0D;
            double d5 = 999.0D;
            double d6 = vec32.field_72450_a - vec31.field_72450_a;
            double d7 = vec32.field_72448_b - vec31.field_72448_b;
            double d8 = vec32.field_72449_c - vec31.field_72449_c;
            if (flag2) {
               d3 = (d0 - vec31.field_72450_a) / d6;
            }

            if (flag) {
               d4 = (d1 - vec31.field_72448_b) / d7;
            }

            if (flag1) {
               d5 = (d2 - vec31.field_72449_c) / d8;
            }

            if (d3 == -0.0D) {
               d3 = -1.0E-4D;
            }

            if (d4 == -0.0D) {
               d4 = -1.0E-4D;
            }

            if (d5 == -0.0D) {
               d5 = -1.0E-4D;
            }

            EnumFacing enumfacing;
            if (d3 < d4 && d3 < d5) {
               enumfacing = i > l ? EnumFacing.WEST : EnumFacing.EAST;
               vec31 = new Vec3d(d0, vec31.field_72448_b + d7 * d3, vec31.field_72449_c + d8 * d3);
            } else if (d4 < d5) {
               enumfacing = j > i1 ? EnumFacing.DOWN : EnumFacing.UP;
               vec31 = new Vec3d(vec31.field_72450_a + d6 * d4, d1, vec31.field_72449_c + d8 * d4);
            } else {
               enumfacing = k > j1 ? EnumFacing.NORTH : EnumFacing.SOUTH;
               vec31 = new Vec3d(vec31.field_72450_a + d6 * d5, vec31.field_72448_b + d7 * d5, d2);
            }

            l = MathHelper.func_76128_c(vec31.field_72450_a) - (enumfacing == EnumFacing.EAST ? 1 : 0);
            i1 = MathHelper.func_76128_c(vec31.field_72448_b) - (enumfacing == EnumFacing.UP ? 1 : 0);
            j1 = MathHelper.func_76128_c(vec31.field_72449_c) - (enumfacing == EnumFacing.SOUTH ? 1 : 0);
            blockpos = new BlockPos(l, i1, j1);
            IBlockState iblockstate1 = mc.field_71441_e.func_180495_p(blockpos);
            Block block1 = iblockstate1.func_177230_c();
            if (!ignoreBlockWithoutBoundingBox || iblockstate1.func_185904_a() == Material.field_151567_E || iblockstate1.func_185890_d(mc.field_71441_e, blockpos) != Block.field_185506_k) {
               if (block1.func_176209_a(iblockstate1, stopOnLiquid) && block1 != Blocks.field_150321_G) {
                  return iblockstate1.func_185910_a(mc.field_71441_e, blockpos, vec31, vec32);
               }

               raytraceresult2 = new RayTraceResult(Type.MISS, vec31, enumfacing, blockpos);
            }
         }

         return returnLastUncollidableBlock ? raytraceresult2 : null;
      }
   }

   public static float getDamageMultiplied(float damage) {
      int diff = mc.field_71441_e.func_175659_aa().func_151525_a();
      return damage * (diff == 0 ? 0.0F : (diff == 2 ? 1.0F : (diff == 1 ? 0.5F : 1.5F)));
   }

   public static void setTimer(float speed) {
      Minecraft.func_71410_x().field_71428_T.field_194149_e = 50.0F / speed;
   }

   public static void resetTimer() {
      Minecraft.func_71410_x().field_71428_T.field_194149_e = 50.0F;
   }

   public static double getMaxSpeed() {
      double maxModifier = 0.2873D;
      if (mc.field_71439_g.func_70644_a((Potion)Objects.requireNonNull(Potion.func_188412_a(1)))) {
         maxModifier *= 1.0D + 0.2D * (double)(((PotionEffect)Objects.requireNonNull(mc.field_71439_g.func_70660_b((Potion)Objects.requireNonNull(Potion.func_188412_a(1))))).func_76458_c() + 1);
      }

      return maxModifier;
   }

   public static boolean isEntityMoving(Entity entity) {
      if (entity == null) {
         return false;
      } else if (entity instanceof EntityPlayer) {
         return mc.field_71474_y.field_74351_w.func_151470_d() || mc.field_71474_y.field_74368_y.func_151470_d() || mc.field_71474_y.field_74370_x.func_151470_d() || mc.field_71474_y.field_74366_z.func_151470_d();
      } else {
         return entity.field_70159_w != 0.0D || entity.field_70181_x != 0.0D || entity.field_70179_y != 0.0D;
      }
   }

   public static Vec3d[] getUnsafeBlockArray(Entity entity, int height, boolean floor) {
      List list = getUnsafeBlocks(entity, height, floor);
      Vec3d[] array = new Vec3d[list.size()];
      return (Vec3d[])list.toArray(array);
   }

   public static BlockPos getRoundedBlockPos(Entity entity) {
      return new BlockPos(MathUtil.roundVec(entity.func_174791_d(), 0));
   }

   public static Vec3d[] getUnsafeBlockArrayFromVec3d(Vec3d pos, int height, boolean floor) {
      List list = getUnsafeBlocksFromVec3d(pos, height, floor);
      Vec3d[] array = new Vec3d[list.size()];
      return (Vec3d[])list.toArray(array);
   }

   public static boolean stopSneaking(boolean isSneaking) {
      if (isSneaking && mc.field_71439_g != null) {
         mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.STOP_SNEAKING));
      }

      return false;
   }

   public static EntityPlayer getTarget(float range) {
      EntityPlayer currentTarget = null;
      int size = mc.field_71441_e.field_73010_i.size();

      for(int i = 0; i < size; ++i) {
         EntityPlayer player = (EntityPlayer)mc.field_71441_e.field_73010_i.get(i);
         if (!isntValid(player, (double)range)) {
            if (currentTarget == null) {
               currentTarget = player;
            } else if (mc.field_71439_g.func_70068_e(player) < mc.field_71439_g.func_70068_e(currentTarget)) {
               currentTarget = player;
            }
         }
      }

      return currentTarget;
   }

   public static EntityPlayer getTarget2(float range) {
      EntityPlayer currentTarget = null;
      int size = mc.field_71441_e.field_73010_i.size();

      for(int i = 0; i < size; ++i) {
         EntityPlayer player = (EntityPlayer)mc.field_71441_e.field_73010_i.get(i);
         if (!isntValid(player, (double)range)) {
            if (currentTarget == null) {
               currentTarget = player;
            } else if (mc.field_71439_g.func_70068_e(player) < mc.field_71439_g.func_70068_e(currentTarget)) {
               currentTarget = player;
            }
         }
      }

      return currentTarget;
   }

   public static EntityPlayer getTargetDouble(double range) {
      EntityPlayer currentTarget = null;
      int size = mc.field_71441_e.field_73010_i.size();

      for(int i = 0; i < size; ++i) {
         EntityPlayer player = (EntityPlayer)mc.field_71441_e.field_73010_i.get(i);
         if (!isntValid(player, range)) {
            if (currentTarget == null) {
               currentTarget = player;
            } else if (mc.field_71439_g.func_70068_e(player) < mc.field_71439_g.func_70068_e(currentTarget)) {
               currentTarget = player;
            }
         }
      }

      return currentTarget;
   }

   public static boolean basicChecksEntity(Entity pl) {
      return pl.func_70005_c_().equals(mc.field_71439_g.func_70005_c_()) || pl.field_70128_L;
   }

   public static List getSphere(BlockPos loc, float r, int h, boolean hollow, boolean sphere, int plusY) {
      List circleBlocks = new ArrayList();
      int cx = loc.func_177958_n();
      int cy = loc.func_177956_o();
      int cz = loc.func_177952_p();

      for(int x = cx - (int)r; (float)x <= (float)cx + r; ++x) {
         for(int z = cz - (int)r; (float)z <= (float)cz + r; ++z) {
            for(int y = sphere ? cy - (int)r : cy; (float)y < (sphere ? (float)cy + r : (float)(cy + h)); ++y) {
               double dist = (double)((cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? (cy - y) * (cy - y) : 0));
               if (dist < (double)(r * r) && (!hollow || dist >= (double)((r - 1.0F) * (r - 1.0F)))) {
                  BlockPos l = new BlockPos(x, y + plusY, z);
                  circleBlocks.add(l);
               }
            }
         }
      }

      return circleBlocks;
   }

   public static boolean isntValid(Entity entity, double range) {
      return entity == null || isDead(entity) || entity.equals(mc.field_71439_g) || entity instanceof EntityPlayer && Client.friendManager.isFriend(entity.func_70005_c_()) || mc.field_71439_g.func_70068_e(entity) > MathUtil.square(range);
   }

   public static boolean isInHole(Entity entity) {
      return isBlockValid(new BlockPos(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v));
   }

   public static boolean isBlockValid(BlockPos blockPos) {
      return isBedrockHole(blockPos) || isObbyHole(blockPos) || isBothHole(blockPos);
   }

   public static boolean isObbyHole(BlockPos blockPos) {
      BlockPos[] var2 = new BlockPos[]{blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b()};
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         BlockPos pos = var2[var4];
         IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
         if (touchingState.func_177230_c() == Blocks.field_150350_a || touchingState.func_177230_c() != Blocks.field_150343_Z) {
            return false;
         }
      }

      return true;
   }

   public static boolean isBedrockHole(BlockPos blockPos) {
      BlockPos[] var2 = new BlockPos[]{blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b()};
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         BlockPos pos = var2[var4];
         IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
         if (touchingState.func_177230_c() == Blocks.field_150350_a || touchingState.func_177230_c() != Blocks.field_150357_h) {
            return false;
         }
      }

      return true;
   }

   public static boolean isBothHole(BlockPos blockPos) {
      BlockPos[] var2 = new BlockPos[]{blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b()};
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         BlockPos pos = var2[var4];
         IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
         if (touchingState.func_177230_c() == Blocks.field_150350_a || touchingState.func_177230_c() != Blocks.field_150357_h && touchingState.func_177230_c() != Blocks.field_150343_Z) {
            return false;
         }
      }

      return true;
   }

   public static boolean isSafe(Entity entity, int height, boolean floor) {
      return getUnsafeBlocks(entity, height, floor).size() == 0;
   }

   public static List getUnsafeBlocks(Entity entity, int height, boolean floor) {
      return getUnsafeBlocksFromVec3d(entity.func_174791_d(), height, floor);
   }

   public static boolean isSafe(Entity entity) {
      return isSafe(entity, 0, false);
   }

   public static Vec3d interpolateEntity(Entity entity, float time) {
      return new Vec3d(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)time, entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)time, entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)time);
   }

   public static BlockPos getPlayerPos(EntityPlayer player) {
      return new BlockPos(Math.floor(player.field_70165_t), Math.floor(player.field_70163_u), Math.floor(player.field_70161_v));
   }

   public static List getUnsafeBlocksFromVec3d(Vec3d pos, int height, boolean floor) {
      ArrayList vec3ds = new ArrayList();
      Vec3d[] var4 = getOffsets(height, floor);
      int var5 = var4.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         Vec3d vector = var4[var6];
         BlockPos targetPos = (new BlockPos(pos)).func_177963_a(vector.field_72450_a, vector.field_72448_b, vector.field_72449_c);
         Block block = mc.field_71441_e.func_180495_p(targetPos).func_177230_c();
         if (block instanceof BlockAir || block instanceof BlockLiquid || block instanceof BlockTallGrass || block instanceof BlockFire || block instanceof BlockDeadBush || block instanceof BlockSnow) {
            vec3ds.add(vector);
         }
      }

      return vec3ds;
   }

   public static double getEntitySpeed(Entity entity) {
      if (entity != null) {
         double distTraveledLastTickX = entity.field_70165_t - entity.field_70169_q;
         double distTraveledLastTickZ = entity.field_70161_v - entity.field_70166_s;
         double speed = (double)MathHelper.func_76133_a(distTraveledLastTickX * distTraveledLastTickX + distTraveledLastTickZ * distTraveledLastTickZ);
         return speed * 20.0D;
      } else {
         return 0.0D;
      }
   }

   public static void moveEntityStrafe(double speed, Entity entity) {
      if (entity != null) {
         MovementInput movementInput = mc.field_71439_g.field_71158_b;
         double forward = (double)movementInput.field_192832_b;
         double strafe = (double)movementInput.field_78902_a;
         float yaw = mc.field_71439_g.field_70177_z;
         if (forward == 0.0D && strafe == 0.0D) {
            entity.field_70159_w = 0.0D;
            entity.field_70179_y = 0.0D;
         } else {
            if (forward != 0.0D) {
               if (strafe > 0.0D) {
                  yaw += (float)(forward > 0.0D ? -45 : 45);
               } else if (strafe < 0.0D) {
                  yaw += (float)(forward > 0.0D ? 45 : -45);
               }

               strafe = 0.0D;
               if (forward > 0.0D) {
                  forward = 1.0D;
               } else if (forward < 0.0D) {
                  forward = -1.0D;
               }
            }

            entity.field_70159_w = forward * speed * Math.cos(Math.toRadians((double)(yaw + 90.0F))) + strafe * speed * Math.sin(Math.toRadians((double)(yaw + 90.0F)));
            entity.field_70179_y = forward * speed * Math.sin(Math.toRadians((double)(yaw + 90.0F))) - strafe * speed * Math.cos(Math.toRadians((double)(yaw + 90.0F)));
         }
      }

   }

   public static List getOffsetList(int y, boolean floor) {
      ArrayList offsets = new ArrayList();
      offsets.add(new Vec3d(-1.0D, (double)y, 0.0D));
      offsets.add(new Vec3d(1.0D, (double)y, 0.0D));
      offsets.add(new Vec3d(0.0D, (double)y, -1.0D));
      offsets.add(new Vec3d(0.0D, (double)y, 1.0D));
      if (floor) {
         offsets.add(new Vec3d(0.0D, (double)(y - 1), 0.0D));
      }

      return offsets;
   }

   public static Vec3d[] getOffsets(int y, boolean floor) {
      List offsets = getOffsetList(y, floor);
      Vec3d[] array = new Vec3d[offsets.size()];
      return (Vec3d[])offsets.toArray(array);
   }

   public static Vec3d[] getHeightOffsets(int min, int max) {
      ArrayList offsets = new ArrayList();

      for(int i = min; i <= max; ++i) {
         offsets.add(new Vec3d(0.0D, (double)i, 0.0D));
      }

      Vec3d[] array = new Vec3d[offsets.size()];
      return (Vec3d[])offsets.toArray(array);
   }

   public static boolean isLiving(Entity entity) {
      return entity instanceof EntityLivingBase;
   }

   public static boolean isAlive(Entity entity) {
      return isLiving(entity) && !entity.field_70128_L && ((EntityLivingBase)entity).func_110143_aJ() > 0.0F;
   }

   public static boolean isDead(Entity entity) {
      return !isAlive(entity);
   }

   public static float getHealth(Entity entity) {
      if (isLiving(entity)) {
         EntityLivingBase livingBase = (EntityLivingBase)entity;
         return livingBase.func_110143_aJ() + livingBase.func_110139_bj();
      } else {
         return 0.0F;
      }
   }

   public static float getHealth(Entity entity, boolean absorption) {
      if (isLiving(entity)) {
         EntityLivingBase livingBase = (EntityLivingBase)entity;
         return livingBase.func_110143_aJ() + (absorption ? livingBase.func_110139_bj() : 0.0F);
      } else {
         return 0.0F;
      }
   }

   public static Vec3d calculateLine(Vec3d x1, Vec3d x2, double distance) {
      double length = Math.sqrt(multiply(x2.field_72450_a - x1.field_72450_a) + multiply(x2.field_72448_b - x1.field_72448_b) + multiply(x2.field_72449_c - x1.field_72449_c));
      double unitSlopeX = (x2.field_72450_a - x1.field_72450_a) / length;
      double unitSlopeY = (x2.field_72448_b - x1.field_72448_b) / length;
      double unitSlopeZ = (x2.field_72449_c - x1.field_72449_c) / length;
      double x = x1.field_72450_a + unitSlopeX * distance;
      double y = x1.field_72448_b + unitSlopeY * distance;
      double z = x1.field_72449_c + unitSlopeZ * distance;
      return new Vec3d(x, y, z);
   }

   public static Vec2f calculateLineNoY(Vec2f x1, Vec2f x2, double distance) {
      double length = Math.sqrt(multiply((double)(x2.field_189982_i - x1.field_189982_i)) + multiply((double)(x2.field_189983_j - x1.field_189983_j)));
      double unitSlopeX = (double)(x2.field_189982_i - x1.field_189982_i) / length;
      double unitSlopeZ = (double)(x2.field_189983_j - x1.field_189983_j) / length;
      float x = (float)((double)x1.field_189982_i + unitSlopeX * distance);
      float z = (float)((double)x1.field_189983_j + unitSlopeZ * distance);
      return new Vec2f(x, z);
   }

   public static double multiply(double one) {
      return one * one;
   }

   public static Vec3d extrapolatePlayerPositionWithGravity(EntityPlayer player, int ticks) {
      double totalDistance = 0.0D;
      double extrapolatedMotionY = player.field_70181_x;

      for(int i = 0; i < ticks; ++i) {
         totalDistance += multiply(player.field_70159_w) + multiply(extrapolatedMotionY) + multiply(player.field_70179_y);
         extrapolatedMotionY -= 0.1D;
      }

      double horizontalDistance = multiply(player.field_70159_w) + multiply(player.field_70179_y) * (double)ticks;
      Vec2f horizontalVec = calculateLineNoY(new Vec2f((float)player.field_70142_S, (float)player.field_70136_U), new Vec2f((float)player.field_70165_t, (float)player.field_70161_v), horizontalDistance);
      double addedY = player.field_70181_x;
      double finalY = player.field_70163_u;
      Vec3d tempPos = new Vec3d((double)horizontalVec.field_189982_i, player.field_70163_u, (double)horizontalVec.field_189983_j);

      for(int i = 0; i < ticks; ++i) {
         finalY += addedY;
         addedY -= 0.1D;
      }

      RayTraceResult result = mc.field_71441_e.func_72933_a(player.func_174791_d(), new Vec3d(tempPos.field_72450_a, finalY, tempPos.field_72449_c));
      return result != null && result.field_72313_a != Type.ENTITY ? result.field_72307_f : new Vec3d(tempPos.field_72450_a, finalY, tempPos.field_72449_c);
   }

   public static Vec3d extrapolatePlayerPosition(EntityPlayer player, int ticks) {
      double totalDistance = 0.0D;
      double extrapolatedMotionY = player.field_70181_x;

      for(int i = 0; i < ticks; ++i) {
         ;
      }

      Vec3d lastPos = new Vec3d(player.field_70142_S, player.field_70137_T, player.field_70136_U);
      Vec3d currentPos = new Vec3d(player.field_70165_t, player.field_70163_u, player.field_70161_v);
      double distance = multiply(player.field_70159_w) + multiply(player.field_70181_x) + multiply(player.field_70179_y);
      double extrapolatedPosY = player.field_70163_u;
      if (!player.func_189652_ae()) {
         extrapolatedPosY -= 0.1D;
      }

      Vec3d tempVec = calculateLine(lastPos, currentPos, distance * (double)ticks);
      Vec3d finalVec = new Vec3d(tempVec.field_72450_a, extrapolatedPosY, tempVec.field_72449_c);
      RayTraceResult result = mc.field_71441_e.func_72933_a(player.func_174791_d(), finalVec);
      return new Vec3d(tempVec.field_72450_a, player.field_70163_u, tempVec.field_72449_c);
   }

   public static boolean isMoving() {
      return (double)mc.field_71439_g.field_191988_bg != 0.0D || (double)mc.field_71439_g.field_70702_br != 0.0D;
   }

   public static Map getTextRadarPlayers() {
      Map output = new HashMap();
      DecimalFormat dfHealth = new DecimalFormat("#.#");
      dfHealth.setRoundingMode(RoundingMode.CEILING);
      DecimalFormat dfDistance = new DecimalFormat("#.#");
      dfDistance.setRoundingMode(RoundingMode.CEILING);
      StringBuilder healthSB = new StringBuilder();
      StringBuilder distanceSB = new StringBuilder();
      Iterator var5 = mc.field_71441_e.field_73010_i.iterator();

      while(var5.hasNext()) {
         EntityPlayer player = (EntityPlayer)var5.next();
         if (!player.func_82150_aj() && !player.func_70005_c_().equals(mc.field_71439_g.func_70005_c_())) {
            int hpRaw = (int)getHealth(player);
            String hp = dfHealth.format((long)hpRaw);
            healthSB.append("Â§");
            if (hpRaw >= 20) {
               healthSB.append("a");
            } else if (hpRaw >= 10) {
               healthSB.append("e");
            } else if (hpRaw >= 5) {
               healthSB.append("6");
            } else {
               healthSB.append("c");
            }

            healthSB.append(hp);
            int distanceInt = (int)mc.field_71439_g.func_70032_d(player);
            String distance = dfDistance.format((long)distanceInt);
            distanceSB.append("Â§");
            if (distanceInt >= 25) {
               distanceSB.append("a");
            } else if (distanceInt > 10) {
               distanceSB.append("6");
            } else {
               distanceSB.append("c");
            }

            distanceSB.append(distance);
            ((Map)output).put(healthSB + " " + (Client.friendManager.isFriend(player) ? ChatFormatting.AQUA : ChatFormatting.RED) + player.func_70005_c_() + " " + distanceSB + " Â§f0", (int)mc.field_71439_g.func_70032_d(player));
            healthSB.setLength(0);
            distanceSB.setLength(0);
         }
      }

      if (!((Map)output).isEmpty()) {
         output = MathUtil.sortByValue((Map)output, false);
      }

      return (Map)output;
   }

   public static boolean isMoving(EntityLivingBase entity) {
      return entity.field_191988_bg != 0.0F || entity.field_70702_br != 0.0F;
   }

   public static void setSpeed(EntityLivingBase entity, double speed) {
      double[] dir = forward(speed);
      entity.field_70159_w = dir[0];
      entity.field_70179_y = dir[1];
   }

   public static double getBaseMoveSpeed() {
      double baseSpeed = 0.2873D;
      if (mc.field_71439_g != null && mc.field_71439_g.func_70644_a((Potion)Objects.requireNonNull(Potion.func_188412_a(1)))) {
         int amplifier = ((PotionEffect)Objects.requireNonNull(Objects.requireNonNull(mc.field_71439_g.func_70660_b((Potion)Objects.requireNonNull(Potion.func_188412_a(1)))))).func_76458_c();
         baseSpeed *= 1.0D + 0.2D * (double)(amplifier + 1);
      }

      return baseSpeed;
   }

   public static double getSpeed(EntityLivingBase entity) {
      return Math.sqrt(entity.field_70159_w * entity.field_70159_w + entity.field_70179_y * entity.field_70179_y);
   }

   public static double[] forward(double speed) {
      float forward = mc.field_71439_g.field_71158_b.field_192832_b;
      float side = mc.field_71439_g.field_71158_b.field_78902_a;
      float yaw = mc.field_71439_g.field_70126_B + (mc.field_71439_g.field_70177_z - mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
      if (forward != 0.0F) {
         if (side > 0.0F) {
            yaw += (float)(forward > 0.0F ? -45 : 45);
         } else if (side < 0.0F) {
            yaw += (float)(forward > 0.0F ? 45 : -45);
         }

         side = 0.0F;
         if (forward > 0.0F) {
            forward = 1.0F;
         } else if (forward < 0.0F) {
            forward = -1.0F;
         }
      }

      double sin = Math.sin(Math.toRadians((double)(yaw + 90.0F)));
      double cos = Math.cos(Math.toRadians((double)(yaw + 90.0F)));
      double posX = (double)forward * speed * cos + (double)side * speed * sin;
      double posZ = (double)forward * speed * sin - (double)side * speed * cos;
      return new double[]{posX, posZ};
   }
}
