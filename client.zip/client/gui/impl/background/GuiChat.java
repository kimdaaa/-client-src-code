package client.gui.impl.background;

import client.Client;
import client.modules.miscellaneous.ChatModifications;
import client.util.MathUtil;
import client.util.Timer;
import client.util.Util;
import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ChatLine;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.gui.GuiUtilRenderComponents;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer.EnumChatVisibility;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.apache.logging.log4j.Logger;

@SideOnly(Side.CLIENT)
public class GuiChat extends GuiNewChat implements Util {
   private static final Logger LOGGER;
   private final Minecraft mc;
   private final Timer messageTimer = new Timer();
   private final List sentMessages = Lists.newArrayList();
   private final List chatLines = Lists.newArrayList();
   private final List drawnChatLines = Lists.newArrayList();
   private int scrollPos;
   private boolean isScrolled;
   public static float percentComplete;
   public static int newLines;
   public static long prevMillis;
   public static int messageAdd;
   public boolean configuring;

   public GuiChat(Minecraft mcIn) {
      super(mcIn);
      this.mc = mcIn;
   }

   public static void updatePercentage(long diff) {
      if (percentComplete < 1.0F) {
         percentComplete += 0.004F * (float)diff;
      }

      percentComplete = MathUtil.clamp(percentComplete, 0.0F, 1.0F);
   }

   public void func_146230_a(int updateCounter) {
      if (!this.configuring) {
         if (prevMillis == -1L) {
            prevMillis = System.currentTimeMillis();
         } else {
            long current = System.currentTimeMillis();
            long diff = current - prevMillis;
            prevMillis = current;
            updatePercentage(diff);
            float t = percentComplete;
            float percent = 1.0F - --t * t * t * t;
            percent = MathUtil.clamp(percent, 0.0F, 1.0F);
            if (this.mc.field_71474_y.field_74343_n != EnumChatVisibility.HIDDEN) {
               int i = this.func_146232_i();
               int j = this.drawnChatLines.size();
               float f = this.mc.field_71474_y.field_74357_r * 0.9F + 0.1F;
               if (j > 0) {
                  boolean flag = this.func_146241_e();
                  float f1 = this.func_146244_h();
                  GlStateManager.func_179094_E();
                  if (ChatModifications.getInstance().isOn() && ((Boolean)ChatModifications.getInstance().smoothChat.getCurrentState()).booleanValue() && ChatModifications.getInstance().type.getCurrentState() == ChatModifications.Type.VERTICAL && !this.isScrolled) {
                     GlStateManager.func_179109_b(2.0F + ((Double)ChatModifications.getInstance().xOffset.getCurrentState()).floatValue(), 8.0F + ((Double)ChatModifications.getInstance().yOffset.getCurrentState()).floatValue() + (9.0F - 9.0F * percent) * f1, 0.0F);
                  } else {
                     GlStateManager.func_179109_b(2.0F + ((Double)ChatModifications.getInstance().xOffset.getCurrentState()).floatValue(), 8.0F + ((Double)ChatModifications.getInstance().yOffset.getCurrentState()).floatValue(), 0.0F);
                  }

                  GlStateManager.func_179152_a(f1, f1, 1.0F);
                  int l = 0;

                  int i1;
                  int j1;
                  int l1;
                  for(i1 = 0; i1 + this.scrollPos < this.drawnChatLines.size() && i1 < i; ++i1) {
                     ChatLine chatline = (ChatLine)this.drawnChatLines.get(i1 + this.scrollPos);
                     if (chatline != null) {
                        j1 = updateCounter - chatline.func_74540_b();
                        if (j1 < 200 || flag) {
                           double d0 = (double)j1 / 200.0D;
                           d0 = 1.0D - d0;
                           d0 *= 10.0D;
                           d0 = MathHelper.func_151237_a(d0, 0.0D, 1.0D);
                           d0 *= d0;
                           l1 = (int)(255.0D * d0);
                           if (flag) {
                              l1 = 255;
                           }

                           l1 = (int)((float)l1 * f);
                           ++l;
                           if (l1 > 3) {
                              int i2 = 0;
                              int j2 = -i1 * 9;
                              String s = chatline.func_151461_a().func_150254_d();
                              GlStateManager.func_179147_l();
                              if (((Boolean)ChatModifications.getInstance().smoothChat.getCurrentState()).booleanValue() && i1 <= newLines) {
                                 if (this.messageTimer.passedMs((long)((Double)ChatModifications.getInstance().vSpeed.getCurrentState()).intValue()) && messageAdd < 0) {
                                    messageAdd += ((Double)ChatModifications.getInstance().vIncrements.getCurrentState()).intValue();
                                    if (messageAdd > 0) {
                                       messageAdd = 0;
                                    }

                                    this.messageTimer.reset();
                                 }

                                 this.mc.field_71466_p.func_175063_a(s, 0.0F + (float)(ChatModifications.getInstance().type.getCurrentState() == ChatModifications.Type.HORIZONTAL ? messageAdd : 0), (float)(j2 - 8), 16777215 + (l1 << 24));
                              } else {
                                 this.mc.field_71466_p.func_175063_a(s, (float)i2, (float)(j2 - 8), 16777215 + (l1 << 24));
                              }

                              GlStateManager.func_179118_c();
                              GlStateManager.func_179084_k();
                           }
                        }
                     }
                  }

                  if (flag) {
                     i1 = this.mc.field_71466_p.field_78288_b;
                     GlStateManager.func_179109_b(-3.0F, 0.0F, 0.0F);
                     int l2 = j * i1 + j;
                     j1 = l * i1 + l;
                     int j3 = this.scrollPos * j1 / j;
                     int k1 = j1 * j1 / l2;
                     if (l2 != j1) {
                        l1 = j3 > 0 ? 170 : 96;
                        int l3 = this.isScrolled ? 13382451 : 3355562;
                        Gui.func_73734_a(0, -j3, 2, -j3 - k1, l3 + (l1 << 24));
                        Gui.func_73734_a(2, -j3, 1, -j3 - k1, 13421772 + (l1 << 24));
                     }
                  }

                  GlStateManager.func_179121_F();
               }
            }

         }
      }
   }

   public void func_146227_a(ITextComponent chatComponent) {
      this.func_146234_a(chatComponent, 0);
   }

   public void func_146234_a(ITextComponent chatComponent, int chatLineId) {
      percentComplete = 0.0F;
      this.setChatLine(chatComponent, chatLineId, this.mc.field_71456_v.func_73834_c(), false);
      LOGGER.info("[CHAT] {}", chatComponent.func_150260_c().replaceAll("\r", "\\\\r").replaceAll("\n", "\\\\n"));
   }

   private void setChatLine(ITextComponent chatComponent, int chatLineId, int updateCounter, boolean displayOnly) {
      messageAdd = -((Double)ChatModifications.getInstance().vLength.getCurrentState()).intValue();
      if (chatLineId != 0) {
         this.func_146242_c(chatLineId);
      }

      int i = MathHelper.func_76141_d((float)this.func_146228_f() / this.func_146244_h());
      List list = GuiUtilRenderComponents.func_178908_a(chatComponent, i, this.mc.field_71466_p, false, false);
      boolean flag = this.func_146241_e();
      newLines = list.size() - 1;

      ITextComponent itextcomponent;
      for(Iterator var8 = list.iterator(); var8.hasNext(); this.drawnChatLines.add(0, new ChatLine(updateCounter, itextcomponent, chatLineId))) {
         itextcomponent = (ITextComponent)var8.next();
         if (flag && this.scrollPos > 0) {
            this.isScrolled = true;
            this.func_146229_b(1);
         }
      }

      while(this.drawnChatLines.size() > 100) {
         this.drawnChatLines.remove(this.drawnChatLines.size() - 1);
      }

      if (!displayOnly) {
         this.chatLines.add(0, new ChatLine(updateCounter, chatComponent, chatLineId));

         while(this.chatLines.size() > 100) {
            this.chatLines.remove(this.chatLines.size() - 1);
         }
      }

   }

   public void func_146245_b() {
      this.drawnChatLines.clear();
      this.func_146240_d();

      for(int i = this.chatLines.size() - 1; i >= 0; --i) {
         ChatLine chatline = (ChatLine)this.chatLines.get(i);
         this.setChatLine(chatline.func_151461_a(), chatline.func_74539_c(), chatline.func_74540_b(), true);
      }

   }

   public List func_146238_c() {
      return this.sentMessages;
   }

   public void func_146239_a(String message) {
      if (this.sentMessages.isEmpty() || !((String)this.sentMessages.get(this.sentMessages.size() - 1)).equals(message)) {
         this.sentMessages.add(message);
      }

   }

   public void func_146240_d() {
      this.scrollPos = 0;
      this.isScrolled = false;
   }

   public void func_146229_b(int amount) {
      this.scrollPos += amount;
      int i = this.drawnChatLines.size();
      if (this.scrollPos > i - this.func_146232_i()) {
         this.scrollPos = i - this.func_146232_i();
      }

      if (this.scrollPos <= 0) {
         this.scrollPos = 0;
         this.isScrolled = false;
      }

   }

   @Nullable
   public ITextComponent func_146236_a(int mouseX, int mouseY) {
      if (!this.func_146241_e()) {
         return null;
      } else {
         ScaledResolution scaledresolution = new ScaledResolution(this.mc);
         int i = scaledresolution.func_78325_e();
         float f = this.func_146244_h();
         int j = mouseX / i - 2 - ((Double)ChatModifications.getInstance().xOffset.getCurrentState()).intValue();
         int k = mouseY / i - 40 + ((Double)ChatModifications.getInstance().yOffset.getCurrentState()).intValue();
         j = MathHelper.func_76141_d((float)j / f);
         k = MathHelper.func_76141_d((float)k / f);
         if (j >= 0 && k >= 0) {
            int l = Math.min(this.func_146232_i(), this.drawnChatLines.size());
            if (j <= MathHelper.func_76141_d((float)this.func_146228_f() / this.func_146244_h()) && k < this.mc.field_71466_p.field_78288_b * l + l) {
               int i1 = k / this.mc.field_71466_p.field_78288_b + this.scrollPos;
               if (i1 >= 0 && i1 < this.drawnChatLines.size()) {
                  ChatLine chatline = (ChatLine)this.drawnChatLines.get(i1);
                  int j1 = 0;
                  Iterator var12 = chatline.func_151461_a().iterator();

                  while(var12.hasNext()) {
                     ITextComponent itextcomponent = (ITextComponent)var12.next();
                     if (itextcomponent instanceof TextComponentString) {
                        j1 += this.mc.field_71466_p.func_78256_a(GuiUtilRenderComponents.func_178909_a(((TextComponentString)itextcomponent).func_150265_g(), false));
                        if (j1 > j) {
                           return itextcomponent;
                        }
                     }
                  }
               }

               return null;
            } else {
               return null;
            }
         } else {
            return null;
         }
      }
   }

   public boolean func_146241_e() {
      return this.mc.field_71462_r instanceof net.minecraft.client.gui.GuiChat;
   }

   public void func_146242_c(int id) {
      Iterator iterator = this.drawnChatLines.iterator();

      ChatLine chatline1;
      while(iterator.hasNext()) {
         chatline1 = (ChatLine)iterator.next();
         if (chatline1.func_74539_c() == id) {
            iterator.remove();
         }
      }

      iterator = this.chatLines.iterator();

      while(iterator.hasNext()) {
         chatline1 = (ChatLine)iterator.next();
         if (chatline1.func_74539_c() == id) {
            iterator.remove();
            break;
         }
      }

   }

   public int func_146228_f() {
      return calculateChatboxWidth(this.mc.field_71474_y.field_96692_F);
   }

   public int func_146246_g() {
      return calculateChatboxHeight(this.func_146241_e() ? this.mc.field_71474_y.field_96694_H : this.mc.field_71474_y.field_96693_G);
   }

   public float func_146244_h() {
      return this.mc.field_71474_y.field_96691_E;
   }

   public static int calculateChatboxWidth(float scale) {
      return MathHelper.func_76141_d(scale * 280.0F + 40.0F);
   }

   public static int calculateChatboxHeight(float scale) {
      return MathHelper.func_76141_d(scale * 160.0F + 20.0F);
   }

   public int func_146232_i() {
      return this.func_146246_g() / 9;
   }

   static {
      LOGGER = Client.LOGGER;
      percentComplete = 0.0F;
      prevMillis = -1L;
   }
}
