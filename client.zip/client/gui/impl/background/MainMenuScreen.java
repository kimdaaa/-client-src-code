package client.gui.impl.background;

import client.Client;
import client.gui.impl.background.particles.ParticleSystem;
import client.util.ColorUtil;
import client.util.RenderUtil;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiWorldSelection;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class MainMenuScreen extends GuiScreen {
   private final ResourceLocation resourceLocation = new ResourceLocation("textures/background.jpg");
   public ParticleSystem particleSystem;
   private int y;
   private int x;

   public static void drawCompleteImage(float posX, float posY, float width, float height) {
      GL11.glPushMatrix();
      GL11.glTranslatef(posX, posY, 0.0F);
      GL11.glBegin(7);
      GL11.glTexCoord2f(0.0F, 0.0F);
      GL11.glVertex3f(0.0F, 0.0F, 0.0F);
      GL11.glTexCoord2f(0.0F, 1.0F);
      GL11.glVertex3f(0.0F, height, 0.0F);
      GL11.glTexCoord2f(1.0F, 1.0F);
      GL11.glVertex3f(width, height, 0.0F);
      GL11.glTexCoord2f(1.0F, 0.0F);
      GL11.glVertex3f(width, 0.0F, 0.0F);
      GL11.glEnd();
      GL11.glPopMatrix();
   }

   public static boolean isHovered(int x, int y, int width, int height, int mouseX, int mouseY) {
      return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY < y + height;
   }

   public void func_73866_w_() {
      this.x = this.field_146294_l / 2;
      this.y = this.field_146295_m / 4 + 48;
      int yOffset = (int)(-1.0F * ((float)this.field_146295_m / 2.0F) / ((float)this.field_146295_m / 18.0F));
      this.field_146292_n.add(new MainMenuScreen.TextButton(0, 3 + Client.textManager.getStringWidth("Welcome to Client 2.0.0") / 2, yOffset + 10, "Welcome to Client 2.0.0"));
      this.field_146292_n.add(new MainMenuScreen.TextButton(0, 3 + Client.textManager.getStringWidth("Singleplayer") / 2, this.y + 20, "Singleplayer"));
      this.field_146292_n.add(new MainMenuScreen.TextButton(1, 3 + Client.textManager.getStringWidth("Multiplayer") / 2, this.y + 44, "Multiplayer"));
      this.field_146292_n.add(new MainMenuScreen.TextButton(2, 3 + Client.textManager.getStringWidth("Options") / 2, this.y + 66, "Options"));
      this.field_146292_n.add(new MainMenuScreen.TextButton(2, 3 + Client.textManager.getStringWidth("Quit game") / 2, this.y + 88, "Quit game"));
      GlStateManager.func_179090_x();
      GlStateManager.func_179147_l();
      GlStateManager.func_179118_c();
      GlStateManager.func_179103_j(7425);
      GlStateManager.func_179103_j(7424);
      GlStateManager.func_179084_k();
      GlStateManager.func_179141_d();
      GlStateManager.func_179098_w();
   }

   public void func_73876_c() {
      if (this.particleSystem != null) {
         this.particleSystem.update();
      }

      super.func_73876_c();
   }

   public void func_73864_a(int mouseX, int mouseY, int mouseButton) {
      if (isHovered(Client.textManager.getStringWidth("Singleplayer") / 2, this.y + 20, Client.textManager.getStringWidth("Singleplayer"), Client.textManager.getFontHeight(), mouseX, mouseY)) {
         this.field_146297_k.func_147118_V().func_147682_a(PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
         this.field_146297_k.func_147108_a(new GuiWorldSelection(this));
      } else if (isHovered(Client.textManager.getStringWidth("Multiplayer") / 2, this.y + 44, Client.textManager.getStringWidth("Multiplayer"), Client.textManager.getFontHeight(), mouseX, mouseY)) {
         this.field_146297_k.func_147118_V().func_147682_a(PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
         this.field_146297_k.func_147108_a(new GuiMultiplayer(this));
      } else if (isHovered(Client.textManager.getStringWidth("Options") / 2, this.y + 66, Client.textManager.getStringWidth("Options"), Client.textManager.getFontHeight(), mouseX, mouseY)) {
         this.field_146297_k.func_147118_V().func_147682_a(PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
         this.field_146297_k.func_147108_a(new GuiOptions(this, this.field_146297_k.field_71474_y));
      } else if (isHovered(Client.textManager.getStringWidth("Quit game") / 2, this.y + 88, Client.textManager.getStringWidth("Quit game"), Client.textManager.getFontHeight(), mouseX, mouseY)) {
         this.field_146297_k.func_147118_V().func_147682_a(PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
         this.field_146297_k.func_71400_g();
      }

   }

   public void drawLogo() {
      ResourceLocation logo = new ResourceLocation("textures/logo.png");
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      this.field_146297_k.func_110434_K().func_110577_a(logo);
      drawCompleteImage(0.0F, 464.0F, 250.0F, 48.0F);
      this.field_146297_k.func_110434_K().func_147645_c(logo);
      GlStateManager.func_179147_l();
      GlStateManager.func_179090_x();
   }

   public void drawRoundedLogo() {
      ResourceLocation logo = new ResourceLocation("textures/roundedlogo.png");
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      this.field_146297_k.func_110434_K().func_110577_a(logo);
      drawCompleteImage((float)(this.x - 72), (float)(this.y - 72), 144.0F, 144.0F);
      this.field_146297_k.func_110434_K().func_147645_c(logo);
      GlStateManager.func_179147_l();
      GlStateManager.func_179090_x();
   }

   public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
      float xOffset = -1.0F * ((float)this.field_146294_l / 2.0F / ((float)this.field_146294_l / 32.0F));
      float yOffset = -1.0F * ((float)this.field_146295_m / 2.0F / ((float)this.field_146295_m / 18.0F));
      this.x = this.field_146294_l / 2;
      this.y = this.field_146295_m / 4 + 48;
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      this.field_146297_k.func_110434_K().func_110577_a(this.resourceLocation);
      drawCompleteImage(-16.0F + xOffset, -9.0F + yOffset, (float)(this.field_146294_l + 32), (float)(this.field_146295_m + 18));
      RenderUtil.drawRect(xOffset, yOffset, 70.0F, 1000.0F, ColorUtil.toRGBA(20, 20, 20, 70));
      super.func_73863_a(970, 540, partialTicks);
      this.drawLogo();
      this.drawRoundedLogo();
      if (this.particleSystem != null && ((Boolean)MenuToggler.getInstance().particles.getCurrentState()).booleanValue()) {
         this.particleSystem.render(mouseX, mouseY);
      } else {
         this.particleSystem = new ParticleSystem(new ScaledResolution(this.field_146297_k));
      }

   }

   private static class TextButton extends GuiButton {
      public TextButton(int buttonId, int x, int y, String buttonText) {
         super(buttonId, x, y, Client.textManager.getStringWidth(buttonText), Client.textManager.getFontHeight(), buttonText);
      }

      public void func_191745_a(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
         if (this.field_146125_m) {
            this.field_146124_l = true;
            this.field_146123_n = (float)mouseX >= (float)this.field_146128_h - (float)Client.textManager.getStringWidth(this.field_146126_j) / 2.0F && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g;
            Client.textManager.drawStringWithShadow(this.field_146126_j, (float)this.field_146128_h - (float)Client.textManager.getStringWidth(this.field_146126_j) / 2.0F, (float)this.field_146129_i, Color.WHITE.getRGB());
            if (this.field_146123_n) {
               RenderUtil.drawLine((float)(this.field_146128_h - 1) - (float)Client.textManager.getStringWidth(this.field_146126_j) / 2.0F, (float)(this.field_146129_i + 2 + Client.textManager.getFontHeight()), (float)this.field_146128_h + (float)Client.textManager.getStringWidth(this.field_146126_j) / 2.0F + 1.0F, (float)(this.field_146129_i + 2 + Client.textManager.getFontHeight()), 1.0F, Color.WHITE.getRGB());
            }
         }

      }

      public boolean func_146116_c(Minecraft mc, int mouseX, int mouseY) {
         return this.field_146124_l && this.field_146125_m && (float)mouseX >= (float)this.field_146128_h - (float)Client.textManager.getStringWidth(this.field_146126_j) / 2.0F && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g;
      }
   }
}
