package client.gui.impl.background;

public class MainMenuButton {
   public static boolean grdnguyferht8gvy34y785g43ynb57gny34875nt34t5bv7n3t7634gny53674t5gv3487256g7826b5342n58gv341tb5763tgb567v32t55gt34() {
      return true;
   }
}
