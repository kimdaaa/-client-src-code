package client.gui.impl;

import client.Client;
import client.gui.ClientGui;
import client.gui.impl.button.Button;
import client.modules.Feature;
import client.modules.client.ClickGui;
import client.util.ColorUtil;
import client.util.RenderUtil;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.function.Consumer;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.init.SoundEvents;

public class Component extends Feature {
   public static int[] counter1 = new int[]{1};
   private final ArrayList items = new ArrayList();
   public boolean drag;
   private int x;
   private int y;
   private int x2;
   private int y2;
   private int width;
   private int height;
   private boolean open;

   public Component(String name, int x, int y, boolean open) {
      super(name);
      this.x = x;
      this.y = y;
      this.width = 100;
      this.height = 18;
      this.open = open;
      this.setupItems();
   }

   public void setupItems() {
   }

   private void drag(int mouseX, int mouseY) {
      if (this.drag) {
         this.x = this.x2 + mouseX;
         this.y = this.y2 + mouseY;
      }
   }

   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      float var4;
      int color;
      if (ClickGui.getInstance().gui.getCurrentState() == ClickGui.Gui.OLD) {
         this.drag(mouseX, mouseY);
         counter1 = new int[]{1};
         var4 = this.open ? this.getTotalItemHeight() - 2.0F : 0.0F;
         color = ColorUtil.toARGB(((Integer)ClickGui.getInstance().topRed.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().topGreen.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().topBlue.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().secondAlpha.getCurrentState()).intValue());
         if (this.open) {
            RenderUtil.drawRect((float)this.x + 1.0F, (float)this.y + 15.0F, (float)(this.x + this.width), (float)(this.y + this.height + 2) + var4, ColorUtil.toRGBA(((Integer)ClickGui.getInstance().red.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().green.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().blue.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().b_alpha.getCurrentState()).intValue()));
            if (((Boolean)ClickGui.getInstance().outline.getCurrentState()).booleanValue() && ((Boolean)ClickGui.getInstance().rainbow.getCurrentState()).booleanValue()) {
               RenderUtil.drawRect((float)this.x, (float)this.y + 12.2F, (float)(this.x + this.width - 99), (float)(this.y + this.height) + var4 + 1.0F, ColorUtil.rainbow(((Integer)ClickGui.getInstance().rainbowHue.getCurrentState()).intValue()).getRGB());
               RenderUtil.drawRect((float)this.x + 99.0F, (float)this.y + 12.2F, (float)(this.x + this.width), (float)(this.y + this.height) + var4 + 1.0F, ColorUtil.rainbow(((Integer)ClickGui.getInstance().rainbowHue.getCurrentState()).intValue()).getRGB());
               RenderUtil.drawRect((float)this.x, (float)(this.y + this.height + 2) + var4 - 1.0F, (float)(this.x + this.width), (float)(this.y + this.height + 2) + var4, ColorUtil.rainbow(((Integer)ClickGui.getInstance().rainbowHue.getCurrentState()).intValue()).getRGB());
            } else if (((Boolean)ClickGui.getInstance().outline.getCurrentState()).booleanValue()) {
               RenderUtil.drawRect((float)this.x, (float)this.y + 12.2F, (float)(this.x + this.width - 99), (float)(this.y + this.height) + var4 + 1.0F, ColorUtil.toRGBA(((Integer)ClickGui.getInstance().o_red.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().o_green.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().o_blue.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().o_alpha.getCurrentState()).intValue()));
               RenderUtil.drawRect((float)this.x + 99.0F, (float)this.y + 12.2F, (float)(this.x + this.width), (float)(this.y + this.height) + var4 + 1.0F, ColorUtil.toRGBA(((Integer)ClickGui.getInstance().o_red.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().o_green.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().o_blue.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().o_alpha.getCurrentState()).intValue()));
               RenderUtil.drawRect((float)this.x, (float)(this.y + this.height + 2) + var4 - 1.0F, (float)(this.x + this.width), (float)(this.y + this.height + 2) + var4, ColorUtil.toRGBA(((Integer)ClickGui.getInstance().o_red.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().o_green.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().o_blue.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().o_alpha.getCurrentState()).intValue()));
            }
         }

         if (ClickGui.getInstance().topRect.getCurrentState() == ClickGui.Rect.SQUARE) {
            Gui.func_73734_a(this.x, this.y + 3, this.x + this.width, this.y + this.height - 4, ((Boolean)ClickGui.getInstance().rainbow.getCurrentState()).booleanValue() ? ColorUtil.rainbow(((Integer)ClickGui.getInstance().rainbowHue.getCurrentState()).intValue()).getRGB() : color);
         } else if (ClickGui.getInstance().topRect.getCurrentState() == ClickGui.Rect.ROUNDED) {
            RenderUtil.drawTopRoundedRect((double)this.x, (double)(this.y + 2), (double)this.width, (double)(this.height - 5), ClickGui.getInstance().roundedness.getCurrentState() == ClickGui.Roundedness.FULL ? 25.0D : (ClickGui.getInstance().roundedness.getCurrentState() == ClickGui.Roundedness.LARGE ? 20.0D : (ClickGui.getInstance().roundedness.getCurrentState() == ClickGui.Roundedness.MEDIUM ? 15.0D : (ClickGui.getInstance().roundedness.getCurrentState() == ClickGui.Roundedness.LITTLE ? 10.0D : (ClickGui.getInstance().roundedness.getCurrentState() == ClickGui.Roundedness.TINY ? 5.0D : 0.0D)))), ((Boolean)ClickGui.getInstance().rainbow.getCurrentState()).booleanValue() ? ColorUtil.rainbow(((Integer)ClickGui.getInstance().rainbowHue.getCurrentState()).intValue()) : new Color(ColorUtil.toRGBA(((Integer)ClickGui.getInstance().topRed.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().topGreen.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().topBlue.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().secondAlpha.getCurrentState()).intValue())));
         }

         if (ClickGui.getInstance().bottomRect.getCurrentState() == ClickGui.Bottom.ROUNDED) {
            RenderUtil.drawBottomRoundedRect((double)this.x, (double)((float)(this.y + this.height + 2) + var4 - 8.0F + (float)(!this.open ? 3 : 0)), (double)this.width, (double)(this.height - 5), 15.0D, ((Boolean)ClickGui.getInstance().rainbow.getCurrentState()).booleanValue() ? ColorUtil.rainbow(((Integer)ClickGui.getInstance().rainbowHue.getCurrentState()).intValue()) : new Color(ColorUtil.toRGBA(((Integer)ClickGui.getInstance().topRed.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().topGreen.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().topBlue.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().secondAlpha.getCurrentState()).intValue())));
         }

         if (ClickGui.getInstance().componentAlign.getCurrentState() == ClickGui.Align.MIDDLE) {
            Client.textManager.drawStringWithShadow(((Boolean)ClickGui.getInstance().topRectTextBold.getCurrentState()).booleanValue() ? ChatFormatting.BOLD + this.getName() : this.getName(), (float)this.x + (float)(this.width / 2) - (float)(this.renderer.getStringWidth(this.getName()) / 2), (float)this.y - 4.0F - (float)ClientGui.getClickGui().getTextOffset() + 3.0F, -1);
         } else {
            Client.textManager.drawStringWithShadow(((Boolean)ClickGui.getInstance().topRectTextBold.getCurrentState()).booleanValue() ? ChatFormatting.BOLD + this.getName() : this.getName(), (float)this.x + 3.0F, (float)this.y - 4.0F - (float)ClientGui.getClickGui().getTextOffset() + 3.0F, -1);
         }

         if (this.open) {
            float y = (float)(this.getY() + this.getHeight()) - 3.0F;
            Iterator var7 = this.getItems().iterator();

            while(var7.hasNext()) {
               Item item = (Item)var7.next();
               ++counter1[0];
               if (!item.isHidden()) {
                  item.setLocation((float)this.x + 2.0F, y);
                  item.setWidth(this.getWidth() - 4);
                  item.drawScreen(mouseX, mouseY, partialTicks);
                  y += (float)item.getHeight() + 1.5F;
               }
            }
         }
      } else if (ClickGui.getInstance().gui.getCurrentState() == ClickGui.Gui.NEW) {
         this.drag(mouseX, mouseY);
         counter1 = new int[]{1};
         var4 = this.open ? this.getTotalItemHeight() - 2.0F : 0.0F;
         color = ColorUtil.toARGB(((Integer)ClickGui.getInstance().newtopred.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().newtopgreen.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().newtopblue.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().newtopalpha.getCurrentState()).intValue());
         int thirdcolor = ColorUtil.toARGB(((Integer)ClickGui.getInstance().newthirdRed.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().newthirdGreen.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().newthirdBlue.getCurrentState()).intValue(), ((Integer)ClickGui.getInstance().newthirdAlpha.getCurrentState()).intValue());
         Gui.func_73734_a(this.x, this.y - 1, this.x + this.width, this.y + this.height - 6, color);
         Gui.func_73734_a(this.x, this.y + 11, this.x + this.width, this.y + this.height - 6, thirdcolor);
         if (this.open) {
            RenderUtil.drawRect((float)this.x, (float)this.y + 12.5F, (float)(this.x + this.width), (float)(this.y + this.height) + var4, ColorUtil.toRGBA(10, 10, 10, ((Integer)ClickGui.getInstance().newbgAlpha.getCurrentState()).intValue()));
         }

         Client.textManager.drawStringWithShadow(this.getName(), (float)this.x + (float)(this.width / 2) - (float)(this.renderer.getStringWidth(this.getName()) / 2), (float)this.y - 4.0F - (float)ClientGui.getClickGui().getTextOffset(), -1);
         if (this.open) {
            float y = (float)(this.getY() + this.getHeight()) - 3.0F;
            Iterator var12 = this.getItems().iterator();

            while(var12.hasNext()) {
               Item item = (Item)var12.next();
               ++counter1[0];
               if (!item.isHidden()) {
                  item.setLocation((float)this.x + 2.0F, y);
                  item.setWidth(this.getWidth() - 4);
                  item.drawScreen(mouseX, mouseY, partialTicks);
                  y += (float)item.getHeight() + 1.5F;
               }
            }
         }
      }

   }

   public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
      if (mouseButton == 0 && this.isHovering(mouseX, mouseY)) {
         this.x2 = this.x - mouseX;
         this.y2 = this.y - mouseY;
         ClientGui.getClickGui().getComponents().forEach((component) -> {
            if (component.drag) {
               component.drag = false;
            }

         });
         this.drag = true;
      } else if (mouseButton == 1 && this.isHovering(mouseX, mouseY)) {
         this.open = !this.open;
         mc.func_147118_V().func_147682_a(PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
      } else if (this.open) {
         this.getItems().forEach((item) -> {
            item.mouseClicked(mouseX, mouseY, mouseButton);
         });
      }
   }

   public void mouseReleased(int mouseX, int mouseY, int releaseButton) {
      if (releaseButton == 0) {
         this.drag = false;
      }

      if (this.open) {
         this.getItems().forEach((item) -> {
            item.mouseReleased(mouseX, mouseY, releaseButton);
         });
      }
   }

   public void onKeyTyped(char typedChar, int keyCode) {
      if (this.open) {
         this.getItems().forEach((item) -> {
            item.onKeyTyped(typedChar, keyCode);
         });
      }
   }

   public void addButton(Button button) {
      this.items.add(button);
   }

   public int getX() {
      return this.x;
   }

   public void setX(int x) {
      this.x = x;
   }

   public int getY() {
      return this.y;
   }

   public void setY(int y) {
      this.y = y;
   }

   public int getWidth() {
      return this.width;
   }

   public void setWidth(int width) {
      this.width = width;
   }

   public int getHeight() {
      return this.height;
   }

   public void setHeight(int height) {
      this.height = height;
   }

   public final ArrayList getItems() {
      return this.items;
   }

   private boolean isHovering(int mouseX, int mouseY) {
      return mouseX >= this.getX() && mouseX <= this.getX() + this.getWidth() && mouseY >= this.getY() && mouseY <= this.getY() + this.getHeight() - (this.open ? 2 : 0);
   }

   private float getTotalItemHeight() {
      float height = 0.0F;

      Item item;
      for(Iterator var2 = this.getItems().iterator(); var2.hasNext(); height += (float)item.getHeight() + 1.5F) {
         item = (Item)var2.next();
      }

      return height;
   }
}
