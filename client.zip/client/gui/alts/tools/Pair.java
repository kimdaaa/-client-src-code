package client.gui.alts.tools;

import java.io.Serializable;

public class Pair implements Serializable {
   private static final long serialVersionUID = 2586850598481149380L;
   private final Object obj1;
   private final Object obj2;

   public Pair(Object obj1, Object obj2) {
      this.obj1 = obj1;
      this.obj2 = obj2;
   }

   public Object getValue1() {
      return this.obj1;
   }

   public Object getValue2() {
      return this.obj2;
   }

   public String toString() {
      return Pair.class.getName() + "@" + Integer.toHexString(this.hashCode()) + " [" + this.obj1.toString() + ", " + this.obj2.toString() + "]";
   }
}
