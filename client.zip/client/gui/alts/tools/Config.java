package client.gui.alts.tools;

import client.gui.alts.zprestige.iasencrypt.Standards;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.attribute.DosFileAttributeView;
import java.nio.file.attribute.DosFileAttributes;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.Minecraft;

public class Config implements Serializable {
   public static final long serialVersionUID = -559038737L;
   private static Config instance = null;
   private static final String configFileName = ".iasx";
   private final ArrayList field_218893_c = new ArrayList();

   public static Config getInstance() {
      return instance;
   }

   private Config() {
      instance = this;
   }

   public void setKey(Pair key) {
      if (this.getKey((String)key.getValue1()) != null) {
         this.removeKey((String)key.getValue1());
      }

      this.field_218893_c.add(key);
      save();
   }

   public void setKey(String key, Object value) {
      this.setKey(new Pair(key, value));
   }

   public Object getKey(String key) {
      if (this.field_218893_c == null) {
         System.out.println("Error: Config failed to load during PreInitialization. Loading now.");
         load();
      }

      Iterator var2 = this.field_218893_c.iterator();

      Pair aField_218893_c;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         aField_218893_c = (Pair)var2.next();
      } while(!((String)aField_218893_c.getValue1()).equals(key));

      return aField_218893_c.getValue2();
   }

   private void removeKey(String key) {
      for(int i = 0; i < this.field_218893_c.size(); ++i) {
         if (((String)((Pair)this.field_218893_c.get(i)).getValue1()).equals(key)) {
            this.field_218893_c.remove(i);
         }
      }

   }

   public static void save() {
      saveToFile();
   }

   public static void load() {
      loadFromOld();
      readFromFile();
   }

   private static void readFromFile() {
      File f = new File(Standards.IASFOLDER, ".iasx");
      if (f.exists()) {
         try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream(f));
            instance = (Config)stream.readObject();
            stream.close();
         } catch (IOException var2) {
            var2.printStackTrace();
            instance = new Config();
            f.delete();
         } catch (ClassNotFoundException var3) {
            var3.printStackTrace();
            instance = new Config();
            f.delete();
         }
      }

      if (instance == null) {
         instance = new Config();
      }

   }

   private static void saveToFile() {
      Path file;
      DosFileAttributes attr;
      DosFileAttributeView view;
      try {
         file = (new File(Standards.IASFOLDER, ".iasx")).toPath();
         attr = (DosFileAttributes)Files.readAttributes(file, DosFileAttributes.class);
         view = (DosFileAttributeView)Files.getFileAttributeView(file, DosFileAttributeView.class);
         if (attr.isHidden()) {
            view.setHidden(false);
         }
      } catch (NoSuchFileException var5) {
         ;
      } catch (Exception var6) {
         var6.printStackTrace();
      }

      try {
         ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(new File(Standards.IASFOLDER, ".iasx")));
         out.writeObject(instance);
         out.close();
      } catch (IOException var4) {
         var4.printStackTrace();
      }

      try {
         file = (new File(Standards.IASFOLDER, ".iasx")).toPath();
         attr = (DosFileAttributes)Files.readAttributes(file, DosFileAttributes.class);
         view = (DosFileAttributeView)Files.getFileAttributeView(file, DosFileAttributeView.class);
         if (!attr.isHidden()) {
            view.setHidden(true);
         }
      } catch (Exception var3) {
         var3.printStackTrace();
      }

   }

   private static void loadFromOld() {
      File f = new File(Minecraft.func_71410_x().field_71412_D, "user.cfg");
      if (f.exists()) {
         try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream(f));
            instance = (Config)stream.readObject();
            stream.close();
            f.delete();
            System.out.println("Loaded data from old file");
         } catch (IOException var2) {
            var2.printStackTrace();
            f.delete();
         } catch (ClassNotFoundException var3) {
            var3.printStackTrace();
            f.delete();
         }
      }

   }
}
