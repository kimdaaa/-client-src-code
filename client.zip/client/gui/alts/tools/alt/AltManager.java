package client.gui.alts.tools.alt;

import client.gui.alts.MR;
import client.gui.alts.zprestige.ias.account.AlreadyLoggedInException;
import client.gui.alts.zprestige.ias.config.ConfigValues;
import client.gui.alts.zprestige.iasencrypt.EncryptionTools;
import com.mojang.authlib.Agent;
import com.mojang.authlib.AuthenticationService;
import com.mojang.authlib.UserAuthentication;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.util.UUIDTypeAdapter;
import java.util.Iterator;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Session;

public class AltManager {
   private static AltManager manager = null;
   private final UserAuthentication auth;

   private AltManager() {
      UUID uuid = UUID.randomUUID();
      AuthenticationService authService = new YggdrasilAuthenticationService(Minecraft.func_71410_x().func_110437_J(), uuid.toString());
      this.auth = authService.createUserAuthentication(Agent.MINECRAFT);
      authService.createMinecraftSessionService();
   }

   public static AltManager getInstance() {
      if (manager == null) {
         manager = new AltManager();
      }

      return manager;
   }

   public Throwable setUser(String username, String password) {
      Throwable throwable = null;
      if (Minecraft.func_71410_x().func_110432_I().func_111285_a().equals(EncryptionTools.decode(username)) && !Minecraft.func_71410_x().func_110432_I().func_148254_d().equals("0")) {
         if (!ConfigValues.ENABLERELOG) {
            throwable = new AlreadyLoggedInException();
         }
      } else {
         if (!Minecraft.func_71410_x().func_110432_I().func_148254_d().equals("0")) {
            Iterator var4 = AltDatabase.getInstance().getAlts().iterator();

            while(var4.hasNext()) {
               AccountData data = (AccountData)var4.next();
               if (data.alias.equals(Minecraft.func_71410_x().func_110432_I().func_111285_a()) && data.user.equals(username)) {
                  Throwable throwable = new AlreadyLoggedInException();
                  return throwable;
               }
            }
         }

         this.auth.logOut();
         this.auth.setUsername(EncryptionTools.decode(username));
         this.auth.setPassword(EncryptionTools.decode(password));

         try {
            this.auth.logIn();
            Session session = new Session(this.auth.getSelectedProfile().getName(), UUIDTypeAdapter.fromUUID(this.auth.getSelectedProfile().getId()), this.auth.getAuthenticatedToken(), this.auth.getUserType().getName());
            MR.setSession(session);

            for(int i = 0; i < AltDatabase.getInstance().getAlts().size(); ++i) {
               AccountData data = (AccountData)AltDatabase.getInstance().getAlts().get(i);
               if (data.user.equals(username) && data.pass.equals(password)) {
                  data.alias = session.func_111285_a();
               }
            }
         } catch (Exception var7) {
            throwable = var7;
         }
      }

      return (Throwable)throwable;
   }

   public void setUserOffline(String username) {
      this.auth.logOut();
      Session session = new Session(username, username, "0", "legacy");

      try {
         MR.setSession(session);
      } catch (Exception var4) {
         var4.printStackTrace();
      }

   }
}
