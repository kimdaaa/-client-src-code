package client.gui.alts.tools.alt;

import client.gui.alts.zprestige.iasencrypt.EncryptionTools;
import java.io.Serializable;

public class AccountData implements Serializable {
   public static final long serialVersionUID = -147985492L;
   public final String user;
   public final String pass;
   public String alias;

   protected AccountData(String user, String pass, String alias) {
      this.user = EncryptionTools.encode(user);
      this.pass = EncryptionTools.encode(pass);
      this.alias = alias;
   }

   public boolean equalsBasic(Object obj) {
      if (this == obj) {
         return true;
      } else if (obj == null) {
         return false;
      } else if (this.getClass() != obj.getClass()) {
         return false;
      } else {
         AccountData other = (AccountData)obj;
         return this.user.equals(other.user);
      }
   }
}
