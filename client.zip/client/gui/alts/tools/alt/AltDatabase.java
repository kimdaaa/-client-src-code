package client.gui.alts.tools.alt;

import client.gui.alts.tools.Config;
import java.io.Serializable;
import java.util.ArrayList;

public class AltDatabase implements Serializable {
   public static final long serialVersionUID = -1585600597L;
   private static AltDatabase instance;
   private final ArrayList altList = new ArrayList();

   private static void loadFromConfig() {
      if (instance == null) {
         instance = (AltDatabase)Config.getInstance().getKey("altaccounts");
      }

   }

   private static void saveToConfig() {
      Config.getInstance().setKey("altaccounts", instance);
   }

   public static AltDatabase getInstance() {
      loadFromConfig();
      if (instance == null) {
         instance = new AltDatabase();
         saveToConfig();
      }

      return instance;
   }

   public ArrayList getAlts() {
      return this.altList;
   }
}
