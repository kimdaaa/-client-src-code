package client.gui.alts;

import client.gui.alts.tools.Config;
import java.lang.reflect.Field;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Session;

public class MR {
   public static void init() {
      Config.load();
   }

   public static void setSession(Session s) throws Exception {
      Class mc = Minecraft.func_71410_x().getClass();

      try {
         Field session = null;
         Field[] var3 = mc.getDeclaredFields();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            Field f = var3[var5];
            if (f.getType().isInstance(s)) {
               session = f;
               System.out.println("Found field " + f + ", injecting...");
            }
         }

         if (session == null) {
            throw new IllegalStateException("No field of type " + Session.class.getCanonicalName() + " declared.");
         } else {
            session.setAccessible(true);
            session.set(Minecraft.func_71410_x(), s);
            session.setAccessible(false);
         }
      } catch (Exception var7) {
         var7.printStackTrace();
         throw var7;
      }
   }
}
