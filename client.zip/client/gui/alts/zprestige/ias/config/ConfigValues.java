package client.gui.alts.zprestige.ias.config;

public class ConfigValues {
   public static final boolean CASESENSITIVE_DEFAULT = false;
   public static boolean CASESENSITIVE;
   public static final String CASESENSITIVE_NAME = "Case sensitive";
   public static final boolean ENABLERELOG_DEFAULT = false;
   public static boolean ENABLERELOG;
   public static final String ENABLERELOG_NAME = "Enable relog";
}
