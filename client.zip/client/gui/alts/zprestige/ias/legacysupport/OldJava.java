package client.gui.alts.zprestige.ias.legacysupport;

import net.minecraft.client.resources.I18n;

public class OldJava implements ILegacyCompat {
   public int[] getDate() {
      int[] ret = new int[]{0, 0, 0};
      return ret;
   }

   public String getFormattedDate() {
      return I18n.func_135052_a("ias.updatejava", new Object[0]);
   }
}
