package client.gui.alts.zprestige.ias.legacysupport;

public interface ILegacyCompat {
   int[] getDate();

   String getFormattedDate();
}
