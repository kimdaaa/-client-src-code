package client.gui.alts.zprestige.ias.tools;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.util.ResourceLocation;

public class SkinRender {
   private final File file;
   private DynamicTexture previewTexture;
   private ResourceLocation resourceLocation;
   private final TextureManager textureManager;

   public SkinRender(TextureManager textureManager, File file) {
      this.textureManager = textureManager;
      this.file = file;
   }

   private boolean loadPreview() {
      try {
         BufferedImage image = ImageIO.read(this.file);
         this.previewTexture = new DynamicTexture(image);
         this.resourceLocation = this.textureManager.func_110578_a("ias", this.previewTexture);
         return true;
      } catch (IOException var2) {
         var2.printStackTrace();
         return false;
      }
   }

   public void drawImage(int xPos, int yPos, int width, int height) {
      if (this.previewTexture == null) {
         boolean successful = this.loadPreview();
         if (!successful) {
            System.out.println("Failure to load preview.");
            return;
         }
      }

      this.previewTexture.func_110564_a();
      this.textureManager.func_110577_a(this.resourceLocation);
      Gui.func_146110_a(xPos, yPos, 0.0F, 0.0F, width, height, 64.0F, 128.0F);
   }
}
