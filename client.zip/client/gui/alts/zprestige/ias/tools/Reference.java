package client.gui.alts.zprestige.ias.tools;

public class Reference {
   public static final String MODID = "ias";
   public static final String MODNAME = "Client 2.0.0 Account Switcher";
}
