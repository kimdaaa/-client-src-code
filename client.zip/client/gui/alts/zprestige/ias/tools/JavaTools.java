package client.gui.alts.zprestige.ias.tools;

import client.gui.alts.zprestige.ias.legacysupport.ILegacyCompat;
import client.gui.alts.zprestige.ias.legacysupport.NewJava;
import client.gui.alts.zprestige.ias.legacysupport.OldJava;

public class JavaTools {
   private static double getJavaVersion() {
      String version = System.getProperty("java.version");
      int pos = version.indexOf(46);
      pos = version.indexOf(46, pos + 1);
      return Double.parseDouble(version.substring(0, pos));
   }

   public static ILegacyCompat getJavaCompat() {
      return (ILegacyCompat)(getJavaVersion() >= 1.8D ? new NewJava() : new OldJava());
   }
}
