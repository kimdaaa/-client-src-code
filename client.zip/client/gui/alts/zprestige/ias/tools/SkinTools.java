package client.gui.alts.zprestige.ias.tools;

import client.gui.alts.tools.alt.AccountData;
import client.gui.alts.tools.alt.AltDatabase;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.Iterator;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class SkinTools {
   public static final File cachedir;
   private static final File skinOut;

   public static void buildSkin(String name) {
      BufferedImage skin;
      try {
         skin = ImageIO.read(new File(cachedir, name + ".png"));
      } catch (IOException var17) {
         if (skinOut.exists()) {
            skinOut.delete();
         }

         return;
      }

      BufferedImage drawing = new BufferedImage(16, 32, 2);
      int[] head;
      int[] torso;
      int[] larm;
      int[] rarm;
      int[] lleg;
      if (skin.getHeight() == 64) {
         head = skin.getRGB(8, 8, 8, 8, (int[])null, 0, 8);
         torso = skin.getRGB(20, 20, 8, 12, (int[])null, 0, 8);
         larm = skin.getRGB(44, 20, 4, 12, (int[])null, 0, 4);
         rarm = skin.getRGB(36, 52, 4, 12, (int[])null, 0, 4);
         lleg = skin.getRGB(4, 20, 4, 12, (int[])null, 0, 4);
         int[] rleg = skin.getRGB(20, 52, 4, 12, (int[])null, 0, 4);
         int[] hat = skin.getRGB(40, 8, 8, 8, (int[])null, 0, 8);
         int[] jacket = skin.getRGB(20, 36, 8, 12, (int[])null, 0, 8);
         int[] larm2 = skin.getRGB(44, 36, 4, 12, (int[])null, 0, 4);
         int[] rarm2 = skin.getRGB(52, 52, 4, 12, (int[])null, 0, 4);
         int[] lleg2 = skin.getRGB(4, 36, 4, 12, (int[])null, 0, 4);
         int[] rleg2 = skin.getRGB(4, 52, 4, 12, (int[])null, 0, 4);

         int i;
         for(i = 0; i < hat.length; ++i) {
            if (hat[i] == 0) {
               hat[i] = head[i];
            }
         }

         for(i = 0; i < jacket.length; ++i) {
            if (jacket[i] == 0) {
               jacket[i] = torso[i];
            }
         }

         for(i = 0; i < larm2.length; ++i) {
            if (larm2[i] == 0) {
               larm2[i] = larm[i];
            }
         }

         for(i = 0; i < rarm2.length; ++i) {
            if (rarm2[i] == 0) {
               rarm2[i] = rarm[i];
            }
         }

         for(i = 0; i < lleg2.length; ++i) {
            if (lleg2[i] == 0) {
               lleg2[i] = lleg[i];
            }
         }

         for(i = 0; i < rleg2.length; ++i) {
            if (rleg2[i] == 0) {
               rleg2[i] = rleg[i];
            }
         }

         drawing.setRGB(4, 0, 8, 8, hat, 0, 8);
         drawing.setRGB(4, 8, 8, 12, jacket, 0, 8);
         drawing.setRGB(0, 8, 4, 12, larm2, 0, 4);
         drawing.setRGB(12, 8, 4, 12, rarm2, 0, 4);
         drawing.setRGB(4, 20, 4, 12, lleg2, 0, 4);
         drawing.setRGB(8, 20, 4, 12, rleg2, 0, 4);
      } else {
         head = skin.getRGB(8, 8, 8, 8, (int[])null, 0, 8);
         torso = skin.getRGB(20, 20, 8, 12, (int[])null, 0, 8);
         larm = skin.getRGB(44, 20, 4, 12, (int[])null, 0, 4);
         rarm = skin.getRGB(4, 20, 4, 12, (int[])null, 0, 4);
         lleg = skin.getRGB(40, 8, 8, 8, (int[])null, 0, 8);

         for(int i = 0; i < lleg.length; ++i) {
            if (lleg[i] == 0) {
               lleg[i] = head[i];
            }
         }

         drawing.setRGB(4, 0, 8, 8, lleg, 0, 8);
         drawing.setRGB(4, 8, 8, 12, torso, 0, 8);
         drawing.setRGB(0, 8, 4, 12, larm, 0, 4);
         drawing.setRGB(12, 8, 4, 12, larm, 0, 4);
         drawing.setRGB(4, 20, 4, 12, rarm, 0, 4);
         drawing.setRGB(8, 20, 4, 12, rarm, 0, 4);
      }

      try {
         ImageIO.write(drawing, "png", skinOut);
      } catch (IOException var16) {
         var16.printStackTrace();
      }

   }

   public static void javDrawSkin(int x, int y, int width, int height) {
      if (skinOut.exists()) {
         SkinRender r = new SkinRender(Minecraft.func_71410_x().func_110434_K(), skinOut);
         r.drawImage(x, y, width, height);
      }
   }

   public static void cacheSkins() {
      if (!cachedir.exists() && !cachedir.mkdirs()) {
         System.out.println("Skin cache directory creation failed.");
      }

      Iterator var0 = AltDatabase.getInstance().getAlts().iterator();

      while(var0.hasNext()) {
         AccountData data = (AccountData)var0.next();
         File file = new File(cachedir, data.alias + ".png");

         try {
            URL url = new URL(String.format("http://skins.minecraft.net/MinecraftSkins/%s.png", data.alias));
            InputStream is = url.openStream();
            if (file.exists()) {
               file.delete();
            }

            file.createNewFile();
            OutputStream os = new FileOutputStream(file);
            byte[] b = new byte[2048];

            int length;
            while((length = is.read(b)) != -1) {
               os.write(b, 0, length);
            }

            is.close();
            os.close();
         } catch (IOException var10) {
            try {
               URL url = new URL("http://skins.minecraft.net/MinecraftSkins/direwolf20.png");
               InputStream is = url.openStream();
               if (file.exists()) {
                  file.delete();
               }

               file.createNewFile();
               OutputStream os = new FileOutputStream(file);
               byte[] b = new byte[2048];

               int length;
               while((length = is.read(b)) != -1) {
                  os.write(b, 0, length);
               }

               is.close();
               os.close();
            } catch (IOException var9) {
               ;
            }
         }
      }

   }

   static {
      cachedir = new File(Minecraft.func_71410_x().field_71412_D, "cachedImages/skins/");
      skinOut = new File(cachedir, "temp.png");
   }
}
