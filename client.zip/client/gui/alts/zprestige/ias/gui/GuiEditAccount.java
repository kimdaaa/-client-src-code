package client.gui.alts.zprestige.ias.gui;

import client.gui.alts.tools.alt.AccountData;
import client.gui.alts.tools.alt.AltDatabase;
import client.gui.alts.zprestige.ias.account.ExtendedAccountData;
import client.gui.alts.zprestige.ias.enums.EnumBool;
import client.gui.alts.zprestige.ias.tools.JavaTools;
import client.gui.alts.zprestige.iasencrypt.EncryptionTools;

class GuiEditAccount extends AbstractAccountGui {
   private final ExtendedAccountData data;
   private final int selectedIndex;

   public GuiEditAccount(int index) {
      super("Edit account");
      this.selectedIndex = index;
      AccountData data = (AccountData)AltDatabase.getInstance().getAlts().get(index);
      if (data instanceof ExtendedAccountData) {
         this.data = (ExtendedAccountData)data;
      } else {
         this.data = new ExtendedAccountData(data.user, data.pass, data.alias, 0, JavaTools.getJavaCompat().getDate(), EnumBool.UNKNOWN);
      }

   }

   public void func_73866_w_() {
      super.func_73866_w_();
      this.setUsername(EncryptionTools.decode(this.data.user));
      this.setPassword(EncryptionTools.decode(this.data.pass));
   }

   public void complete() {
      AltDatabase.getInstance().getAlts().set(this.selectedIndex, new ExtendedAccountData(this.getUsername(), this.getPassword(), this.hasUserChanged ? this.getUsername() : this.data.alias, this.data.useCount, this.data.lastused, this.data.premium));
   }
}
