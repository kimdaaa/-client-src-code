package client.gui.alts.zprestige.ias;

import client.gui.alts.MR;
import client.gui.alts.zprestige.ias.config.ConfigValues;
import client.gui.alts.zprestige.ias.events.ClientEvents;
import client.gui.alts.zprestige.ias.tools.SkinTools;
import client.gui.alts.zprestige.iasencrypt.Standards;
import net.minecraft.client.resources.I18n;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.common.config.Property;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(
   modid = "ias",
   name = "Client 2.0.0 Account Switcher",
   clientSideOnly = true,
   guiFactory = "client.gui.alts.zprestige.ias.config.IASGuiFactory",
   updateJSON = "http://thefireplace.bitnamiapp.com/jsons/ias.json",
   acceptedMinecraftVersions = "[1.11,)"
)
public class IAS {
   public static Configuration config;
   private static Property CASESENSITIVE_PROPERTY;
   private static Property ENABLERELOG_PROPERTY;

   public static void syncConfig() {
      ConfigValues.CASESENSITIVE = CASESENSITIVE_PROPERTY.getBoolean();
      ConfigValues.ENABLERELOG = ENABLERELOG_PROPERTY.getBoolean();
      if (config.hasChanged()) {
         config.save();
      }

   }

   @EventHandler
   public void preInit(FMLPreInitializationEvent event) {
      config = new Configuration(event.getSuggestedConfigurationFile());
      config.load();
      CASESENSITIVE_PROPERTY = config.get("general", "Case sensitive", false, I18n.func_135052_a("Case sensitive.tooltip", new Object[0]));
      ENABLERELOG_PROPERTY = config.get("general", "Enable relog", false, I18n.func_135052_a("Enable relog.tooltip", new Object[0]));
      syncConfig();
      if (!event.getModMetadata().version.equals("${version}")) {
         Standards.updateFolder();
      } else {
         System.out.println("Dev environment detected!");
      }

   }

   @EventHandler
   public void init(FMLInitializationEvent event) {
      MR.init();
      MinecraftForge.EVENT_BUS.register(new ClientEvents());
      Standards.importAccounts();
   }

   @EventHandler
   public void postInit(FMLPostInitializationEvent event) {
      SkinTools.cacheSkins();
   }
}
