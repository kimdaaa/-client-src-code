package client.gui.alts.zprestige.ias.account;

import client.gui.alts.tools.alt.AccountData;
import client.gui.alts.zprestige.ias.enums.EnumBool;
import client.gui.alts.zprestige.ias.tools.JavaTools;
import java.util.Arrays;

public class ExtendedAccountData extends AccountData {
   private static final long serialVersionUID = -909128662161235160L;
   public EnumBool premium;
   public int[] lastused;
   public int useCount;

   public ExtendedAccountData(String user, String pass, String alias) {
      super(user, pass, alias);
      this.useCount = 0;
      this.lastused = JavaTools.getJavaCompat().getDate();
      this.premium = EnumBool.UNKNOWN;
   }

   public ExtendedAccountData(String user, String pass, String alias, int useCount, int[] lastused, EnumBool premium) {
      super(user, pass, alias);
      this.useCount = useCount;
      this.lastused = lastused;
      this.premium = premium;
   }

   public boolean equals(Object obj) {
      if (this == obj) {
         return true;
      } else if (obj == null) {
         return false;
      } else if (this.getClass() != obj.getClass()) {
         return false;
      } else {
         ExtendedAccountData other = (ExtendedAccountData)obj;
         if (!Arrays.equals(this.lastused, other.lastused)) {
            return false;
         } else if (this.premium != other.premium) {
            return false;
         } else if (this.useCount != other.useCount) {
            return false;
         } else {
            return this.user.equals(other.user) && this.pass.equals(other.pass);
         }
      }
   }
}
