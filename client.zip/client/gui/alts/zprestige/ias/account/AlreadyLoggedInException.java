package client.gui.alts.zprestige.ias.account;

import net.minecraft.client.resources.I18n;

public class AlreadyLoggedInException extends Exception {
   private static final long serialVersionUID = -7572892045698003265L;

   public String getLocalizedMessage() {
      return I18n.func_135052_a("already logged in", new Object[0]);
   }
}
