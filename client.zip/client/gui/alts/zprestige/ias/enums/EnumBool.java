package client.gui.alts.zprestige.ias.enums;

public enum EnumBool {
   TRUE,
   FALSE,
   UNKNOWN;
}
