package client.gui.alts.zprestige.iasencrypt;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

public final class EncryptionTools {
   public static final String DEFAULT_ENCODING = "UTF-8";
   private static final Encoder encoder = Base64.getEncoder();
   private static final Decoder decoder = Base64.getDecoder();
   private static final MessageDigest sha512 = getSha512Hasher();
   private static final KeyGenerator keyGen = getAESGenerator();
   private static final String secretSalt = "${secretSalt}";

   public static String decodeOld(String text) {
      try {
         return new String(decoder.decode(text), "UTF-8");
      } catch (IOException var2) {
         return null;
      }
   }

   public static String encode(String text) {
      try {
         byte[] data = text.getBytes("UTF-8");
         Cipher cipher = Cipher.getInstance("AES");
         cipher.init(1, getSecretKey());
         return new String(encoder.encode(cipher.doFinal(data)));
      } catch (BadPaddingException var3) {
         throw new RuntimeException("The password does not match", var3);
      } catch (InvalidKeyException | IOException | NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException var4) {
         throw new RuntimeException(var4);
      }
   }

   public static String decode(String text) {
      try {
         byte[] data = decoder.decode(text);
         Cipher cipher = Cipher.getInstance("AES");
         cipher.init(2, getSecretKey());
         return new String(cipher.doFinal(data), "UTF-8");
      } catch (BadPaddingException var3) {
         throw new RuntimeException("The password does not match", var3);
      } catch (InvalidKeyException | IOException | NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException var4) {
         throw new RuntimeException(var4);
      }
   }

   public static String generatePassword() {
      keyGen.init(256);
      return new String(encoder.encode(keyGen.generateKey().getEncoded()));
   }

   private static MessageDigest getSha512Hasher() {
      try {
         return MessageDigest.getInstance("SHA-512");
      } catch (NoSuchAlgorithmException var1) {
         throw new RuntimeException(var1);
      }
   }

   private static KeyGenerator getAESGenerator() {
      try {
         return KeyGenerator.getInstance("AES");
      } catch (NoSuchAlgorithmException var1) {
         throw new RuntimeException(var1);
      }
   }

   private static SecretKeySpec getSecretKey() {
      try {
         String password = "${secretSalt}" + Standards.getPassword() + "${secretSalt}";
         byte[] key = Arrays.copyOf(sha512.digest(password.getBytes("UTF-8")), 16);
         return new SecretKeySpec(key, "AES");
      } catch (UnsupportedEncodingException var2) {
         throw new RuntimeException(var2);
      }
   }
}
