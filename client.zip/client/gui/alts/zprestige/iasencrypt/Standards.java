package client.gui.alts.zprestige.iasencrypt;

import client.gui.alts.tools.Config;
import client.gui.alts.tools.alt.AccountData;
import client.gui.alts.tools.alt.AltDatabase;
import client.gui.alts.zprestige.ias.account.ExtendedAccountData;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.DosFileAttributeView;
import java.nio.file.attribute.DosFileAttributes;
import java.util.Iterator;
import net.minecraft.client.Minecraft;

public final class Standards {
   public static File IASFOLDER;
   public static final String cfgn = ".iasx";
   public static final String pwdn = ".iasp";

   public static String getPassword() {
      File passwordFile = new File(IASFOLDER, ".iasp");
      String newPass;
      if (passwordFile.exists()) {
         try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream(passwordFile));
            newPass = (String)stream.readObject();
            stream.close();
            return newPass;
         } catch (ClassNotFoundException | IOException var5) {
            throw new RuntimeException(var5);
         }
      } else {
         newPass = EncryptionTools.generatePassword();

         try {
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(passwordFile));
            out.writeObject(newPass);
            out.close();
         } catch (IOException var7) {
            throw new RuntimeException(var7);
         }

         try {
            Path file = passwordFile.toPath();
            DosFileAttributes attr = (DosFileAttributes)Files.readAttributes(file, DosFileAttributes.class);
            DosFileAttributeView view = (DosFileAttributeView)Files.getFileAttributeView(file, DosFileAttributeView.class);
            if (!attr.isHidden()) {
               view.setHidden(true);
            }
         } catch (Exception var6) {
            var6.printStackTrace();
         }

         return newPass;
      }
   }

   public static void updateFolder() {
      String OS = System.getProperty("os.name").toUpperCase();
      String dir;
      if (OS.contains("WIN")) {
         dir = System.getenv("AppData");
      } else {
         dir = System.getProperty("user.home");
         if (OS.contains("MAC")) {
            dir = dir + "/Library/Application Support";
         }
      }

      IASFOLDER = new File(dir);
   }

   public static void importAccounts() {
      processData(getConfigV3());
      processData(getConfigV2());
      processData(getConfigV1(), false);
   }

   private static boolean hasData(AccountData data) {
      Iterator var1 = AltDatabase.getInstance().getAlts().iterator();

      AccountData edata;
      do {
         if (!var1.hasNext()) {
            return false;
         }

         edata = (AccountData)var1.next();
      } while(!edata.equalsBasic(data));

      return true;
   }

   private static void processData(Config olddata) {
      processData(olddata, true);
   }

   private static void processData(Config olddata, boolean decrypt) {
      if (olddata != null) {
         Iterator var2 = ((AltDatabase)olddata.getKey("altaccounts")).getAlts().iterator();

         while(var2.hasNext()) {
            AccountData data = (AccountData)var2.next();
            AccountData data2 = convertData(data, decrypt);
            if (!hasData(data2)) {
               AltDatabase.getInstance().getAlts().add(data2);
            }
         }
      }

   }

   private static ExtendedAccountData convertData(AccountData oldData, boolean decrypt) {
      if (decrypt) {
         return oldData instanceof ExtendedAccountData ? new ExtendedAccountData(EncryptionTools.decodeOld(oldData.user), EncryptionTools.decodeOld(oldData.pass), oldData.alias, ((ExtendedAccountData)oldData).useCount, ((ExtendedAccountData)oldData).lastused, ((ExtendedAccountData)oldData).premium) : new ExtendedAccountData(EncryptionTools.decodeOld(oldData.user), EncryptionTools.decodeOld(oldData.pass), oldData.alias);
      } else {
         return oldData instanceof ExtendedAccountData ? new ExtendedAccountData(oldData.user, oldData.pass, oldData.alias, ((ExtendedAccountData)oldData).useCount, ((ExtendedAccountData)oldData).lastused, ((ExtendedAccountData)oldData).premium) : new ExtendedAccountData(oldData.user, oldData.pass, oldData.alias);
      }
   }

   private static Config getConfigV3() {
      File f = new File(IASFOLDER, ".ias");
      Config cfg = null;
      if (f.exists()) {
         try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream(f));
            cfg = (Config)stream.readObject();
            stream.close();
         } catch (ClassNotFoundException | IOException var3) {
            var3.printStackTrace();
         }

         f.delete();
      }

      return cfg;
   }

   private static Config getConfigV2() {
      File f = new File(Minecraft.func_71410_x().field_71412_D, ".ias");
      Config cfg = null;
      if (f.exists()) {
         try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream(f));
            cfg = (Config)stream.readObject();
            stream.close();
         } catch (ClassNotFoundException | IOException var3) {
            var3.printStackTrace();
         }

         f.delete();
      }

      return cfg;
   }

   private static Config getConfigV1() {
      File f = new File(Minecraft.func_71410_x().field_71412_D, "user.cfg");
      Config cfg = null;
      if (f.exists()) {
         try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream(f));
            cfg = (Config)stream.readObject();
            stream.close();
         } catch (ClassNotFoundException | IOException var3) {
            var3.printStackTrace();
         }

         f.delete();
      }

      return cfg;
   }

   static {
      IASFOLDER = Minecraft.func_71410_x().field_71412_D;
   }
}
