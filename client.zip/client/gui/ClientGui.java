package client.gui;

import client.Client;
import client.gui.impl.Component;
import client.gui.impl.Item;
import client.gui.impl.background.Snow;
import client.gui.impl.background.particles.ParticleSystem;
import client.gui.impl.button.ModuleButton;
import client.modules.Feature;
import client.modules.Module;
import client.modules.client.ClickGui;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class ClientGui extends GuiScreen {
   private static ClientGui INSTANCE = new ClientGui();
   private final ArrayList _snowList = new ArrayList();
   public ParticleSystem particleSystem;
   private final ArrayList components = new ArrayList();

   public ClientGui() {
      this.setInstance();
      this.load();
   }

   public static ClientGui getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new ClientGui();
      }

      return INSTANCE;
   }

   public void func_73866_w_() {
      if (OpenGlHelper.field_148824_g && this.field_146297_k.func_175606_aa() instanceof EntityPlayer && ((Boolean)ClickGui.getInstance().blur.getCurrentState()).booleanValue() && ClickGui.getInstance().gui.getCurrentState() == ClickGui.Gui.OLD) {
         if (this.field_146297_k.field_71460_t.func_147706_e() != null) {
            this.field_146297_k.field_71460_t.func_147706_e().func_148021_a();
         }

         this.field_146297_k.field_71460_t.func_175069_a(new ResourceLocation("shaders/post/blur.json"));
      }

      if (OpenGlHelper.field_148824_g && this.field_146297_k.func_175606_aa() instanceof EntityPlayer && ClickGui.getInstance().gui.getCurrentState() == ClickGui.Gui.NEW) {
         if (this.field_146297_k.field_71460_t.func_147706_e() != null) {
            this.field_146297_k.field_71460_t.func_147706_e().func_148021_a();
         }

         this.field_146297_k.field_71460_t.func_175069_a(new ResourceLocation("shaders/post/blur.json"));
      }

   }

   public void func_146281_b() {
      if (this.field_146297_k.field_71460_t.func_147706_e() != null) {
         this.field_146297_k.field_71460_t.func_147706_e().func_148021_a();
      }

   }

   public static ClientGui getClickGui() {
      return getInstance();
   }

   private void setInstance() {
      INSTANCE = this;
   }

   private void load() {
      int x = -84;
      Random random = new Random();

      for(int i = 0; i < 100; ++i) {
         for(int y = 0; y < 3; ++y) {
            Snow snow = new Snow(25 * i, y * -50, random.nextInt(3) + 1, random.nextInt(2) + 1);
            this._snowList.add(snow);
         }
      }

      Iterator var6 = Client.moduleManager.getCategories().iterator();

      while(var6.hasNext()) {
         final Module.Category category = (Module.Category)var6.next();
         ArrayList var10000 = this.components;
         String var10004 = category.getName();
         x += 110;
         var10000.add(new Component(var10004, x, 10, true) {
            public void setupItems() {
               counter1 = new int[]{1};
               Client.moduleManager.getModulesByCategory(category).forEach((module) -> {
                  this.addButton(new ModuleButton(module));
               });
            }
         });
      }

      this.components.forEach((components) -> {
         components.getItems().sort(Comparator.comparing(Feature::getName));
      });
   }

   public void updateModule(Module module) {
      Iterator var2 = this.components.iterator();

      while(var2.hasNext()) {
         Component component = (Component)var2.next();
         Iterator var4 = component.getItems().iterator();

         while(var4.hasNext()) {
            Item item = (Item)var4.next();
            if (item instanceof ModuleButton) {
               ModuleButton button = (ModuleButton)item;
               Module mod = button.getModule();
               if (module != null && module.equals(mod)) {
                  button.initSettings();
               }
            }
         }
      }

   }

   public static void drawCompleteImage(int posX, int posY, int width, int height) {
      GL11.glPushMatrix();
      GL11.glTranslatef((float)posX, (float)posY, 0.0F);
      GL11.glBegin(7);
      GL11.glTexCoord2f(0.0F, 0.0F);
      GL11.glVertex3f(0.0F, 0.0F, 0.0F);
      GL11.glTexCoord2f(0.0F, 1.0F);
      GL11.glVertex3f(0.0F, (float)height, 0.0F);
      GL11.glTexCoord2f(1.0F, 1.0F);
      GL11.glVertex3f((float)width, (float)height, 0.0F);
      GL11.glTexCoord2f(1.0F, 0.0F);
      GL11.glVertex3f((float)width, 0.0F, 0.0F);
      GL11.glEnd();
      GL11.glPopMatrix();
   }

   public void drawImageLogo() {
      ResourceLocation logo = new ResourceLocation("textures/logo.png");
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      this.field_146297_k.func_110434_K().func_110577_a(logo);
      drawCompleteImage(0, 464, 250, 48);
      this.field_146297_k.func_110434_K().func_147645_c(logo);
      GlStateManager.func_179147_l();
      GlStateManager.func_179090_x();
   }

   public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
      ScaledResolution res = new ScaledResolution(this.field_146297_k);
      if (!this._snowList.isEmpty() && ((Boolean)ClickGui.getInstance().snowing.getCurrentState()).booleanValue() && ClickGui.getInstance().gui.getCurrentState() == ClickGui.Gui.OLD) {
         this._snowList.forEach((snow) -> {
            snow.Update(res);
         });
      }

      if (this.particleSystem != null && ClickGui.getInstance().gui.getCurrentState() == ClickGui.Gui.OLD) {
         this.particleSystem.render(mouseX, mouseY);
      } else {
         this.particleSystem = new ParticleSystem(new ScaledResolution(this.field_146297_k));
      }

      this.checkMouseWheel();
      this.drawImageLogo();
      this.components.forEach((components) -> {
         components.drawScreen(mouseX, mouseY, partialTicks);
      });
   }

   public void func_73864_a(int mouseX, int mouseY, int clickedButton) {
      this.components.forEach((components) -> {
         components.mouseClicked(mouseX, mouseY, clickedButton);
      });
   }

   public void func_146286_b(int mouseX, int mouseY, int releaseButton) {
      this.components.forEach((components) -> {
         components.mouseReleased(mouseX, mouseY, releaseButton);
      });
   }

   public boolean func_73868_f() {
      return false;
   }

   public final ArrayList getComponents() {
      return this.components;
   }

   public void checkMouseWheel() {
      int dWheel = Mouse.getDWheel();
      if (dWheel < 0) {
         this.components.forEach((component) -> {
            component.setY(component.getY() - 10);
         });
      } else if (dWheel > 0) {
         this.components.forEach((component) -> {
            component.setY(component.getY() + 10);
         });
      }

   }

   public int getTextOffset() {
      return -6;
   }

   public void func_73869_a(char typedChar, int keyCode) throws IOException {
      super.func_73869_a(typedChar, keyCode);
      this.components.forEach((component) -> {
         component.onKeyTyped(typedChar, keyCode);
      });
   }

   public void func_73876_c() {
      if (this.particleSystem != null) {
         this.particleSystem.update();
      }

   }
}
