package client.mixin;

import client.events.JesusEvent;
import client.modules.player.Interactions;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({BlockLiquid.class})
public class MixinLiquidBlock extends Block {
   protected MixinLiquidBlock(Material materialIn) {
      super(materialIn);
   }

   @Inject(
      method = {"canCollideCheck"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void canCollideCheckHook(IBlockState blockState, boolean hitIfLiquid, CallbackInfoReturnable info) {
      info.setReturnValue(hitIfLiquid && ((Integer)blockState.func_177229_b(BlockLiquid.field_176367_b)).intValue() == 0 || Interactions.getInstance().isOn() && ((Boolean)Interactions.getInstance().liquid.getCurrentState()).booleanValue());
   }

   @Inject(
      method = {"getCollisionBoundingBox"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void getCollisionBoundingBoxHook(IBlockState blockState, IBlockAccess worldIn, BlockPos pos, CallbackInfoReturnable info) {
      JesusEvent event = new JesusEvent(0, pos);
      MinecraftForge.EVENT_BUS.post(event);
      if (event.isCanceled()) {
         info.setReturnValue(event.getBoundingBox());
      }

   }
}
