package client.mixin;

import client.events.BlockEvent;
import client.events.BlockResetEvent;
import client.events.ClickBlockEvent;
import client.modules.player.Interactions;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerControllerMP.class})
public abstract class MixinPlayerControllerMP {
   @Inject(
      method = {"clickBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void clickBlock(BlockPos loc, EnumFacing face, CallbackInfoReturnable cir) {
      ClickBlockEvent event = new ClickBlockEvent(0, loc, face);
      MinecraftForge.EVENT_BUS.post(event);
      if (event.isCanceled()) {
         cir.cancel();
      }

   }

   @Inject(
      method = {"clickBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void clickBlockHook(BlockPos pos, EnumFacing face, CallbackInfoReturnable info) {
      BlockEvent event = new BlockEvent(3, pos, face);
      MinecraftForge.EVENT_BUS.post(event);
   }

   @Inject(
      method = {"onPlayerDamageBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onPlayerDamageBlockHook(BlockPos pos, EnumFacing face, CallbackInfoReturnable info) {
      BlockEvent event = new BlockEvent(4, pos, face);
      MinecraftForge.EVENT_BUS.post(event);
   }

   @Inject(
      method = {"onPlayerDamageBlock(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Z"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onPlayerDamageBlock(BlockPos posBlock, EnumFacing directionFacing, CallbackInfoReturnable cir) {
      ClickBlockEvent event = new ClickBlockEvent(1, posBlock, directionFacing);
      MinecraftForge.EVENT_BUS.post(event);
      if (event.isCanceled()) {
         cir.cancel();
      }

   }

   @Inject(
      method = {"resetBlockRemoving"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void resetBlock(CallbackInfo info) {
      BlockResetEvent blockResetEvent = new BlockResetEvent();
      MinecraftForge.EVENT_BUS.post(blockResetEvent);
      if (blockResetEvent.isCanceled()) {
         info.cancel();
      }

   }

   @Inject(
      method = {"getBlockReachDistance"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void getReachDistanceHook(CallbackInfoReturnable distance) {
      if (Interactions.getInstance().isOn() && ((Boolean)Interactions.getInstance().reach.getCurrentState()).booleanValue()) {
         float range = ((Float)distance.getReturnValue()).floatValue();
         distance.setReturnValue(Interactions.getInstance().reachAmount.getCurrentState());
      }

   }
}
