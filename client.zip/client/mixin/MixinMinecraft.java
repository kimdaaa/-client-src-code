package client.mixin;

import client.Client;
import client.gui.impl.background.MainMenuScreen;
import client.gui.impl.background.MenuToggler;
import client.util.Util;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.crash.CrashReport;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Minecraft.class})
public abstract class MixinMinecraft implements Util {
   @Inject(
      method = {"shutdownMinecraftApplet"},
      at = {@At("HEAD")}
   )
   private void stopClient(CallbackInfo callbackInfo) {
      this.unload();
   }

   @Redirect(
      method = {"run"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/Minecraft;displayCrashReport(Lnet/minecraft/crash/CrashReport;)V"
)
   )
   public void displayCrashReport(Minecraft minecraft, CrashReport crashReport) {
      this.unload();
   }

   private void unload() {
      Client.LOGGER.info("Initiated client shutdown.");
      Client.onUnload();
      Client.LOGGER.info("Finished client shutdown.");
   }

   @Inject(
      method = {"runTick()V"},
      at = {@At("RETURN")}
   )
   private void runTick(CallbackInfo callbackInfo) {
      if (Minecraft.func_71410_x().field_71462_r instanceof GuiMainMenu && MenuToggler.getInstance().isOn()) {
         Minecraft.func_71410_x().func_147108_a(new MainMenuScreen());
      }

   }

   @Shadow
   public abstract void func_147108_a(@Nullable GuiScreen var1);

   @Inject(
      method = {"displayGuiScreen"},
      at = {@At("HEAD")}
   )
   private void displayGuiScreen(GuiScreen screen, CallbackInfo ci) {
      if (screen instanceof GuiMainMenu) {
         this.func_147108_a(new MainMenuScreen());
      }

   }
}
