package client.mixin;

import client.Client;
import client.modules.client.ClickGui;
import client.util.ColorUtil;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ChatLine;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiNewChat;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(
   value = {GuiNewChat.class},
   priority = 999999999
)
public class MixinGuiNewChat extends Gui {
   @Shadow
   @Final
   public List field_146253_i;
   private ChatLine chatLine;

   @Redirect(
      method = {"drawChat"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/FontRenderer;drawStringWithShadow(Ljava/lang/String;FFI)I"
)
   )
   private int drawStringWithShadow(FontRenderer fontRenderer, String text, float x, float y, int color) {
      if (text.contains("§+")) {
         int[] arrayOfInt = new int[]{1};
         char[] stringToCharArray = text.toCharArray();
         float f = 0.0F;
         char[] var9 = stringToCharArray;
         int var10 = stringToCharArray.length;

         for(int var11 = 0; var11 < var10; ++var11) {
            char c = var9[var11];
            Client.textManager.drawString(String.valueOf(c), x + f, y, ColorUtil.rainbowHud(arrayOfInt[0] * ((Integer)ClickGui.getInstance().rainbowHue.getCurrentState()).intValue()).getRGB(), true);
            f += (float)Client.textManager.getStringWidth(String.valueOf(c));
            ++arrayOfInt[0];
         }
      } else {
         Minecraft.func_71410_x().field_71466_p.func_175063_a(text, x, y, color);
      }

      return 0;
   }
}
