package client.mixin;

import client.events.RenderEntityModelEvent;
import client.modules.visual.CrystalChanger;
import client.util.ColorUtil;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderEnderCrystal;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(
   value = {RenderEnderCrystal.class},
   priority = 9999999
)
public class MixinRenderModifiedCrystal {
   private static ResourceLocation ENDER_CRYSTAL_TEXTURES;

   @SubscribeEvent
   @Redirect(
      method = {"doRender"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/model/ModelBase;render(Lnet/minecraft/entity/Entity;FFFFFF)V"
)
   )
   public void renderModelBasezPrestigesSexyBelly(ModelBase model, Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
      if (CrystalChanger.getInstance().isEnabled()) {
         GlStateManager.func_179152_a(((Double)CrystalChanger.getInstance().scale.getCurrentState()).floatValue(), ((Double)CrystalChanger.getInstance().scale.getCurrentState()).floatValue(), ((Double)CrystalChanger.getInstance().scale.getCurrentState()).floatValue());
      }

      if (CrystalChanger.getInstance().isEnabled() && ((Boolean)CrystalChanger.getInstance().wireframe.getCurrentState()).booleanValue()) {
         RenderEntityModelEvent event = new RenderEntityModelEvent(0, model, entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
         CrystalChanger.getInstance().onRenderModel(event);
      }

      if (CrystalChanger.getInstance().isEnabled() && ((Boolean)CrystalChanger.getInstance().chams.getCurrentState()).booleanValue()) {
         GL11.glPushAttrib(1048575);
         GL11.glDisable(3008);
         GL11.glDisable(3553);
         GL11.glDisable(2896);
         GL11.glEnable(3042);
         GL11.glBlendFunc(770, 771);
         GL11.glLineWidth(1.5F);
         GL11.glEnable(2960);
         int visibleColor;
         if (((Boolean)CrystalChanger.getInstance().XQZ.getCurrentState()).booleanValue() && ((Boolean)CrystalChanger.getInstance().throughwalls.getCurrentState()).booleanValue()) {
            visibleColor = ColorUtil.toRGBA(((Integer)CrystalChanger.getInstance().h_red.getCurrentState()).intValue(), ((Integer)CrystalChanger.getInstance().h_green.getCurrentState()).intValue(), ((Integer)CrystalChanger.getInstance().h_blue.getCurrentState()).intValue(), ((Integer)CrystalChanger.getInstance().h_alpha.getCurrentState()).intValue());
            int visibleColor = ColorUtil.toRGBA(((Integer)CrystalChanger.getInstance().red.getCurrentState()).intValue(), ((Integer)CrystalChanger.getInstance().green.getCurrentState()).intValue(), ((Integer)CrystalChanger.getInstance().blue.getCurrentState()).intValue(), ((Integer)CrystalChanger.getInstance().alpha.getCurrentState()).intValue());
            if (((Boolean)CrystalChanger.getInstance().throughwalls.getCurrentState()).booleanValue()) {
               GL11.glDisable(2929);
               GL11.glDepthMask(false);
            }

            GL11.glEnable(10754);
            GL11.glColor4f((float)((Integer)CrystalChanger.getInstance().h_red.getCurrentState()).intValue() / 255.0F, (float)((Integer)CrystalChanger.getInstance().h_green.getCurrentState()).intValue() / 255.0F, (float)((Integer)CrystalChanger.getInstance().h_blue.getCurrentState()).intValue() / 255.0F, (float)((Integer)CrystalChanger.getInstance().alpha.getCurrentState()).intValue() / 255.0F);
            model.func_78088_a(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            if (((Boolean)CrystalChanger.getInstance().throughwalls.getCurrentState()).booleanValue()) {
               GL11.glEnable(2929);
               GL11.glDepthMask(true);
            }

            GL11.glColor4f((float)((Integer)CrystalChanger.getInstance().red.getCurrentState()).intValue() / 255.0F, (float)((Integer)CrystalChanger.getInstance().green.getCurrentState()).intValue() / 255.0F, (float)((Integer)CrystalChanger.getInstance().blue.getCurrentState()).intValue() / 255.0F, (float)((Integer)CrystalChanger.getInstance().alpha.getCurrentState()).intValue() / 255.0F);
            model.func_78088_a(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
         } else {
            visibleColor = ColorUtil.toRGBA(((Integer)CrystalChanger.getInstance().red.getCurrentState()).intValue(), ((Integer)CrystalChanger.getInstance().green.getCurrentState()).intValue(), ((Integer)CrystalChanger.getInstance().blue.getCurrentState()).intValue(), ((Integer)CrystalChanger.getInstance().alpha.getCurrentState()).intValue());
            if (((Boolean)CrystalChanger.getInstance().throughwalls.getCurrentState()).booleanValue()) {
               GL11.glDisable(2929);
               GL11.glDepthMask(false);
            }

            GL11.glEnable(10754);
            GL11.glColor4f((float)((Integer)CrystalChanger.getInstance().red.getCurrentState()).intValue() / 255.0F, (float)((Integer)CrystalChanger.getInstance().green.getCurrentState()).intValue() / 255.0F, (float)((Integer)CrystalChanger.getInstance().blue.getCurrentState()).intValue() / 255.0F, (float)((Integer)CrystalChanger.getInstance().alpha.getCurrentState()).intValue() / 255.0F);
            model.func_78088_a(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            if (((Boolean)CrystalChanger.getInstance().throughwalls.getCurrentState()).booleanValue()) {
               GL11.glEnable(2929);
               GL11.glDepthMask(true);
            }
         }

         GL11.glEnable(3042);
         GL11.glEnable(2896);
         GL11.glEnable(3553);
         GL11.glEnable(3008);
         GL11.glPopAttrib();
         if (((Boolean)CrystalChanger.getInstance().glint.getCurrentState()).booleanValue()) {
            GL11.glDisable(2929);
            GL11.glDepthMask(false);
            GlStateManager.func_179141_d();
            GlStateManager.func_179131_c(1.0F, 0.0F, 0.0F, 0.13F);
            model.func_78088_a(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            GlStateManager.func_179118_c();
            GL11.glEnable(2929);
            GL11.glDepthMask(true);
         }
      } else {
         model.func_78088_a(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
      }

      if (CrystalChanger.getInstance().isEnabled()) {
         GlStateManager.func_179152_a(1.0F / ((Double)CrystalChanger.getInstance().scale.getCurrentState()).floatValue(), 1.0F / ((Double)CrystalChanger.getInstance().scale.getCurrentState()).floatValue(), 1.0F / ((Double)CrystalChanger.getInstance().scale.getCurrentState()).floatValue());
      }

   }
}
