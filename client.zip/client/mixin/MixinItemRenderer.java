package client.mixin;

import client.modules.visual.Viewmodel;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({RenderItem.class})
public abstract class MixinItemRenderer {
   @Inject(
      method = {"renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType;Z)V"},
      at = {@At("INVOKE")}
   )
   public void renderItem(ItemStack stack, EntityLivingBase entitylivingbaseIn, TransformType transform, boolean leftHanded, CallbackInfo ci) {
      if (Viewmodel.getINSTANCE().isEnabled() && (transform == TransformType.FIRST_PERSON_LEFT_HAND || transform == TransformType.FIRST_PERSON_RIGHT_HAND)) {
         Viewmodel changer = Viewmodel.getINSTANCE();
         GlStateManager.func_179152_a(((Float)Viewmodel.getINSTANCE().sizeX.getCurrentState()).floatValue(), ((Float)Viewmodel.getINSTANCE().sizeY.getCurrentState()).floatValue(), ((Float)Viewmodel.getINSTANCE().sizeZ.getCurrentState()).floatValue());
         if (transform.equals(TransformType.FIRST_PERSON_LEFT_HAND)) {
            GL11.glTranslated((double)(((Float)changer.offhandX.getCurrentState()).floatValue() / 4.0F), (double)(((Float)changer.offhandY.getCurrentState()).floatValue() / 4.0F), (double)(((Float)changer.offhandZ.getCurrentState()).floatValue() / 4.0F));
         } else {
            GL11.glTranslated((double)(((Float)changer.offsetX.getCurrentState()).floatValue() / 4.0F), (double)(((Float)changer.offsetY.getCurrentState()).floatValue() / 4.0F), (double)(((Float)changer.offsetZ.getCurrentState()).floatValue() / 4.0F));
         }
      }

   }
}
