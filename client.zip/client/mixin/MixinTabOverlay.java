package client.mixin;

import client.modules.miscellaneous.TabTweaks;
import java.util.List;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.network.NetworkPlayerInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({GuiPlayerTabOverlay.class})
public class MixinTabOverlay extends Gui {
   @Redirect(
      method = {"renderPlayerlist"},
      at = @At(
   value = "INVOKE",
   target = "Ljava/util/List;subList(II)Ljava/util/List;",
   remap = false
)
   )
   public List subListHook(List list, int fromIndex, int toIndex) {
      return list.subList(fromIndex, TabTweaks.getINSTANCE().isEnabled() ? Math.min(((Integer)TabTweaks.getINSTANCE().size.getCurrentState()).intValue(), list.size()) : toIndex);
   }

   @Inject(
      method = {"getPlayerName"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void getPlayerNameHook(NetworkPlayerInfo networkPlayerInfoIn, CallbackInfoReturnable info) {
      if (TabTweaks.getINSTANCE().isEnabled()) {
         info.setReturnValue(TabTweaks.getPlayerName(networkPlayerInfoIn));
      }

   }
}
