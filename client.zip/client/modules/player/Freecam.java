package client.modules.player;

import client.events.PacketEvent;
import client.events.PushEvent;
import client.gui.impl.setting.Setting;
import client.modules.Feature;
import client.modules.Module;
import client.util.MathUtil;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketInput;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Freecam extends Module {
   public Setting packet = this.register(new Setting("Packet", true));
   private AxisAlignedBB oldBoundingBox;
   private EntityOtherPlayerMP entity;
   private Vec3d position;
   private Entity riding;
   private float yaw;
   private float pitch;

   public Freecam() {
      super("Freecam", "Lets you fly around when ur really not...", Module.Category.PLAYER);
   }

   public void onEnable() {
      if (!Feature.fullNullCheck()) {
         this.oldBoundingBox = mc.field_71439_g.func_174813_aQ();
         mc.field_71439_g.func_174826_a(new AxisAlignedBB(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v));
         if (mc.field_71439_g.func_184187_bx() != null) {
            this.riding = mc.field_71439_g.func_184187_bx();
            mc.field_71439_g.func_184210_p();
         }

         (this.entity = new EntityOtherPlayerMP(mc.field_71441_e, mc.func_110432_I().func_148256_e())).func_82149_j(mc.field_71439_g);
         this.entity.field_70177_z = mc.field_71439_g.field_70177_z;
         this.entity.field_70759_as = mc.field_71439_g.field_70759_as;
         this.entity.field_71071_by.func_70455_b(mc.field_71439_g.field_71071_by);
         mc.field_71441_e.func_73027_a(69420, this.entity);
         this.position = mc.field_71439_g.func_174791_d();
         this.yaw = mc.field_71439_g.field_70177_z;
         this.pitch = mc.field_71439_g.field_70125_A;
         mc.field_71439_g.field_70145_X = true;
      }

   }

   public void onDisable() {
      if (!Feature.fullNullCheck()) {
         mc.field_71439_g.func_174826_a(this.oldBoundingBox);
         if (this.riding != null) {
            mc.field_71439_g.func_184205_a(this.riding, true);
         }

         if (this.entity != null) {
            mc.field_71441_e.func_72900_e(this.entity);
         }

         if (this.position != null) {
            mc.field_71439_g.func_70107_b(this.position.field_72450_a, this.position.field_72448_b, this.position.field_72449_c);
         }

         mc.field_71439_g.field_70177_z = this.yaw;
         mc.field_71439_g.field_70125_A = this.pitch;
         mc.field_71439_g.field_70145_X = false;
      }

   }

   public void onUpdate() {
      mc.field_71439_g.field_70145_X = true;
      mc.field_71439_g.func_70016_h(0.0D, 0.0D, 0.0D);
      mc.field_71439_g.field_70747_aH = 1.0F;
      double[] dir = MathUtil.directionSpeed(1.0D);
      if (mc.field_71439_g.field_71158_b.field_78902_a == 0.0F && mc.field_71439_g.field_71158_b.field_192832_b == 0.0F) {
         mc.field_71439_g.field_70159_w = 0.0D;
         mc.field_71439_g.field_70179_y = 0.0D;
      } else {
         mc.field_71439_g.field_70159_w = dir[0];
         mc.field_71439_g.field_70179_y = dir[1];
      }

      mc.field_71439_g.func_70031_b(false);
      mc.field_71439_g.field_70181_x = 1.0D * -MathUtil.degToRad((double)mc.field_71439_g.field_70125_A) * (double)mc.field_71439_g.field_71158_b.field_192832_b;
      EntityPlayerSP player2;
      if (mc.field_71474_y.field_74314_A.func_151470_d()) {
         player2 = mc.field_71439_g;
         ++player2.field_70181_x;
      }

      if (mc.field_71474_y.field_74311_E.func_151470_d()) {
         player2 = mc.field_71439_g;
         --player2.field_70181_x;
      }

   }

   public void onLogout() {
      this.disable();
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send event) {
      if (event.getStage() == 0 && (event.getPacket() instanceof CPacketPlayer || event.getPacket() instanceof CPacketInput)) {
         event.setCanceled(true);
      }

   }

   @SubscribeEvent
   public void onPush(PushEvent event) {
      if (event.getStage() == 1) {
         event.setCanceled(true);
      }

   }
}
