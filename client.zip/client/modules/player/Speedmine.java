package client.modules.player;

import client.Client;
import client.events.BlockEvent;
import client.events.Render3DEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.BlockUtil;
import client.util.RenderUtil;
import client.util.Timer;
import java.awt.Color;
import java.util.function.Predicate;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Speedmine extends Module {
   private static Speedmine INSTANCE = new Speedmine();
   private final Timer timer = new Timer();
   public Setting mode;
   public Setting render;
   public Setting box;
   private final Setting boxAlpha;
   public Setting outline;
   private final Setting lineWidth;
   public BlockPos currentPos;
   public IBlockState currentBlockState;

   public Speedmine() {
      super("Speedmine", "Speeds up mining.", Module.Category.PLAYER);
      this.mode = this.register(new Setting("Mode", Speedmine.Mode.PACKET));
      this.render = this.register(new Setting("Render", false));
      this.box = this.register(new Setting("Box", false, (v) -> {
         return ((Boolean)this.render.getCurrentState()).booleanValue();
      }));
      this.boxAlpha = this.register(new Setting("BoxAlpha", Integer.valueOf(85), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.box.getCurrentState()).booleanValue() && ((Boolean)this.render.getCurrentState()).booleanValue();
      }));
      this.outline = this.register(new Setting("Outline", true, (v) -> {
         return ((Boolean)this.render.getCurrentState()).booleanValue();
      }));
      this.lineWidth = this.register(new Setting("Width", 1.0F, 0.1F, 5.0F, (v) -> {
         return ((Boolean)this.outline.getCurrentState()).booleanValue() && ((Boolean)this.render.getCurrentState()).booleanValue();
      }));
      this.setInstance();
   }

   public static Speedmine getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new Speedmine();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public void onTick() {
      if (this.currentPos != null && (!mc.field_71441_e.func_180495_p(this.currentPos).equals(this.currentBlockState) || mc.field_71441_e.func_180495_p(this.currentPos).func_177230_c() == Blocks.field_150350_a)) {
         this.currentPos = null;
         this.currentBlockState = null;
      }

   }

   public void onUpdate() {
      if (!fullNullCheck()) {
         mc.field_71442_b.field_78781_i = 0;
      }
   }

   public void onRender3D(Render3DEvent event) {
      if (((Boolean)this.render.getCurrentState()).booleanValue() && this.currentPos != null && this.currentBlockState.func_177230_c() == Blocks.field_150343_Z) {
         Color color = new Color(this.timer.passedMs((long)((int)(2000.0F * Client.serverManager.getTpsFactor()))) ? 0 : 255, this.timer.passedMs((long)((int)(2000.0F * Client.serverManager.getTpsFactor()))) ? 255 : 0, 0, 255);
         RenderUtil.drawBoxESP(this.currentPos, color, false, color, ((Float)this.lineWidth.getCurrentState()).floatValue(), ((Boolean)this.outline.getCurrentState()).booleanValue(), ((Boolean)this.box.getCurrentState()).booleanValue(), ((Integer)this.boxAlpha.getCurrentState()).intValue(), false);
      }

   }

   @SubscribeEvent
   public void onBlockEvent(BlockEvent event) {
      if (!fullNullCheck()) {
         if (event.getStage() == 3 && mc.field_71442_b.field_78770_f > 0.1F) {
            mc.field_71442_b.field_78778_j = true;
         }

         if (event.getStage() == 4 && BlockUtil.canBreak(event.pos)) {
            mc.field_71442_b.field_78778_j = false;
            switch((Speedmine.Mode)this.mode.getCurrentState()) {
            case PACKET:
               if (this.currentPos == null) {
                  this.currentPos = event.pos;
                  this.currentBlockState = mc.field_71441_e.func_180495_p(this.currentPos);
                  this.timer.reset();
               }

               mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(Action.START_DESTROY_BLOCK, event.pos, event.facing));
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(Action.STOP_DESTROY_BLOCK, event.pos, event.facing));
               event.setCanceled(true);
               break;
            case INSTANT:
               mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(Action.START_DESTROY_BLOCK, event.pos, event.facing));
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(Action.STOP_DESTROY_BLOCK, event.pos, event.facing));
               mc.field_71442_b.func_187103_a(event.pos);
               mc.field_71441_e.func_175698_g(event.pos);
            }
         }

      }
   }

   public String getDisplayInfo() {
      return this.mode.currentEnumName();
   }

   public static enum Mode {
      PACKET,
      INSTANT;
   }
}
