package client.modules.player;

import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.InventoryUtil;
import java.util.function.Predicate;
import net.minecraft.init.Items;
import net.minecraft.item.ItemEndCrystal;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;

public class FastPlace extends Module {
   public Setting exp = this.register(new Setting("Exp", true));
   public Setting crazyFastExpExploit = this.register(new Setting("UltraSpeed", false));
   public Setting packets = this.register(new Setting("Packets", Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(20), (v) -> {
      return ((Boolean)this.crazyFastExpExploit.getCurrentState()).booleanValue();
   }));
   public Setting crystal = this.register(new Setting("Crystal", true));

   public FastPlace() {
      super("FastPlace", "Changes the delay of things", Module.Category.PLAYER);
   }

   public void onUpdate() {
      if (!fullNullCheck()) {
         if (InventoryUtil.holdingItem(ItemExpBottle.class) && ((Boolean)this.exp.getCurrentState()).booleanValue()) {
            mc.field_71467_ac = 0;
         }

         if (InventoryUtil.holdingItem(ItemEndCrystal.class) && ((Boolean)this.crystal.getCurrentState()).booleanValue()) {
            mc.field_71467_ac = 0;
         }

         if (((Boolean)this.crazyFastExpExploit.getCurrentState()).booleanValue() && InventoryUtil.holdingItem(ItemExpBottle.class)) {
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(this.HotbarEXP()));

            for(int i = 0; i < ((Integer)this.packets.getCurrentState()).intValue(); ++i) {
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
            }

            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(mc.field_71439_g.field_71071_by.field_70461_c));
         }

      }
   }

   private int HotbarEXP() {
      int slot = 0;

      for(int i = 0; i < 9; ++i) {
         if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == Items.field_151062_by) {
            slot = i;
            break;
         }
      }

      return slot;
   }
}
