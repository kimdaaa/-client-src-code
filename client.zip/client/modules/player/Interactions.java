package client.modules.player;

import client.events.PacketEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import java.util.function.Predicate;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Interactions extends Module {
   private static Interactions INSTANCE = new Interactions();
   public Setting liquid = this.register(new Setting("LiquidPlace", false));
   public Setting heightLimit = this.register(new Setting("HeightLimit", false));
   public Setting reach = this.register(new Setting("Reach", false));
   public Setting reachAmount = this.register(new Setting("ReachAmount", 6.0F, 0.0F, 10.0F, (v) -> {
      return ((Boolean)this.reach.getCurrentState()).booleanValue();
   }));

   public Interactions() {
      super("Interactions", "Changes the way you interact with things", Module.Category.PLAYER);
      this.setInstance();
   }

   public static Interactions getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new Interactions();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send event) {
      CPacketPlayerTryUseItemOnBlock packet;
      if (((Boolean)this.heightLimit.getCurrentState()).booleanValue() && event.getStage() == 0 && event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock && (packet = (CPacketPlayerTryUseItemOnBlock)event.getPacket()).func_187023_a().func_177956_o() >= 255 && packet.func_187024_b() == EnumFacing.UP) {
         packet.field_149579_d = EnumFacing.DOWN;
      }

   }
}
