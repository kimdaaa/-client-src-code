package client.modules.player;

import client.events.PacketEvent;
import client.mixin.AccessorSPacketPlayerPosLook;
import client.modules.Module;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AntiRotate extends Module {
   public AntiRotate() {
      super("AntiRotate", "", Module.Category.PLAYER);
   }

   @SubscribeEvent
   public void onPacket(PacketEvent.Receive event) {
      if (event.getPacket() instanceof SPacketPlayerPosLook) {
         AccessorSPacketPlayerPosLook packet = (AccessorSPacketPlayerPosLook)event.getPacket();
         packet.setPitch(mc.field_71439_g.field_70125_A);
         packet.setYaw(mc.field_71439_g.field_70177_z);
      }

      if (!fullNullCheck()) {
         ;
      }
   }
}
