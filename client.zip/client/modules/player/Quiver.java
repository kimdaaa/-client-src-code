package client.modules.player;

import client.command.Command;
import client.modules.Module;
import client.util.InventoryUtil;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.init.MobEffects;
import net.minecraft.init.PotionTypes;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTippedArrow;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.potion.PotionUtils;
import net.minecraft.util.math.BlockPos;

public class Quiver extends Module {
   private int timer = 0;
   private int stage = 1;
   private int returnSlot = -1;

   public Quiver() {
      super("Quiver", "Shoots arrows at yourself", Module.Category.PLAYER);
   }

   public void onDisable() {
      this.timer = 0;
      this.stage = 0;
      mc.field_71474_y.field_74313_G.field_74513_e = false;
      if (this.returnSlot != -1) {
         mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, 9, 0, ClickType.PICKUP, mc.field_71439_g);
         mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, this.returnSlot, 0, ClickType.PICKUP, mc.field_71439_g);
         mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, 9, 0, ClickType.PICKUP, mc.field_71439_g);
         this.returnSlot = -1;
      }

   }

   public void onTick() {
      if (!nullCheck()) {
         if (mc.field_71462_r == null) {
            InventoryUtil.switchToHotbarSlot(ItemBow.class, false);
            if (InventoryUtil.findHotbarBlock(ItemBow.class) == -1) {
               this.disable();
               Command.sendMessage(ChatFormatting.RED + "No bow found!");
            } else {
               mc.field_71439_g.field_71174_a.func_147297_a(new Rotation(mc.field_71439_g.field_70177_z, -90.0F, mc.field_71439_g.field_70122_E));
               if (this.stage == 0) {
                  if (!this.mapArrows()) {
                     this.disable();
                     Command.sendMessage(ChatFormatting.GREEN + "All effects applied!");
                     return;
                  }

                  ++this.stage;
               } else {
                  if (this.stage == 1) {
                     ++this.stage;
                     ++this.timer;
                     return;
                  }

                  if (this.stage == 2) {
                     mc.field_71474_y.field_74313_G.field_74513_e = true;
                     this.timer = 0;
                     ++this.stage;
                  } else if (this.stage == 3) {
                     if (this.timer > 4) {
                        ++this.stage;
                     }
                  } else if (this.stage == 4) {
                     mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, mc.field_71439_g.func_174811_aO()));
                     mc.field_71439_g.func_184602_cy();
                     mc.field_71474_y.field_74313_G.field_74513_e = false;
                     this.timer = 0;
                     ++this.stage;
                  } else if (this.stage == 5) {
                     if (this.timer < 10) {
                        ++this.timer;
                        return;
                     }

                     this.stage = 0;
                     this.timer = 0;
                  }
               }

               ++this.timer;
            }
         }
      }
   }

   private boolean mapArrows() {
      for(int a = 9; a < 45; ++a) {
         if (((ItemStack)mc.field_71439_g.field_71069_bz.func_75138_a().get(a)).func_77973_b() instanceof ItemTippedArrow) {
            ItemStack arrow = (ItemStack)mc.field_71439_g.field_71069_bz.func_75138_a().get(a);
            if ((PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185223_F) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185225_H) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185224_G)) && !mc.field_71439_g.func_70644_a(MobEffects.field_76420_g)) {
               this.switchTo(a);
               return true;
            }

            if ((PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185243_o) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185244_p) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185245_q)) && !mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
               this.switchTo(a);
               return true;
            }
         }
      }

      return false;
   }

   public String getDisplayInfo() {
      return "Stage: " + this.stage;
   }

   private void switchTo(int from) {
      if (from != 9) {
         this.returnSlot = from;
         mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, from, 0, ClickType.PICKUP, mc.field_71439_g);
         mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, 9, 0, ClickType.PICKUP, mc.field_71439_g);
         mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, from, 0, ClickType.PICKUP, mc.field_71439_g);
         mc.field_71442_b.func_78765_e();
      }
   }
}
