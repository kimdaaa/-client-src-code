package client.modules.player;

import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.BlockUtil;
import client.util.InventoryUtil;
import client.util.PlayerUtil;
import client.util.Timer;
import java.lang.reflect.Field;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAnvil;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.block.BlockObsidian;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class Burrow extends Module {
   private static Burrow INSTANCE = new Burrow();
   private final Setting force = this.register(new Setting("Offset", 1.5D, -5.0D, 10.0D));
   private final Setting instant = this.register(new Setting("Instant", true));
   private final Setting rotate = this.register(new Setting("Rotate", false));
   private final Setting anvil = this.register(new Setting("Anvil", false));
   int swapBlock = -1;
   BlockPos oldPos;
   Block blockW;
   boolean flag;

   public Burrow() {
      super("Burrow", "Tps you inside a block", Module.Category.PLAYER);
      this.blockW = ((Boolean)this.anvil.getCurrentState()).booleanValue() ? Blocks.field_150467_bQ : Blocks.field_150343_Z;
      this.setInstance();
   }

   public static Burrow getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new Burrow();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public void onEnable() {
      if (nullCheck()) {
         this.disable();
      } else {
         this.flag = false;
         mc.field_71439_g.field_70159_w = 0.0D;
         mc.field_71439_g.field_70179_y = 0.0D;
         this.oldPos = PlayerUtil.getPlayerPos();
         if (((Boolean)this.anvil.getCurrentState()).booleanValue()) {
            if (InventoryUtil.findHotbarBlock(BlockAnvil.class) > 1) {
               this.swapBlock = InventoryUtil.findHotbarBlock(BlockAnvil.class);
            } else {
               this.disable();
            }
         } else {
            if (InventoryUtil.findHotbarBlock(BlockEnderChest.class) > 1) {
               this.swapBlock = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
            } else if (InventoryUtil.findHotbarBlock(BlockObsidian.class) > 1) {
               this.swapBlock = InventoryUtil.findHotbarBlock(BlockObsidian.class);
            } else {
               this.disable();
            }

            if (this.swapBlock == -1) {
               this.disable();
               return;
            }

            if (((Boolean)this.instant.getCurrentState()).booleanValue()) {
               this.setTimer(50.0F);
            }
         }

      }
   }

   public void onUpdate() {
      if (!nullCheck()) {
         mc.field_71439_g.field_71174_a.func_147297_a(new Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.41999998688698D, mc.field_71439_g.field_70161_v, true));
         mc.field_71439_g.field_71174_a.func_147297_a(new Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.7531999805211997D, mc.field_71439_g.field_70161_v, true));
         mc.field_71439_g.field_71174_a.func_147297_a(new Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.00133597911214D, mc.field_71439_g.field_70161_v, true));
         mc.field_71439_g.field_71174_a.func_147297_a(new Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.16610926093821D, mc.field_71439_g.field_70161_v, true));
         int old = mc.field_71439_g.field_71071_by.field_70461_c;
         this.switchToSlot(this.swapBlock);
         BlockUtil.placeBlock(this.oldPos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getCurrentState()).booleanValue(), true, false);
         this.switchToSlot(old);
         mc.field_71439_g.field_71174_a.func_147297_a(new Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + ((Double)this.force.getCurrentState()).doubleValue(), mc.field_71439_g.field_70161_v, false));
         this.disable();
      }
   }

   public void onDisable() {
      if (((Boolean)this.instant.getCurrentState()).booleanValue() && !nullCheck()) {
         this.setTimer(1.0F);
      }

   }

   private void switchToSlot(int slot) {
      mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(slot));
      mc.field_71439_g.field_71071_by.field_70461_c = slot;
      mc.field_71442_b.func_78765_e();
   }

   private void setTimer(float value) {
      try {
         Field timer = Minecraft.class.getDeclaredField(Timer.timer);
         timer.setAccessible(true);
         Field tickLength = net.minecraft.util.Timer.class.getDeclaredField(Timer.tickLength);
         tickLength.setAccessible(true);
         tickLength.setFloat(timer.get(mc), 50.0F / value);
      } catch (Exception var4) {
         var4.printStackTrace();
      }

   }

   public String getDisplayInfo() {
      return "PACKET";
   }

   public void setBlock(Block b) {
      this.blockW = b;
   }

   public Block getBlock() {
      return this.blockW;
   }
}
