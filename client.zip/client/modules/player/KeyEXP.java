package client.modules.player;

import client.Client;
import client.gui.impl.setting.Bind;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.modules.combat.AutoArmor;
import client.util.PlayerUtil;
import java.util.Iterator;
import java.util.function.Predicate;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraft.util.EnumHand;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class KeyEXP extends Module {
   private int armorCheck = 0;
   private int delay_count;
   int prvSlot;
   public Setting bind = this.register(new Setting("EXPBind:", new Bind(-1)));
   public Setting feet = this.register(new Setting("Feet", false));
   public Setting takeOff = this.register(new Setting("ArmorTakeOff", false));
   public Setting threshold = this.register(new Setting("Threshold", Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(100), (v) -> {
      return ((Boolean)this.takeOff.getCurrentState()).booleanValue();
   }));
   public Setting enemyRange = this.register(new Setting("EnemyRange", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(20), (v) -> {
      return ((Boolean)this.takeOff.getCurrentState()).booleanValue();
   }));

   public KeyEXP() {
      super("KeyEXP", "", Module.Category.PLAYER);
   }

   public void onUpdate() {
      if (((Bind)this.bind.getCurrentState()).getKey() > -1) {
         if (Keyboard.isKeyDown(((Bind)this.bind.getCurrentState()).getKey()) && mc.field_71462_r == null) {
            this.useXp();
            if (AutoArmor.getInstance().isEnabled()) {
               this.armorCheck = 1;
               return;
            }

            return;
         }

         if (this.armorCheck == 2) {
            AutoArmor.getInstance().enable();
            this.armorCheck = 0;
         }
      } else if (((Bind)this.bind.getCurrentState()).getKey() < -1 && Mouse.isButtonDown(PlayerUtil.convertToMouse(((Bind)this.bind.getCurrentState()).getKey())) && mc.field_71462_r == null) {
         this.useXp();
      }

   }

   public void onEnable() {
      this.delay_count = 0;
   }

   private ItemStack getArmor(int first) {
      return (ItemStack)mc.field_71439_g.field_71069_bz.func_75138_a().get(first);
   }

   private void takeArmorOff() {
      for(int slot = 5; slot <= 8; ++slot) {
         ItemStack item = this.getArmor(slot);
         double max_dam = (double)item.func_77958_k();
         double dam_left = (double)(item.func_77958_k() - item.func_77952_i());
         double percent = dam_left / max_dam * 100.0D;
         if (percent >= (double)((Integer)this.threshold.getCurrentState()).intValue() && !item.equals(Items.field_190931_a)) {
            if (!this.notInInv(Items.field_190931_a).booleanValue()) {
               return;
            }

            if (this.delay_count < 1) {
               ++this.delay_count;
               return;
            }

            this.delay_count = 0;
            mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.QUICK_MOVE, mc.field_71439_g);
         }
      }

   }

   private int HotbarEXP() {
      int slot = 0;

      for(int i = 0; i < 9; ++i) {
         if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == Items.field_151062_by) {
            slot = i;
            break;
         }
      }

      return slot;
   }

   public static EntityPlayer getClosestEnemy() {
      EntityPlayer closestPlayer = null;
      Iterator var1 = mc.field_71441_e.field_73010_i.iterator();

      while(var1.hasNext()) {
         EntityPlayer player = (EntityPlayer)var1.next();
         if (player != mc.field_71439_g && !Client.friendManager.isFriend(player)) {
            if (closestPlayer == null) {
               closestPlayer = player;
            } else if (mc.field_71439_g.func_70068_e(player) < mc.field_71439_g.func_70068_e(closestPlayer)) {
               closestPlayer = player;
            }
         }
      }

      return closestPlayer;
   }

   private void useXp() {
      this.prvSlot = mc.field_71439_g.field_71071_by.field_70461_c;
      if (this.armorCheck == 1) {
         AutoArmor.getInstance().disable();
         this.armorCheck = 2;
      }

      if (((Boolean)this.feet.getCurrentState()).booleanValue()) {
         mc.field_71439_g.field_71174_a.func_147297_a(new Rotation(mc.field_71439_g.field_70177_z, 90.0F, true));
      }

      mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(this.HotbarEXP()));
      mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
      mc.field_71439_g.field_71071_by.field_70461_c = this.prvSlot;
      mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(this.prvSlot));
      if (getClosestEnemy() == null) {
         this.takeArmorOff();
      }

      if (getClosestEnemy() != null && ((Boolean)this.takeOff.getCurrentState()).booleanValue() && (int)getClosestEnemy().func_70032_d(mc.field_71439_g) > ((Integer)this.enemyRange.getCurrentState()).intValue()) {
         this.takeArmorOff();
      }

   }

   public String getDisplayInfo() {
      return ((Bind)this.bind.getCurrentState()).getKey() > -1 && Keyboard.isKeyDown(((Bind)this.bind.getCurrentState()).getKey()) && mc.field_71462_r == null ? "Throwing" : null;
   }

   public Boolean notInInv(Item itemOfChoice) {
      int n = 0;
      if (itemOfChoice == mc.field_71439_g.func_184592_cb().func_77973_b()) {
         return true;
      } else {
         for(int i = 35; i >= 0; --i) {
            Item item = mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b();
            if (item == itemOfChoice) {
               return true;
            }

            if (item != itemOfChoice) {
               ++n;
            }
         }

         if (n >= 35) {
            return false;
         } else {
            return true;
         }
      }
   }
}
