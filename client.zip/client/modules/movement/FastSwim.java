package client.modules.movement;

import client.modules.Module;
import client.util.Timer;

public class FastSwim extends Module {
   Timer timer = new Timer();

   public FastSwim() {
      super("FastSwim", "", Module.Category.MOVEMENT);
   }

   public void onUpdate() {
      if (!fullNullCheck()) {
         this.timer.setCurrentMS();
         if (mc.field_71439_g.func_70090_H()) {
            if (!mc.field_71439_g.func_70093_af()) {
               mc.field_71439_g.field_70181_x *= 0.01D;
            }

            if (mc.field_71474_y.field_74314_A.func_151470_d()) {
               mc.field_71439_g.field_70181_x *= 1.8D;
            }

            mc.field_71439_g.field_70159_w *= 1.18D;
            mc.field_71439_g.field_70179_y *= 1.18D;
         } else {
            this.timer.setLastMS();
         }

      }
   }
}
