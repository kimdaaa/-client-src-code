package client.modules.movement;

import client.events.PacketEvent;
import client.events.PushEvent;
import client.events.UpdateWalkingPlayerEvent;
import client.gui.impl.setting.Bind;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.EntityUtil;
import client.util.Timer;
import io.netty.util.internal.ConcurrentSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import net.minecraft.client.gui.GuiDownloadTerrain;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Phase extends Module {
   public Setting mode;
   public Setting speedH;
   public Setting speedV;
   public Setting motionFactor;
   public Setting timertime;
   public Setting loops;
   public Setting extraMotion;
   public Setting motionCount;
   public Setting bounds;
   public Setting instant;
   public Setting bypass;
   public Setting rotate;
   public Setting antiKick;
   public Setting increaseTicks;
   public Setting teleportBackBypass;
   public Setting constrict;
   public Setting limit;
   public Setting jitter;
   public Setting limitJitter;
   public Setting directions;
   public Setting bind;
   public Setting rotationType;
   public Setting rotateMode;
   public Setting rotationSpoofer;
   public Setting extraPacket;
   public Setting extraPacketPackets;
   private final Set packets;
   private final double[] positionSpoofer;
   private final double[] twoblockpositionSpoofer;
   private final double[] predictpositionSpoofer;
   final double[] positionSpooferOffset;
   private final double[] fourBlockpositionSpoofer;
   private final double[] selectedSpoofedPositions;
   private final Map teleportmap;
   private final Timer timer;
   private int flightCounter;
   private int teleportID;
   private static Phase instance;

   public Phase() {
      super("Phase", "Phases you through blocks", Module.Category.MOVEMENT);
      this.mode = this.register(new Setting("Mode", Phase.Mode.SEQUENTIAL));
      this.speedH = this.register(new Setting("HorizontalVelocity", 0.2D, 0.0D, 1.0D));
      this.speedV = this.register(new Setting("VerticalVelocity", 1.0D, 0.0D, 5.0D));
      this.motionFactor = this.register(new Setting("MotionFactor", Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(5)));
      this.timertime = this.register(new Setting("Timer", 200.0D, 0.0D, 1000.0D));
      this.loops = this.register(new Setting("Loops", 0.5D, 0.0D, 1.0D));
      this.extraMotion = this.register(new Setting("ExtraMotion", false));
      this.motionCount = this.register(new Setting("ExtraMotionCountTicks", Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(10), (v) -> {
         return ((Boolean)this.extraMotion.getCurrentState()).booleanValue();
      }));
      this.bounds = this.register(new Setting("Bounds", true));
      this.instant = this.register(new Setting("Instant", true));
      this.bypass = this.register(new Setting("Bypass", false));
      this.rotate = this.register(new Setting("Rotate", false));
      this.antiKick = this.register(new Setting("AntiKick", true));
      this.increaseTicks = this.register(new Setting("IncreaseTicks", Integer.valueOf(10), Integer.valueOf(0), Integer.valueOf(15)));
      this.teleportBackBypass = this.register(new Setting("TeleportBackBypass", 0.5D, 0.0D, 3.0D));
      this.constrict = this.register(new Setting("Constrict", true));
      this.limit = this.register(new Setting("Limit", true));
      this.jitter = this.register(new Setting("Jitter", true));
      this.limitJitter = this.register(new Setting("JitterLimit", 1.5D, 0.0D, 20.0D, (v) -> {
         return ((Boolean)this.jitter.getCurrentState()).booleanValue();
      }));
      this.directions = this.register(new Setting("Directions", Phase.Directions.PRESERVE));
      this.bind = this.register(new Setting("LoopsBind:", new Bind(-1)));
      this.rotationType = this.register(new Setting("RotationType", Phase.Type.PACKET));
      this.rotateMode = this.register(new Setting("RotateMode", Phase.RotateMode.FULL));
      this.rotationSpoofer = this.register(new Setting("RotationSpoofer", false, (v) -> {
         return ((Boolean)this.rotate.getCurrentState()).booleanValue();
      }));
      this.extraPacket = this.register(new Setting("ExtraPacket", false));
      this.extraPacketPackets = this.register(new Setting("Packets", Integer.valueOf(5), Integer.valueOf(0), Integer.valueOf(20)));
      this.packets = new ConcurrentSet();
      this.positionSpoofer = new double[]{0.42D, 0.75D};
      this.twoblockpositionSpoofer = new double[]{0.4D, 0.75D, 0.5D, 0.41D, 0.83D, 1.16D, 1.41D, 1.57D, 1.58D, 1.42D};
      this.predictpositionSpoofer = new double[]{0.42D, 0.78D, 0.63D, 0.51D, 0.9D, 1.21D, 1.45D, 1.43D};
      this.positionSpooferOffset = new double[]{0.425D, 0.821D, 0.699D, 0.599D, 1.022D, 1.372D, 1.652D, 1.869D, 2.019D, 1.907D};
      this.fourBlockpositionSpoofer = new double[]{0.42D, 0.78D, 0.63D, 0.51D, 0.9D, 1.21D, 1.45D, 1.43D, 1.78D, 1.63D, 1.51D, 1.9D, 2.21D, 2.45D, 2.43D, 2.78D, 2.63D, 2.51D, 2.9D, 3.21D, 3.45D, 3.43D};
      this.selectedSpoofedPositions = new double[0];
      this.teleportmap = new ConcurrentHashMap();
      this.flightCounter = 0;
      this.teleportID = 0;
      this.timer = new Timer();
      instance = this;
   }

   public static Phase getInstance() {
      if (instance == null) {
         instance = new Phase();
      }

      return instance;
   }

   @SubscribeEvent
   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
      if (event.getStage() != 1) {
         mc.field_71439_g.func_70016_h(0.0D, 0.0D, 0.0D);
         boolean checkCollisionBoxes = this.checkHitBoxes();
         double speed = mc.field_71439_g.field_71158_b.field_78901_c && (checkCollisionBoxes || !EntityUtil.isMoving()) ? (!checkCollisionBoxes ? (this.resetCounter(10) ? -0.032D : 0.062D) : 0.062D) : (mc.field_71439_g.field_71158_b.field_78899_d ? -0.062D : (!checkCollisionBoxes ? (this.resetCounter(4) ? -0.04D : 0.0D) : 0.0D));
         if (checkCollisionBoxes && EntityUtil.isMoving() && speed != 0.0D) {
            double antiFactor = 2.5D;
            speed /= antiFactor;
         }

         double[] strafing = this.getMotion(checkCollisionBoxes ? 0.031D : 0.26D);
         double loops = ((Boolean)this.bypass.getCurrentState()).booleanValue() ? ((Double)this.loops.getCurrentState()).doubleValue() : 0.0D;

         for(int i = 1; (double)i < loops + 1.0D; ++i) {
            double extraFactor = 1.0D;
            mc.field_71439_g.field_70159_w = strafing[0] * (double)i * extraFactor;
            mc.field_71439_g.field_70181_x = speed * (double)i;
            mc.field_71439_g.field_70179_y = strafing[1] * (double)i * extraFactor;
            this.sendPackets(mc.field_71439_g.field_70159_w, mc.field_71439_g.field_70181_x, mc.field_71439_g.field_70179_y);
            if (((Boolean)this.rotationSpoofer.getCurrentState()).booleanValue()) {
               mc.func_71400_g();
            }
         }

      }
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send event) {
      if (event.getPacket() instanceof CPacketPlayer && !this.packets.remove(event.getPacket())) {
         event.setCanceled(true);
      }

   }

   @SubscribeEvent
   public void onPushOutOfBlocks(PushEvent event) {
      if (event.getStage() == 1) {
         event.setCanceled(true);
      }

   }

   @SubscribeEvent
   public void onPacketReceive(PacketEvent.Receive event) {
      if (event.getPacket() instanceof SPacketPlayerPosLook && !fullNullCheck()) {
         SPacketPlayerPosLook packet = (SPacketPlayerPosLook)event.getPacket();
         if (mc.field_71439_g.func_70089_S() && mc.field_71441_e.func_175668_a(new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v), false) && !(mc.field_71462_r instanceof GuiDownloadTerrain)) {
            this.teleportmap.remove(packet.func_186965_f());
         }

         this.teleportID = packet.func_186965_f();
      }

   }

   private boolean checkHitBoxes() {
      return !mc.field_71441_e.func_184144_a(mc.field_71439_g, mc.field_71439_g.func_174813_aQ().func_72321_a(-0.0D, -0.1D, -0.0D)).isEmpty();
   }

   private boolean resetCounter(int counter) {
      if (++this.flightCounter >= counter) {
         this.flightCounter = 0;
         return true;
      } else {
         return false;
      }
   }

   private double[] getMotion(double speed) {
      float moveForward = mc.field_71439_g.field_71158_b.field_192832_b;
      float moveStrafe = mc.field_71439_g.field_71158_b.field_78902_a;
      float rotationYaw = mc.field_71439_g.field_70126_B + (mc.field_71439_g.field_70177_z - mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
      if (moveForward != 0.0F) {
         if (moveStrafe > 0.0F) {
            rotationYaw += (float)(moveForward > 0.0F ? -45 : 45);
         } else if (moveStrafe < 0.0F) {
            rotationYaw += (float)(moveForward > 0.0F ? 45 : -45);
         }

         moveStrafe = 0.0F;
         if (moveForward > 0.0F) {
            moveForward = 1.0F;
         } else if (moveForward < 0.0F) {
            moveForward = -1.0F;
         }
      }

      double posX = (double)moveForward * speed * -Math.sin(Math.toRadians((double)rotationYaw)) + (double)moveStrafe * speed * Math.cos(Math.toRadians((double)rotationYaw));
      double posZ = (double)moveForward * speed * Math.cos(Math.toRadians((double)rotationYaw)) - (double)moveStrafe * speed * -Math.sin(Math.toRadians((double)rotationYaw));
      return new double[]{posX, posZ};
   }

   private void sendPackets(double x, double y, double z) {
      Vec3d vec = new Vec3d(x, y, z);
      Vec3d position = mc.field_71439_g.func_174791_d().func_178787_e(vec);
      Vec3d outOfBoundsVec = this.outOfBoundsVec(position);
      this.packetSender(new Position(position.field_72450_a, position.field_72448_b, position.field_72449_c, mc.field_71439_g.field_70122_E));
      this.packetSender(new Position(outOfBoundsVec.field_72450_a, outOfBoundsVec.field_72448_b, outOfBoundsVec.field_72449_c, mc.field_71439_g.field_70122_E));
      this.teleportPacket(position);
   }

   private void teleportPacket(Vec3d pos) {
      mc.field_71439_g.field_71174_a.func_147297_a(new CPacketConfirmTeleport(++this.teleportID));
      this.teleportmap.put(this.teleportID, new Phase.IDtime(pos, new Timer()));
   }

   private Vec3d outOfBoundsVec(Vec3d position) {
      return position.func_72441_c(0.0D, 1337.0D, 0.0D);
   }

   private void packetSender(CPacketPlayer packet) {
      this.packets.add(packet);
      mc.field_71439_g.field_71174_a.func_147297_a(packet);
   }

   public static class IDtime {
      private final Vec3d pos;
      private final Timer timer;

      public IDtime(Vec3d pos, Timer timer) {
         this.pos = pos;
         this.timer = timer;
         this.timer.reset();
      }

      public Vec3d getPos() {
         return this.pos;
      }

      public Timer getTimer() {
         return this.timer;
      }
   }

   public static enum RotateMode {
      FULL,
      FULLSTRICT,
      SEMI,
      SEMISTRICT;
   }

   public static enum Type {
      PACKET,
      BYPASS,
      VANILLA,
      STRICT;
   }

   public static enum Directions {
      PRESERVE,
      UP,
      DOWN,
      SEMI,
      FULL,
      MULTIAXIS,
      DOUBLEAXIS,
      SINGLEAXIS;
   }

   public static enum Mode {
      SEQUENTIAL,
      DYNAMIC,
      VANILLA,
      NONPARALLEL,
      SERIAL,
      CONSECUTIVE,
      INCIDENTAL,
      STRICT,
      TWOBSTRICT,
      NCP;
   }
}
