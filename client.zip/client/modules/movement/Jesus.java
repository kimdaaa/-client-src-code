package client.modules.movement;

import client.events.JesusEvent;
import client.events.PacketEvent;
import client.modules.Module;
import client.util.EntityUtil;
import net.minecraft.block.Block;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Jesus extends Module {
   public Jesus() {
      super("Jesus", "", Module.Category.MOVEMENT);
   }

   public void onLogin() {
      if (this.isEnabled()) {
         this.disable();
         this.enable();
      }

   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send event) {
      if (event.getPacket() instanceof CPacketPlayer) {
         CPacketPlayer packet = (CPacketPlayer)event.getPacket();
         if (!EntityUtil.isInLiquid() && EntityUtil.isOnLiquid(0.05000000074505806D) && EntityUtil.checkCollide() && mc.field_71439_g.field_70173_aa % 3 == 0) {
            packet.field_149477_b -= 0.05000000074505806D;
         }
      }

   }

   @SubscribeEvent
   public void onJesus(JesusEvent event) {
      if (event.getStage() == 0 && mc.field_71441_e != null && mc.field_71439_g != null && EntityUtil.checkCollide() && mc.field_71439_g.field_70181_x < 0.10000000149011612D && (double)event.getPos().func_177956_o() < mc.field_71439_g.field_70163_u - 0.05000000074505806D) {
         event.setBoundingBox(Block.field_185505_j);
         event.setCanceled(true);
      }

      if (!nullCheck()) {
         ;
      }
   }
}
