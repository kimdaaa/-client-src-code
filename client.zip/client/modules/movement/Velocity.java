package client.modules.movement;

import client.events.EntityCollisionEvent;
import client.events.PacketEvent;
import client.events.PushEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import java.util.function.Predicate;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Velocity extends Module {
   public Setting explosions = this.register(new Setting("Explosions", false));
   public Setting horizontal = this.register(new Setting("Horizontal", 0.0F, 0.0F, 100.0F, (v) -> {
      return ((Boolean)this.explosions.getCurrentState()).booleanValue();
   }));
   public Setting vertical = this.register(new Setting("Vertical", 0.0F, 0.0F, 100.0F, (v) -> {
      return ((Boolean)this.explosions.getCurrentState()).booleanValue();
   }));
   public Setting noPush = this.register(new Setting("NoPush", false));
   public Setting blocks = this.register(new Setting("Blocks", false));

   public Velocity() {
      super("Velocity", "Allows you to control your velocity", Module.Category.MOVEMENT);
   }

   public void onLogin() {
      if (this.isEnabled()) {
         this.disable();
         this.enable();
      }

   }

   @SubscribeEvent
   public void onPacketReceived(PacketEvent.Receive event) {
      if (event.getStage() == 0 && mc.field_71439_g != null) {
         if (event.getPacket() instanceof SPacketEntityVelocity) {
            SPacketEntityVelocity velocity = (SPacketEntityVelocity)event.getPacket();
            if (velocity.func_149412_c() == mc.field_71439_g.field_145783_c) {
               if (((Float)this.horizontal.getCurrentState()).floatValue() == 0.0F && ((Float)this.vertical.getCurrentState()).floatValue() == 0.0F) {
                  event.setCanceled(true);
                  return;
               }

               velocity.field_149415_b = (int)((float)velocity.field_149415_b * (((Float)this.horizontal.getCurrentState()).floatValue() / 100.0F));
               velocity.field_149416_c = (int)((float)velocity.field_149416_c * (((Float)this.vertical.getCurrentState()).floatValue() / 100.0F));
               velocity.field_149414_d = (int)((float)velocity.field_149414_d * (((Float)this.horizontal.getCurrentState()).floatValue() / 100.0F));
            }
         }

         if (((Boolean)this.explosions.getCurrentState()).booleanValue() && event.getPacket() instanceof SPacketExplosion) {
            if (((Float)this.horizontal.getCurrentState()).floatValue() == 0.0F && ((Float)this.vertical.getCurrentState()).floatValue() == 0.0F) {
               event.setCanceled(true);
               return;
            }

            SPacketExplosion velocity2;
            SPacketExplosion sPacketExplosion4 = velocity2 = (SPacketExplosion)event.getPacket();
            sPacketExplosion4.field_149152_f *= ((Float)this.horizontal.getCurrentState()).floatValue();
            velocity2.field_149153_g *= ((Float)this.vertical.getCurrentState()).floatValue();
            velocity2.field_149159_h *= ((Float)this.horizontal.getCurrentState()).floatValue();
         }
      }

   }

   @SubscribeEvent
   public void onPush(PushEvent event) {
      if (event.getStage() == 1 && ((Boolean)this.blocks.getCurrentState()).booleanValue()) {
         event.setCanceled(true);
      }

   }

   @SubscribeEvent
   public void onEntityCollision(EntityCollisionEvent event) {
      if (((Boolean)this.noPush.getCurrentState()).booleanValue()) {
         event.setCanceled(true);
      }

   }
}
