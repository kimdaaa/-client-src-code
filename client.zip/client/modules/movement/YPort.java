package client.modules.movement;

import client.Client;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.EntityUtil;
import client.util.Timer;

public class YPort extends Module {
   private final Setting speed = this.register(new Setting("Speed", 0.1D, 0.0D, 1.0D));
   public Setting futurePrefix = this.register(new Setting("FuturePrefix", "."));
   private final Timer timer = new Timer();

   public YPort() {
      super("Longjump", "Terrible rip off longjump", Module.Category.MOVEMENT);
   }

   public void onDisable() {
      this.timer.reset();
      EntityUtil.resetTimer();
   }

   public void onUpdate() {
      if (!mc.field_71439_g.func_70093_af() && !mc.field_71439_g.func_70090_H() && !mc.field_71439_g.func_180799_ab() && !mc.field_71439_g.func_70617_f_() && !Client.moduleManager.isModuleEnabled("Strafe")) {
         if (mc.field_71439_g != null && mc.field_71441_e != null) {
            this.handleYPortSpeed();
            if (Step.mc.field_71439_g.field_70123_F && Step.mc.field_71439_g.field_70122_E) {
               this.disable();
               mc.field_71439_g.func_71165_d((String)this.futurePrefix.getCurrentState() + "toggle Speed");
               Step.getInstance().enable();
            }

         } else {
            this.disable();
         }
      }
   }

   public void onToggle() {
      mc.field_71439_g.field_70181_x = -3.0D;
      mc.field_71439_g.field_70138_W = 0.6F;
   }

   private void handleYPortSpeed() {
      if (EntityUtil.isMoving(mc.field_71439_g) && (!mc.field_71439_g.func_70090_H() || !mc.field_71439_g.func_180799_ab()) && !mc.field_71439_g.field_70123_F) {
         if (mc.field_71439_g.field_70122_E) {
            mc.field_71439_g.func_70664_aZ();
            EntityUtil.setSpeed(mc.field_71439_g, EntityUtil.getBaseMoveSpeed() + ((Double)this.speed.getCurrentState()).doubleValue());
         } else {
            mc.field_71439_g.field_70181_x = -1.0D;
         }

      }
   }
}
