package client.modules.movement;

import client.Client;
import client.events.ClientEvent;
import client.events.MoveEvent;
import client.events.WalkEvent;
import client.gui.impl.setting.Bind;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.EntityUtil;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.util.MovementInput;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

public class Strafe extends Module {
   private static Strafe INSTANCE = new Strafe();
   private int delay;
   private boolean preMotion;
   private double motion;
   public boolean antiShake = false;
   public boolean changeY = false;
   public double minY = 0.0D;
   public Setting mode;
   public Setting switchBind;

   public Strafe() {
      super("Strafe", "", Module.Category.MOVEMENT);
      this.mode = this.register(new Setting("Mode", Strafe.Mode.STRAFE));
      this.switchBind = this.register(new Setting("SwitchBind", new Bind(-1)));
      this.setInstance();
   }

   public static Strafe getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new Strafe();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public void onEnable() {
      this.motion = 0.0D;
   }

   public void onTick() {
      if (this.delay < 12) {
         ++this.delay;
      }

      if (this.delay > 10 && ((Bind)this.switchBind.getCurrentState()).getKey() > -1 && Keyboard.isKeyDown(((Bind)this.switchBind.getCurrentState()).getKey())) {
         if (this.mode.getCurrentState() == Strafe.Mode.INSTANT) {
            this.mode.setValue(Strafe.Mode.STRAFE);
            mc.field_71456_v.func_146158_b().func_146234_a(new TextComponentString(Client.commandManager.getClientMessage() + ChatFormatting.BOLD + " Strafe: " + ChatFormatting.GRAY + "Mode set to: " + ChatFormatting.RED + ChatFormatting.BOLD + "Strafe"), 1);
            this.delay = 0;
         } else if (this.mode.getCurrentState() == Strafe.Mode.STRAFE) {
            this.mode.setValue(Strafe.Mode.INSTANT);
            mc.field_71456_v.func_146158_b().func_146234_a(new TextComponentString(Client.commandManager.getClientMessage() + ChatFormatting.BOLD + " Strafe: " + ChatFormatting.GRAY + "Mode set to: " + ChatFormatting.RED + ChatFormatting.BOLD + "Instant"), 1);
            this.delay = 0;
         }
      }

   }

   @SubscribeEvent
   public void onMove(WalkEvent event) {
      if (this.mode.getCurrentState() == Strafe.Mode.STRAFE) {
         if (!EntityUtil.onMovementInput()) {
            this.motion = EntityUtil.getMovementSpeed();
            event.setMotionX(0.0D);
            event.setMotionZ(0.0D);
            return;
         }

         if (mc.field_71439_g.field_70122_E) {
            this.motion *= 1.57D;
            mc.field_71439_g.field_70181_x = 0.412D;
            event.setMotionY(0.412D);
         } else {
            this.motion = this.preMotion ? (this.motion -= 0.66D * (this.motion - EntityUtil.getMovementSpeed())) : (this.motion -= this.motion / 159.0D);
         }

         this.preMotion = mc.field_71439_g.field_70122_E;
         this.motion = Math.max(this.motion, EntityUtil.getMovementSpeed());
         this.motion = Math.min(this.motion, 0.547D);
         mc.field_71439_g.field_70159_w = -(Math.sin(EntityUtil.getDirection()) * this.motion);
         event.setMotionX(mc.field_71439_g.field_70159_w);
         mc.field_71439_g.field_70179_y = Math.cos(EntityUtil.getDirection()) * this.motion;
         event.setMotionZ(mc.field_71439_g.field_70179_y);
      }

   }

   public void onUpdate() {
      if (mc.field_71439_g.func_70093_af() || mc.field_71439_g.func_70090_H() || mc.field_71439_g.func_180799_ab() || !mc.field_71439_g.field_70122_E && this.mode.getCurrentState() == Strafe.Mode.INSTANT) {
         ;
      }
   }

   public void onDisable() {
      this.changeY = false;
      this.antiShake = false;
   }

   @SubscribeEvent
   public void onSettingChange(ClientEvent event) {
      if (event.getStage() == 2) {
         mc.field_71439_g.field_70181_x = -0.1D;
      }

   }

   @SubscribeEvent
   public void onMode(MoveEvent event) {
      if (this.mode.getCurrentState() == Strafe.Mode.INSTANT && (event.getStage() == 0 && !nullCheck() && !mc.field_71439_g.func_70093_af() && !mc.field_71439_g.func_70090_H() && !mc.field_71439_g.func_180799_ab() && (mc.field_71439_g.field_71158_b.field_192832_b != 0.0F || mc.field_71439_g.field_71158_b.field_78902_a != 0.0F) || !mc.field_71439_g.field_70122_E)) {
         MovementInput movementInput = mc.field_71439_g.field_71158_b;
         float moveForward = movementInput.field_192832_b;
         float moveStrafe = movementInput.field_78902_a;
         float rotationYaw = mc.field_71439_g.field_70177_z;
         if ((double)moveForward == 0.0D && (double)moveStrafe == 0.0D) {
            event.setX(0.0D);
            event.setZ(0.0D);
         } else {
            if ((double)moveForward != 0.0D) {
               if ((double)moveStrafe > 0.0D) {
                  rotationYaw += (float)((double)moveForward > 0.0D ? -45 : 45);
               } else if ((double)moveStrafe < 0.0D) {
                  rotationYaw += (float)((double)moveForward > 0.0D ? 45 : -45);
               }

               moveStrafe = 0.0F;
               if (moveForward != 0.0F) {
                  moveForward = (double)moveForward > 0.0D ? 1.0F : -1.0F;
               }
            }

            moveStrafe = moveStrafe == 0.0F ? moveStrafe : ((double)moveStrafe > 0.0D ? 1.0F : -1.0F);
            event.setX((double)moveForward * EntityUtil.getMaxSpeed() * Math.cos(Math.toRadians((double)(rotationYaw + 90.0F))) + (double)moveStrafe * EntityUtil.getMaxSpeed() * Math.sin(Math.toRadians((double)(rotationYaw + 90.0F))));
            event.setZ((double)moveForward * EntityUtil.getMaxSpeed() * Math.sin(Math.toRadians((double)(rotationYaw + 90.0F))) - (double)moveStrafe * EntityUtil.getMaxSpeed() * Math.cos(Math.toRadians((double)(rotationYaw + 90.0F))));
         }
      }

   }

   public static enum Mode {
      STRAFE,
      INSTANT;
   }
}
