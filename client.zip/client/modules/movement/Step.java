package client.modules.movement;

import client.gui.impl.setting.Setting;
import client.modules.Module;
import java.util.function.Predicate;
import net.minecraft.block.material.Material;
import net.minecraft.network.play.client.CPacketPlayer.Position;

public class Step extends Module {
   public Setting vanilla = this.register(new Setting("Vanilla", false));
   public Setting stepHeight = this.register(new Setting("Height", Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(4), (v) -> {
      return !((Boolean)this.vanilla.getCurrentState()).booleanValue();
   }));
   private final double[] oneblockPositions = new double[]{0.42D, 0.75D};
   private final double[] twoblockPositions = new double[]{0.4D, 0.75D, 0.5D, 0.41D, 0.83D, 1.16D, 1.41D, 1.57D, 1.58D, 1.42D};
   private final double[] futurePositions = new double[]{0.42D, 0.78D, 0.63D, 0.51D, 0.9D, 1.21D, 1.45D, 1.43D};
   final double[] twoFiveOffset = new double[]{0.425D, 0.821D, 0.699D, 0.599D, 1.022D, 1.372D, 1.652D, 1.869D, 2.019D, 1.907D};
   private final double[] fourBlockPositions = new double[]{0.42D, 0.78D, 0.63D, 0.51D, 0.9D, 1.21D, 1.45D, 1.43D, 1.78D, 1.63D, 1.51D, 1.9D, 2.21D, 2.45D, 2.43D, 2.78D, 2.63D, 2.51D, 2.9D, 3.21D, 3.45D, 3.43D};
   private double[] selectedPositions = new double[0];
   private int packets;
   private static Step instance;

   public Step() {
      super("Step", "Step up yo mam", Module.Category.MOVEMENT);
      instance = this;
   }

   public static Step getInstance() {
      if (instance == null) {
         instance = new Step();
      }

      return instance;
   }

   public void onToggle() {
      mc.field_71439_g.field_70138_W = 0.6F;
   }

   public void onUpdate() {
      if (((Boolean)this.vanilla.getCurrentState()).booleanValue()) {
         mc.field_71439_g.field_70138_W = ((Integer)this.stepHeight.getCurrentState()).floatValue();
      } else {
         switch(((Integer)this.stepHeight.getCurrentState()).intValue()) {
         case 1:
            this.selectedPositions = this.oneblockPositions;
            break;
         case 2:
            this.selectedPositions = (double[])this.futurePositions;
            break;
         case 3:
            this.selectedPositions = this.twoFiveOffset;
         case 4:
            this.selectedPositions = this.fourBlockPositions;
         }

         if (mc.field_71439_g.field_70123_F && mc.field_71439_g.field_70122_E) {
            ++this.packets;
         }

         if (mc.field_71439_g.field_70122_E && !mc.field_71439_g.func_70055_a(Material.field_151586_h) && !mc.field_71439_g.func_70055_a(Material.field_151587_i) && mc.field_71439_g.field_70124_G && mc.field_71439_g.field_70143_R == 0.0F && !mc.field_71474_y.field_74314_A.field_74513_e && mc.field_71439_g.field_70123_F && !mc.field_71439_g.func_70617_f_() && (this.packets > this.selectedPositions.length - 2 || this.packets > 0)) {
            double[] var1 = this.selectedPositions;
            int var2 = var1.length;

            for(int var3 = 0; var3 < var2; ++var3) {
               double position = var1[var3];
               mc.field_71439_g.field_71174_a.func_147297_a(new Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + position, mc.field_71439_g.field_70161_v, true));
            }

            mc.field_71439_g.func_70107_b(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + this.selectedPositions[this.selectedPositions.length - 1], mc.field_71439_g.field_70161_v);
            this.packets = 0;
         }

      }
   }

   public String getDisplayInfo() {
      return ((Boolean)this.vanilla.getCurrentState()).booleanValue() ? "Vanilla" : "NCP";
   }
}
