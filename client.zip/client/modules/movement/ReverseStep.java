package client.modules.movement;

import client.gui.impl.setting.Setting;
import client.modules.Module;

public class ReverseStep extends Module {
   private final Setting speed = this.register(new Setting("Speed", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(20)));

   public ReverseStep() {
      super("ReverseStep", "Speeds up downwards motion", Module.Category.MOVEMENT);
   }

   public void onUpdate() {
      if (!mc.field_71439_g.func_180799_ab() && !mc.field_71439_g.func_70090_H() && !Phase.getInstance().isOn()) {
         if (mc.field_71439_g.field_70122_E) {
            mc.field_71439_g.field_70181_x -= (double)((Integer)this.speed.getCurrentState()).intValue();
         }

      }
   }
}
