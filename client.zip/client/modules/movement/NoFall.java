package client.modules.movement;

import client.modules.Module;
import client.util.Timer;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraft.network.play.client.CPacketPlayer.PositionRotation;

public class NoFall extends Module {
   Timer timer = new Timer();

   public NoFall() {
      super("NoFall", "", Module.Category.MOVEMENT);
   }

   public void onUpdate() {
      if (!fullNullCheck()) {
         this.timer.setCurrentMS();
         if (mc.field_71439_g.field_70143_R > 4.0F && this.timer.hasDelayRun(800L)) {
            Position outOfBoundsPosition = new Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u - 420.69D, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E);
            mc.field_71439_g.field_71174_a.func_147297_a(outOfBoundsPosition);
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketConfirmTeleport());
            mc.field_71439_g.field_71174_a.func_147297_a(new PositionRotation(mc.field_71439_g.field_70165_t + mc.field_71439_g.field_70159_w, mc.field_71439_g.field_70163_u + 0.0622D, mc.field_71439_g.field_70161_v + mc.field_71439_g.field_70179_y, mc.field_71439_g.field_70177_z, mc.field_71439_g.field_70125_A, false));
            mc.field_71439_g.field_71174_a.func_147297_a(new PositionRotation(mc.field_71439_g.field_70165_t + mc.field_71439_g.field_70159_w, mc.field_71439_g.field_70163_u - 420.69D, mc.field_71439_g.field_70161_v + mc.field_71439_g.field_70179_y, mc.field_71439_g.field_70177_z, mc.field_71439_g.field_70125_A, true));
            this.timer.setLastMS();
         }
      }
   }
}
