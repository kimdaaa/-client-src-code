package client.modules.movement;

import client.events.KeyEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreenOptionsSounds;
import net.minecraft.client.gui.GuiVideoSettings;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.MovementInput;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

public class NoSlow extends Module {
   private static NoSlow INSTANCE = new NoSlow();
   public Setting items = this.register(new Setting("Items", false));
   public Setting guiMove = this.register(new Setting("Inventory", false));
   public Setting webs = this.register(new Setting("Webs", false));
   private static final KeyBinding[] keys;

   public NoSlow() {
      super("NoSlow", "Stops packets that slow you down", Module.Category.MOVEMENT);
      this.setInstance();
   }

   public static NoSlow getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new NoSlow();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public void onLogin() {
      if (this.isEnabled()) {
         this.disable();
         this.enable();
      }

   }

   public void onUpdate() {
      if (((Boolean)this.guiMove.getCurrentState()).booleanValue()) {
         KeyBinding[] var1;
         int var2;
         int var3;
         KeyBinding bind;
         if (!(mc.field_71462_r instanceof GuiOptions) && !(mc.field_71462_r instanceof GuiVideoSettings) && !(mc.field_71462_r instanceof GuiScreenOptionsSounds) && !(mc.field_71462_r instanceof GuiContainer) && !(mc.field_71462_r instanceof GuiIngameMenu)) {
            if (mc.field_71462_r == null) {
               var1 = keys;
               var2 = var1.length;

               for(var3 = 0; var3 < var2; ++var3) {
                  bind = var1[var3];
                  if (!Keyboard.isKeyDown(bind.func_151463_i())) {
                     KeyBinding.func_74510_a(bind.func_151463_i(), false);
                  }
               }
            }
         } else {
            var1 = keys;
            var2 = var1.length;

            for(var3 = 0; var3 < var2; ++var3) {
               bind = var1[var3];
               KeyBinding.func_74510_a(bind.func_151463_i(), Keyboard.isKeyDown(bind.func_151463_i()));
            }
         }
      }

      if (((Boolean)this.webs.getCurrentState()).booleanValue() && mc.field_71439_g.field_70134_J) {
         mc.field_71439_g.field_70134_J = false;
      }

   }

   @SubscribeEvent
   public void onItemEat(InputUpdateEvent event) {
      if (((Boolean)this.items.getCurrentState()).booleanValue() && mc.field_71439_g.func_184587_cr()) {
         MovementInput var10000 = event.getMovementInput();
         var10000.field_78902_a *= 5.0F;
         var10000 = event.getMovementInput();
         var10000.field_192832_b *= 5.0F;
      }

   }

   @SubscribeEvent
   public void onKeyEvent(KeyEvent event) {
      if (((Boolean)this.guiMove.getCurrentState()).booleanValue() && event.getStage() == 0 && !(mc.field_71462_r instanceof GuiChat)) {
         event.info = event.pressed;
      }

   }

   static {
      keys = new KeyBinding[]{mc.field_71474_y.field_74351_w, mc.field_71474_y.field_74368_y, mc.field_71474_y.field_74370_x, mc.field_71474_y.field_74366_z, mc.field_71474_y.field_74314_A, mc.field_71474_y.field_151444_V};
   }
}
