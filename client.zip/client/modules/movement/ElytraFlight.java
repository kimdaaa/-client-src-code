package client.modules.movement;

import client.events.MoveEvent;
import client.events.UpdateWalkingPlayerEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.PlayerUtil;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ElytraFlight extends Module {
   public Setting speed = this.register(new Setting("Speed", 1.0D, 0.1D, 10.0D));
   public Setting speedDown = this.register(new Setting("SpeedDown", 1.0D, 0.1D, 10.0D));

   public ElytraFlight() {
      super("ElytraFlight", "Allows travel with Elytras to be more easy.", Module.Category.MOVEMENT);
   }

   @SubscribeEvent
   public void onMove(MoveEvent event) {
      if (mc.field_71439_g.func_184613_cA()) {
         if (!mc.field_71439_g.field_71158_b.field_78901_c) {
            if (mc.field_71439_g.field_71158_b.field_78899_d) {
               mc.field_71439_g.field_70181_x = -((Double)this.speedDown.getCurrentState()).doubleValue();
            } else if (event.getY() != -1.01E-4D) {
               event.setY(-1.01E-4D);
               mc.field_71439_g.field_70181_x = -1.01E-4D;
            }

            PlayerUtil.setMoveSpeed(event, ((Double)this.speed.getCurrentState()).doubleValue());
         }
      }
   }

   public void onTick() {
      if (mc.field_71439_g.func_184613_cA()) {
         ;
      }
   }

   @SubscribeEvent
   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
      if (mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() == Items.field_185160_cR) {
         ;
      }
   }

   public void onLogin() {
      if (this.isEnabled()) {
         this.disable();
         this.enable();
      }

   }

   public void onDisable() {
      if (!fullNullCheck() && !mc.field_71439_g.field_71075_bZ.field_75098_d) {
         mc.field_71439_g.field_71075_bZ.field_75100_b = false;
      }
   }
}
