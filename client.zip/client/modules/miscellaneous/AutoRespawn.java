package client.modules.miscellaneous;

import client.modules.Module;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.client.gui.GuiScreen;

public class AutoRespawn extends Module {
   public AutoRespawn() {
      super("AutoRespawn", "Respawns you if you die.", Module.Category.MISC);
   }

   public void onUpdate() {
      if (mc.field_71462_r instanceof GuiGameOver) {
         mc.field_71439_g.func_71004_bE();
         mc.func_147108_a((GuiScreen)null);
      }

   }
}
