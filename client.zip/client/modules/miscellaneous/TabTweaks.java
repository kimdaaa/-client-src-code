package client.modules.miscellaneous;

import client.gui.impl.setting.Setting;
import client.modules.Module;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.scoreboard.ScorePlayerTeam;

public class TabTweaks extends Module {
   private static TabTweaks INSTANCE = new TabTweaks();
   public Setting pingDisplay = this.register(new Setting("Ping", true));
   public Setting coloredPing = this.register(new Setting("Colored", true));
   public Setting size = this.register(new Setting("Size", Integer.valueOf(250), Integer.valueOf(1), Integer.valueOf(1000)));

   public TabTweaks() {
      super("TabTweaks", "Lets you do stuff with tab", Module.Category.MISC);
      this.setInstance();
   }

   public static String getPlayerName(NetworkPlayerInfo networkPlayerInfoIn) {
      String name = networkPlayerInfoIn.func_178854_k() != null ? networkPlayerInfoIn.func_178854_k().func_150254_d() : ScorePlayerTeam.func_96667_a(networkPlayerInfoIn.func_178850_i(), networkPlayerInfoIn.func_178845_a().getName());
      if (((Boolean)getINSTANCE().pingDisplay.getCurrentState()).booleanValue()) {
         if (!((Boolean)getINSTANCE().coloredPing.getCurrentState()).booleanValue()) {
            return name + ChatFormatting.GRAY + " " + (((Boolean)getINSTANCE().pingDisplay.getCurrentState()).booleanValue() ? networkPlayerInfoIn.func_178853_c() : "");
         }

         if (networkPlayerInfoIn.func_178853_c() <= 50) {
            return name + ChatFormatting.GREEN + " " + (((Boolean)getINSTANCE().pingDisplay.getCurrentState()).booleanValue() ? networkPlayerInfoIn.func_178853_c() : "");
         }

         if (networkPlayerInfoIn.func_178853_c() <= 100) {
            return name + ChatFormatting.GOLD + " " + (((Boolean)getINSTANCE().pingDisplay.getCurrentState()).booleanValue() ? networkPlayerInfoIn.func_178853_c() : "");
         }

         if (networkPlayerInfoIn.func_178853_c() <= 150) {
            return name + ChatFormatting.RED + " " + (((Boolean)getINSTANCE().pingDisplay.getCurrentState()).booleanValue() ? networkPlayerInfoIn.func_178853_c() : "");
         }

         if (networkPlayerInfoIn.func_178853_c() <= 1000) {
            return name + ChatFormatting.DARK_RED + " " + (((Boolean)getINSTANCE().pingDisplay.getCurrentState()).booleanValue() ? networkPlayerInfoIn.func_178853_c() : "");
         }
      }

      return name;
   }

   public static TabTweaks getINSTANCE() {
      if (INSTANCE == null) {
         INSTANCE = new TabTweaks();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }
}
