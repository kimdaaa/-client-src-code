package client.modules.miscellaneous;

import client.events.PacketEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.MathUtil;
import client.util.Timer;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketKeepAlive;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class PingSpoofer extends Module {
   private final Setting delay = this.register(new Setting("DelayMS", Integer.valueOf(20), Integer.valueOf(0), Integer.valueOf(1000)));
   private final Queue packets = new ConcurrentLinkedQueue();
   private final Timer timer = new Timer();
   private boolean receive = true;

   public PingSpoofer() {
      super("PingSpoofer", "Makes it look like you have higher ping than you really do.", Module.Category.MISC);
   }

   public void onUpdate() {
      this.clearQueue();
   }

   public void onDisable() {
      this.clearQueue();
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send event) {
      if (this.receive && mc.field_71439_g != null && !mc.func_71356_B() && mc.field_71439_g.func_70089_S() && event.getStage() == 0 && event.getPacket() instanceof CPacketKeepAlive) {
         this.packets.add(event.getPacket());
         event.setCanceled(true);
      }

   }

   public void clearQueue() {
      if (mc.field_71439_g != null && !mc.func_71356_B() && mc.field_71439_g.func_70089_S() && this.timer.passedMs((long)((Integer)this.delay.getCurrentState()).intValue())) {
         double limit = MathUtil.getIncremental(Math.random() * 10.0D, 1.0D);
         this.receive = false;

         for(int i = 0; (double)i < limit; ++i) {
            Packet packet = (Packet)this.packets.poll();
            if (packet != null) {
               mc.field_71439_g.field_71174_a.func_147297_a(packet);
            }
         }

         this.timer.reset();
         this.receive = true;
      }

   }
}
