package client.modules.miscellaneous;

import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.FileUtil;
import client.util.Timer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.network.play.client.CPacketChatMessage;

public class Spammer extends Module {
   public Setting delay = this.register(new Setting("Delay", 6.0D, 0.1D, 20.0D));
   public Setting greentext = this.register(new Setting("Green", false));
   public Setting random = this.register(new Setting("Random", false));
   private final Timer timer = new Timer();
   private static final List spamMessages = new ArrayList();
   private static final Random rnd = new Random();

   public Spammer() {
      super("Spammer", "Spams stuff.", Module.Category.MISC);
   }

   public void onLoad() {
      this.readSpamFile();
   }

   public void onEnable() {
      if (fullNullCheck()) {
         this.disable();
      } else {
         this.readSpamFile();
      }
   }

   public void onLogin() {
      if (this.isEnabled()) {
         this.disable();
      }

      this.readSpamFile();
   }

   public void onLogout() {
      if (this.isEnabled()) {
         this.disable();
      }

   }

   public void onDisable() {
      spamMessages.clear();
      this.timer.reset();
   }

   public void onUpdate() {
      if (fullNullCheck()) {
         this.disable();
      } else if (this.timer.passedS(((Double)this.delay.getCurrentState()).doubleValue())) {
         if (spamMessages.size() > 0) {
            String messageOut;
            if (((Boolean)this.random.getCurrentState()).booleanValue()) {
               int index = rnd.nextInt(spamMessages.size());
               messageOut = (String)spamMessages.get(index);
               spamMessages.remove(index);
            } else {
               messageOut = (String)spamMessages.get(0);
               spamMessages.remove(0);
            }

            spamMessages.add(messageOut);
            if (((Boolean)this.greentext.getCurrentState()).booleanValue()) {
               messageOut = "> " + messageOut;
            }

            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketChatMessage(messageOut.replaceAll("Â§", "")));
         }

         this.timer.reset();
      }
   }

   private void readSpamFile() {
      List fileInput = FileUtil.readTextFileAllLines("client/util/Spammer.txt");
      Iterator i = fileInput.iterator();
      spamMessages.clear();

      while(i.hasNext()) {
         String s = (String)i.next();
         if (!s.replaceAll("\\s", "").isEmpty()) {
            spamMessages.add(s);
         }
      }

      if (spamMessages.size() == 0) {
         spamMessages.add("f");
      }

   }
}
