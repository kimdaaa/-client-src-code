package client.modules.miscellaneous;

import client.gui.impl.setting.Setting;
import client.modules.Module;
import com.mojang.authlib.GameProfile;
import java.util.UUID;
import java.util.function.Predicate;
import net.minecraft.client.entity.EntityOtherPlayerMP;

public class FakePlayer extends Module {
   private static FakePlayer INSTANCE = new FakePlayer();
   public Setting copyInv = this.register(new Setting("Copy Inventory", true));
   public Setting moving = this.register(new Setting("Moving", false));
   public Setting motion = this.register(new Setting("Motion", Integer.valueOf(2), Integer.valueOf(-5), Integer.valueOf(5), (v) -> {
      return ((Boolean)this.moving.getCurrentState()).booleanValue();
   }));
   private final int entityId = -420;

   public FakePlayer() {
      super("FakePlayer", "Spawns a FakePlayer for testing.", Module.Category.MISC);
      this.setInstance();
   }

   public static FakePlayer getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new FakePlayer();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public void onDisable() {
      if (!fullNullCheck()) {
         mc.field_71441_e.func_73028_b(-420);
      }
   }

   public void onUpdate() {
      if (((Boolean)this.moving.getCurrentState()).booleanValue()) {
         if (!fullNullCheck()) {
            GameProfile profile = new GameProfile(UUID.fromString("12cbdfad-33b7-4c07-aeac-01766e609482"), "FakePlayer");
            EntityOtherPlayerMP player = new EntityOtherPlayerMP(mc.field_71441_e, profile);
            player.func_70012_b(mc.field_71439_g.field_70165_t + player.field_70159_w + (double)((Integer)this.motion.getCurrentState()).intValue(), mc.field_71439_g.field_70163_u + player.field_70181_x, mc.field_71439_g.field_70161_v + player.field_70179_y + (double)((Integer)this.motion.getCurrentState()).intValue(), 90.0F, 90.0F);
            player.field_70759_as = mc.field_71439_g.field_70759_as;
            if (((Boolean)this.copyInv.getCurrentState()).booleanValue()) {
               player.field_71071_by.func_70455_b(mc.field_71439_g.field_71071_by);
            }

            mc.field_71441_e.func_73027_a(-420, player);
         }
      }
   }

   public void onEnable() {
      if (!((Boolean)this.moving.getCurrentState()).booleanValue()) {
         if (!fullNullCheck()) {
            GameProfile profile = new GameProfile(UUID.fromString("12cbdfad-33b7-4c07-aeac-01766e609482"), "FakePlayer");
            EntityOtherPlayerMP player = new EntityOtherPlayerMP(mc.field_71441_e, profile);
            player.func_82149_j(mc.field_71439_g);
            player.field_70759_as = mc.field_71439_g.field_70759_as;
            if (((Boolean)this.copyInv.getCurrentState()).booleanValue()) {
               player.field_71071_by.func_70455_b(mc.field_71439_g.field_71071_by);
            }

            mc.field_71441_e.func_73027_a(-420, player);
         }
      }
   }
}
