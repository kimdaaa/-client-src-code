package client.modules.miscellaneous;

import client.events.ChorusEvent;
import client.events.Render3DEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.ColorUtil;
import client.util.RenderUtil;
import client.util.Timer;
import java.awt.Color;
import java.util.function.Predicate;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ChorusPredict extends Module {
   private final Setting time = this.register(new Setting("Duration", Integer.valueOf(500), Integer.valueOf(50), Integer.valueOf(3000)));
   private final Setting box = this.register(new Setting("Box", true));
   private final Setting outline = this.register(new Setting("Outline", true));
   private final Setting boxR = this.register(new Setting("BoxR", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.box.getCurrentState()).booleanValue();
   }));
   private final Setting boxG = this.register(new Setting("BoxG", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.box.getCurrentState()).booleanValue();
   }));
   private final Setting boxB = this.register(new Setting("BoxB", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.box.getCurrentState()).booleanValue();
   }));
   private final Setting boxA = this.register(new Setting("BoxA", Integer.valueOf(120), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.box.getCurrentState()).booleanValue();
   }));
   private final Setting lineWidth = this.register(new Setting("LineWidth", 1.0F, 0.1F, 5.0F, (v) -> {
      return ((Boolean)this.outline.getCurrentState()).booleanValue();
   }));
   private final Setting outlineR = this.register(new Setting("OutlineR", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.outline.getCurrentState()).booleanValue();
   }));
   private final Setting outlineG = this.register(new Setting("OutlineG", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.outline.getCurrentState()).booleanValue();
   }));
   private final Setting outlineB = this.register(new Setting("OutlineB", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.outline.getCurrentState()).booleanValue();
   }));
   private final Setting outlineA = this.register(new Setting("OutlineA", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.outline.getCurrentState()).booleanValue();
   }));
   private final Timer timer = new Timer();
   private double x;
   private double y;
   private double z;

   public ChorusPredict() {
      super("ChorusPredict", "", Module.Category.MISC);
   }

   @SubscribeEvent
   public void onChorus(ChorusEvent event) {
      this.x = event.getChorusX();
      this.y = event.getChorusY();
      this.z = event.getChorusZ();
      this.timer.reset();
   }

   public void onRender3D(Render3DEvent render3DEvent) {
      if (!this.timer.passedMs((long)((Integer)this.time.getCurrentState()).intValue())) {
         AxisAlignedBB pos = RenderUtil.interpolateAxis(new AxisAlignedBB(this.x - 0.3D, this.y, this.z - 0.3D, this.x + 0.3D, this.y + 1.8D, this.z + 0.3D));
         if (((Boolean)this.outline.getCurrentState()).booleanValue()) {
            RenderUtil.drawBlockOutline(pos, new Color(((Integer)this.outlineR.getCurrentState()).intValue(), ((Integer)this.outlineG.getCurrentState()).intValue(), ((Integer)this.outlineB.getCurrentState()).intValue(), ((Integer)this.outlineA.getCurrentState()).intValue()), ((Float)this.lineWidth.getCurrentState()).floatValue());
         }

         if (((Boolean)this.box.getCurrentState()).booleanValue()) {
            RenderUtil.drawFilledBox(pos, ColorUtil.toRGBA(((Integer)this.boxR.getCurrentState()).intValue(), ((Integer)this.boxG.getCurrentState()).intValue(), ((Integer)this.boxB.getCurrentState()).intValue(), ((Integer)this.boxA.getCurrentState()).intValue()));
         }

      }
   }
}
