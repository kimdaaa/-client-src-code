package client.modules.miscellaneous;

import client.modules.Module;
import client.util.InventoryUtil;
import net.minecraft.init.Items;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.util.EnumHand;
import org.lwjgl.input.Mouse;

public class MiddleClickPearl extends Module {
   private boolean clicked = false;

   public MiddleClickPearl() {
      super("MiddleClickPearl", "Throws a pearl when middle clicked", Module.Category.MISC);
   }

   public void onEnable() {
   }

   public void onTick() {
      if (Mouse.isButtonDown(2)) {
         if (!this.clicked) {
            this.throwPearl();
         }

         this.clicked = true;
      } else {
         this.clicked = false;
      }

   }

   private void throwPearl() {
      int pearlSlot = InventoryUtil.findHotbarBlock(ItemEnderPearl.class);
      boolean offhand = mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151079_bi;
      if (pearlSlot != -1 || offhand) {
         int oldslot = mc.field_71439_g.field_71071_by.field_70461_c;
         if (!offhand) {
            InventoryUtil.switchToHotbarSlot(pearlSlot, false);
         }

         mc.field_71442_b.func_187101_a(mc.field_71439_g, mc.field_71441_e, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
         if (!offhand) {
            InventoryUtil.switchToHotbarSlot(oldslot, false);
         }
      }

   }
}
