package client.modules.miscellaneous;

import client.modules.Module;
import client.modules.client.Notify;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.HashMap;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.text.TextComponentString;

public class TotemPopCounter extends Module {
   private static TotemPopCounter INSTANCE = new TotemPopCounter();
   public static HashMap TotemPopContainer = new HashMap();

   public TotemPopCounter() {
      super("TotemPopCounter", "Counts enemy pops", Module.Category.MISC);
      this.setInstance();
   }

   public static TotemPopCounter getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new TotemPopCounter();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public void onDeath(EntityPlayer player) {
      if (TotemPopContainer.containsKey(player.func_70005_c_())) {
         int l_Count = ((Integer)TotemPopContainer.get(player.func_70005_c_())).intValue();
         TotemPopContainer.remove(player.func_70005_c_());
         int id;
         char[] var4;
         int var5;
         int var6;
         char character;
         if (l_Count == 1) {
            id = 0;
            var4 = player.func_70005_c_().toCharArray();
            var5 = var4.length;

            for(var6 = 0; var6 < var5; ++var6) {
               character = var4[var6];
               id += character;
               id *= 10;
            }

            mc.field_71456_v.func_146158_b().func_146234_a(new TextComponentString(Notify.getInstance().getCommandMessage() + " " + ChatFormatting.WHITE + ChatFormatting.BOLD + player.func_70005_c_() + ChatFormatting.RESET + ChatFormatting.RED + " died after popping " + ChatFormatting.WHITE + ChatFormatting.BOLD + l_Count + ChatFormatting.RESET + ChatFormatting.RED + " totem."), id);
         } else {
            id = 0;
            var4 = player.func_70005_c_().toCharArray();
            var5 = var4.length;

            for(var6 = 0; var6 < var5; ++var6) {
               character = var4[var6];
               id += character;
               id *= 10;
            }

            mc.field_71456_v.func_146158_b().func_146234_a(new TextComponentString(Notify.getInstance().getCommandMessage() + " " + ChatFormatting.WHITE + ChatFormatting.BOLD + player.func_70005_c_() + ChatFormatting.RESET + ChatFormatting.RED + " died after popping " + ChatFormatting.WHITE + ChatFormatting.BOLD + l_Count + ChatFormatting.RESET + ChatFormatting.RED + " totems."), id);
         }
      }

   }

   public void onTotemPop(EntityPlayer player) {
      if (!fullNullCheck()) {
         if (!mc.field_71439_g.equals(player)) {
            int l_Count = 1;
            if (TotemPopContainer.containsKey(player.func_70005_c_())) {
               l_Count = ((Integer)TotemPopContainer.get(player.func_70005_c_())).intValue();
               HashMap var10000 = TotemPopContainer;
               String var10001 = player.func_70005_c_();
               ++l_Count;
               var10000.put(var10001, l_Count);
            } else {
               TotemPopContainer.put(player.func_70005_c_(), l_Count);
            }

            int id;
            char[] var4;
            int var5;
            int var6;
            char character;
            if (l_Count == 1) {
               id = 0;
               var4 = player.func_70005_c_().toCharArray();
               var5 = var4.length;

               for(var6 = 0; var6 < var5; ++var6) {
                  character = var4[var6];
                  id += character;
                  id *= 10;
               }

               mc.field_71456_v.func_146158_b().func_146234_a(new TextComponentString(Notify.getInstance().getCommandMessage() + " " + ChatFormatting.WHITE + ChatFormatting.BOLD + player.func_70005_c_() + ChatFormatting.RESET + ChatFormatting.RED + " has popped " + ChatFormatting.WHITE + ChatFormatting.BOLD + l_Count + ChatFormatting.RESET + ChatFormatting.RED + " totem."), id);
            } else {
               id = 0;
               var4 = player.func_70005_c_().toCharArray();
               var5 = var4.length;

               for(var6 = 0; var6 < var5; ++var6) {
                  character = var4[var6];
                  id += character;
                  id *= 10;
               }

               mc.field_71456_v.func_146158_b().func_146234_a(new TextComponentString(Notify.getInstance().getCommandMessage() + " " + ChatFormatting.WHITE + ChatFormatting.BOLD + player.func_70005_c_() + ChatFormatting.RESET + ChatFormatting.RED + " has popped " + ChatFormatting.WHITE + ChatFormatting.BOLD + l_Count + ChatFormatting.RESET + ChatFormatting.RED + " totems."), id);
            }

         }
      }
   }
}
