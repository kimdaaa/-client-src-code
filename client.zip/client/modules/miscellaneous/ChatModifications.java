package client.modules.miscellaneous;

import client.events.PacketEvent;
import client.gui.impl.background.GuiChat;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.function.Predicate;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.util.text.ChatType;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ChatModifications extends Module {
   private static ChatModifications getInstance = new ChatModifications();
   public Setting suffix = this.register(new Setting("Suffix", true));
   public Setting customChat = this.register(new Setting("CustomChat", false));
   public Setting nameHighLight = this.register(new Setting("NameHighLight", false, (v) -> {
      return ((Boolean)this.customChat.getCurrentState()).booleanValue();
   }));
   public Setting smoothChat = this.register(new Setting("SmoothChat", false, (v) -> {
      return ((Boolean)this.customChat.getCurrentState()).booleanValue();
   }));
   public Setting xOffset = this.register(new Setting("XOffset", 0.0D, 0.0D, Integer.valueOf(600), (v) -> {
      return ((Boolean)this.smoothChat.getCurrentState()).booleanValue() && ((Boolean)this.customChat.getCurrentState()).booleanValue();
   }));
   public Setting yOffset = this.register(new Setting("YOffset", 0.0D, 0.0D, 30.0D, (v) -> {
      return ((Boolean)this.smoothChat.getCurrentState()).booleanValue() && ((Boolean)this.customChat.getCurrentState()).booleanValue();
   }));
   public Setting vSpeed = this.register(new Setting("VSpeed", 30.0D, 1.0D, 100.0D, (v) -> {
      return ((Boolean)this.smoothChat.getCurrentState()).booleanValue() && ((Boolean)this.customChat.getCurrentState()).booleanValue();
   }));
   public Setting vLength = this.register(new Setting("VLength", 10.0D, 5.0D, 100.0D, (v) -> {
      return ((Boolean)this.smoothChat.getCurrentState()).booleanValue() && ((Boolean)this.customChat.getCurrentState()).booleanValue();
   }));
   public Setting vIncrements = this.register(new Setting("VIncrements", 1.0D, 1.0D, 5.0D, (v) -> {
      return ((Boolean)this.smoothChat.getCurrentState()).booleanValue() && ((Boolean)this.customChat.getCurrentState()).booleanValue();
   }));
   public Setting type;
   public static GuiChat guiChatSmooth;
   public static GuiNewChat guiChat;

   public ChatModifications() {
      super("ChatModifications", "Modifies your chat", Module.Category.MISC);
      this.type = this.register(new Setting("Type", ChatModifications.Type.HORIZONTAL, (v) -> {
         return ((Boolean)this.smoothChat.getCurrentState()).booleanValue() && ((Boolean)this.customChat.getCurrentState()).booleanValue();
      }));
      this.setInstance();
   }

   public static ChatModifications getInstance() {
      if (getInstance == null) {
         getInstance = new ChatModifications();
      }

      return getInstance;
   }

   private void setInstance() {
      getInstance = this;
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send event) {
      if (event.getStage() == 0 && event.getPacket() instanceof CPacketChatMessage && ((Boolean)this.suffix.getCurrentState()).booleanValue()) {
         CPacketChatMessage packet = (CPacketChatMessage)event.getPacket();
         String s = packet.func_149439_c();
         if (s.startsWith("/")) {
            return;
         }

         s = s + " ⏣";
         if (s.length() >= 256) {
            s = s.substring(0, 256);
         }

         packet.field_149440_a = s;
      }

   }

   public void onEnable() {
      guiChatSmooth = new GuiChat(mc);
      ObfuscationReflectionHelper.setPrivateValue(GuiIngame.class, mc.field_71456_v, guiChatSmooth, new String[]{"field_73840_e"});
   }

   public void onDisable() {
      guiChat = new GuiNewChat(mc);
      ObfuscationReflectionHelper.setPrivateValue(GuiIngame.class, mc.field_71456_v, guiChat, new String[]{"field_73840_e"});
   }

   @SubscribeEvent
   public void onPacketReceive(PacketEvent.Receive event) {
      if (event.getPacket() instanceof SPacketChat) {
         if (((SPacketChat)event.getPacket()).func_192590_c() == ChatType.GAME_INFO) {
            return;
         }

         String originalMessage = ((SPacketChat)event.getPacket()).field_148919_a.func_150254_d();
         String message = originalMessage;
         if (((Boolean)this.nameHighLight.getCurrentState()).booleanValue()) {
            try {
               message.replace(mc.field_71439_g.func_70005_c_(), ChatFormatting.RED + mc.field_71439_g.func_70005_c_() + ChatFormatting.RESET);
            } catch (Exception var5) {
               var5.printStackTrace();
            }
         }
      }

   }

   public void onLogin() {
      if (this.isEnabled()) {
         this.disable();
         this.enable();
      }

   }

   public static enum Type {
      HORIZONTAL,
      VERTICAL;
   }
}
