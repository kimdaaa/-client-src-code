package client.modules.visual;

import client.events.Render3DEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.ColorUtil;
import client.util.EntityUtil;
import client.util.RenderUtil;
import java.awt.Color;
import java.util.Iterator;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public class CityESP extends Module {
   public Setting red = this.register(new Setting("Red", Integer.valueOf(120), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting green = this.register(new Setting("Green", Integer.valueOf(120), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting blue = this.register(new Setting("Blue", Integer.valueOf(120), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting alpha = this.register(new Setting("Alpha", Integer.valueOf(120), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting selfred = this.register(new Setting("SelfRed", Integer.valueOf(120), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting selfgreen = this.register(new Setting("SelfGreen", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting selfblue = this.register(new Setting("SelfBlue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting selfalpha = this.register(new Setting("SelfAlpha", Integer.valueOf(120), Integer.valueOf(0), Integer.valueOf(255)));

   public CityESP() {
      super("CityESP", "", Module.Category.VISUAL);
   }

   public void onRender3D(Render3DEvent event) {
      Iterator var2 = mc.field_71441_e.field_73010_i.iterator();

      while(var2.hasNext()) {
         EntityPlayer player = (EntityPlayer)var2.next();
         this.cityBlocks(player);
      }

   }

   public void cityBlocks(EntityPlayer player) {
      BlockPos pos = EntityUtil.getPlayerPos(player);
      if (EntityUtil.isSafe(player)) {
         if (mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150343_Z && mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c().func_177977_b()).func_177230_c() == Blocks.field_150357_h)) {
            if (player.func_70005_c_().contains(mc.func_110432_I().func_111285_a())) {
               RenderUtil.drawBoxESP(pos.func_177978_c(), new Color(ColorUtil.toRGBA(((Integer)this.selfred.getCurrentState()).intValue(), ((Integer)this.selfgreen.getCurrentState()).intValue(), ((Integer)this.selfblue.getCurrentState()).intValue(), ((Integer)this.selfalpha.getCurrentState()).intValue())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0F, false, true, ((Integer)this.selfalpha.getCurrentState()).intValue(), true);
            } else {
               RenderUtil.drawBoxESP(pos.func_177978_c(), new Color(ColorUtil.toRGBA(((Integer)this.red.getCurrentState()).intValue(), ((Integer)this.green.getCurrentState()).intValue(), ((Integer)this.blue.getCurrentState()).intValue(), ((Integer)this.alpha.getCurrentState()).intValue())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0F, false, true, ((Integer)this.alpha.getCurrentState()).intValue(), true);
            }
         }

         if (mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150343_Z && mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f().func_177977_b()).func_177230_c() == Blocks.field_150357_h)) {
            if (player.func_70005_c_().contains(mc.func_110432_I().func_111285_a())) {
               RenderUtil.drawBoxESP(pos.func_177974_f(), new Color(ColorUtil.toRGBA(((Integer)this.selfred.getCurrentState()).intValue(), ((Integer)this.selfgreen.getCurrentState()).intValue(), ((Integer)this.selfblue.getCurrentState()).intValue(), ((Integer)this.selfalpha.getCurrentState()).intValue())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0F, false, true, ((Integer)this.selfalpha.getCurrentState()).intValue(), true);
            } else {
               RenderUtil.drawBoxESP(pos.func_177974_f(), new Color(ColorUtil.toRGBA(((Integer)this.red.getCurrentState()).intValue(), ((Integer)this.green.getCurrentState()).intValue(), ((Integer)this.blue.getCurrentState()).intValue(), ((Integer)this.alpha.getCurrentState()).intValue())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0F, false, true, ((Integer)this.alpha.getCurrentState()).intValue(), true);
            }
         }

         if (mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150343_Z && mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d().func_177977_b()).func_177230_c() == Blocks.field_150357_h)) {
            if (player.func_70005_c_().contains(mc.func_110432_I().func_111285_a())) {
               RenderUtil.drawBoxESP(pos.func_177968_d(), new Color(ColorUtil.toRGBA(((Integer)this.selfred.getCurrentState()).intValue(), ((Integer)this.selfgreen.getCurrentState()).intValue(), ((Integer)this.selfblue.getCurrentState()).intValue(), ((Integer)this.selfalpha.getCurrentState()).intValue())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0F, false, true, ((Integer)this.selfalpha.getCurrentState()).intValue(), true);
            } else {
               RenderUtil.drawBoxESP(pos.func_177968_d(), new Color(ColorUtil.toRGBA(((Integer)this.red.getCurrentState()).intValue(), ((Integer)this.green.getCurrentState()).intValue(), ((Integer)this.blue.getCurrentState()).intValue(), ((Integer)this.alpha.getCurrentState()).intValue())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0F, false, true, ((Integer)this.alpha.getCurrentState()).intValue(), true);
            }
         }

         if (mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150343_Z && mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e().func_177977_b()).func_177230_c() == Blocks.field_150357_h)) {
            if (player.func_70005_c_().contains(mc.func_110432_I().func_111285_a())) {
               RenderUtil.drawBoxESP(pos.func_177976_e(), new Color(ColorUtil.toRGBA(((Integer)this.selfred.getCurrentState()).intValue(), ((Integer)this.selfgreen.getCurrentState()).intValue(), ((Integer)this.selfblue.getCurrentState()).intValue(), ((Integer)this.selfalpha.getCurrentState()).intValue())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0F, false, true, ((Integer)this.selfalpha.getCurrentState()).intValue(), true);
            } else {
               RenderUtil.drawBoxESP(pos.func_177976_e(), new Color(ColorUtil.toRGBA(((Integer)this.red.getCurrentState()).intValue(), ((Integer)this.green.getCurrentState()).intValue(), ((Integer)this.blue.getCurrentState()).intValue(), ((Integer)this.alpha.getCurrentState()).intValue())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0F, false, true, ((Integer)this.alpha.getCurrentState()).intValue(), true);
            }
         }
      }

   }
}
