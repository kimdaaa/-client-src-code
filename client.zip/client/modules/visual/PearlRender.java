package client.modules.visual;

import client.events.Render3DEvent;
import client.modules.Module;
import client.util.EntityUtil;
import client.util.MathUtil;
import client.util.RenderUtil;
import java.awt.Color;
import java.util.Iterator;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public class PearlRender extends Module {
   public PearlRender() {
      super("PearlRender", "Renders where pearls will go", Module.Category.VISUAL);
   }

   public double interpolate(double now, double then) {
      return then + (now - then) * (double)mc.func_184121_ak();
   }

   public double[] interpolate(Entity entity) {
      double posX = this.interpolate(entity.field_70165_t, entity.field_70142_S) - mc.func_175598_ae().field_78725_b;
      double posY = this.interpolate(entity.field_70163_u, entity.field_70137_T) - mc.func_175598_ae().field_78726_c;
      double posZ = this.interpolate(entity.field_70161_v, entity.field_70136_U) - mc.func_175598_ae().field_78723_d;
      return new double[]{posX, posY, posZ};
   }

   public void drawLineToEntity(Entity e, float red, float green, float blue, float opacity) {
      double[] xyz = this.interpolate(e);
      this.drawLine(xyz[0], xyz[1], xyz[2], red, green, blue, opacity);
   }

   public void drawLine(double posx, double posy, double posz, float red, float green, float blue, float opacity) {
      Vec3d eyes = (new Vec3d(0.0D, 0.0D, 1.0D)).func_178789_a(-((float)Math.toRadians((double)mc.field_71439_g.field_70125_A))).func_178785_b(-((float)Math.toRadians((double)mc.field_71439_g.field_70177_z)));
      this.drawLineFromPosToPos(eyes.field_72450_a, eyes.field_72448_b + (double)mc.field_71439_g.func_70047_e(), eyes.field_72449_c, posx, posy, posz, red, green, blue, opacity);
   }

   public void drawLineFromPosToPos(double posx, double posy, double posz, double posx2, double posy2, double posz2, float red, float green, float blue, float opacity) {
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(3042);
      GL11.glLineWidth(1.0F);
      GL11.glDisable(3553);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glColor4f(red, green, blue, opacity);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLoadIdentity();
      boolean bobbing = mc.field_71474_y.field_74336_f;
      mc.field_71474_y.field_74336_f = false;
      mc.field_71460_t.func_78467_g(mc.func_184121_ak());
      GL11.glBegin(1);
      GL11.glVertex3d(posx, posy, posz);
      GL11.glVertex3d(posx2, posy2, posz2);
      GL11.glEnd();
      GL11.glEnable(3553);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glColor3d(1.0D, 1.0D, 1.0D);
      mc.field_71474_y.field_74336_f = bobbing;
   }

   public void onRender3D(Render3DEvent event) {
      int i = 0;
      Iterator var5 = mc.field_71441_e.field_72996_f.iterator();

      while(var5.hasNext()) {
         Entity entity = (Entity)var5.next();
         if (entity instanceof EntityEnderPearl && mc.field_71439_g.func_70068_e(entity) < 2500.0D) {
            Vec3d interp = EntityUtil.getInterpolatedRenderPos(entity, mc.func_184121_ak());
            AxisAlignedBB bb = new AxisAlignedBB(entity.func_174813_aQ().field_72340_a - 0.05D - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72338_b - 0.0D - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72339_c - 0.05D - entity.field_70161_v + interp.field_72449_c, entity.func_174813_aQ().field_72336_d + 0.05D - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72337_e + 0.1D - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72334_f + 0.05D - entity.field_70161_v + interp.field_72449_c);
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a(770, 771, 0, 1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a(false);
            GL11.glEnable(2848);
            GL11.glHint(3154, 4354);
            GL11.glLineWidth(1.0F);
            RenderGlobal.func_189696_b(bb, 255.0F, 255.0F, 255.0F, 255.0F);
            GL11.glDisable(2848);
            GlStateManager.func_179132_a(true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
            RenderUtil.drawBlockOutline(bb, new Color(255, 255, 255), 1.0F);
            this.drawLineToEntity(entity, 255.0F, 255.0F, 255.0F, 255.0F);
            BlockPos posEntity = entity.func_180425_c();
            RenderUtil.drawText(posEntity, "X: " + MathUtil.round(entity.field_70165_t, 0) + " Y: " + MathUtil.round(entity.field_70163_u, 0) + " Z:" + MathUtil.round(entity.field_70161_v, 2));
            ++i;
            if (i < 50) {
               continue;
            }
            break;
         }
      }

   }
}
