package client.modules.visual;

import client.modules.Module;

public class FullBright extends Module {
   public FullBright() {
      super("Fullbright", "Permanent brightness", Module.Category.VISUAL);
   }

   public void onEnable() {
      mc.field_71474_y.field_74333_Y = 1000.0F;
   }

   public void onUpdate() {
      if (mc.field_71474_y.field_74333_Y != 6969.0F) {
         mc.field_71474_y.field_74333_Y = 6969.0F;
      }

   }
}
