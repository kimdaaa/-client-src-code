package client.modules.visual;

import client.gui.impl.setting.Setting;
import client.modules.Module;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumHand;

public class SwingAnimations extends Module {
   private final Setting switchSetting;
   private final Setting swing;
   private final Setting speed;

   public SwingAnimations() {
      super("SwingAnimations", "Changes animations.", Module.Category.VISUAL);
      this.switchSetting = this.register(new Setting("Switch", SwingAnimations.Switch.ONEDOTEIGHT));
      this.swing = this.register(new Setting("Swing", SwingAnimations.Swing.MAINHAND));
      this.speed = this.register(new Setting("Speed", SwingAnimations.Speed.NORMAL));
   }

   public void onUpdate() {
      if (!nullCheck()) {
         if (this.swing.getCurrentState() == SwingAnimations.Swing.OFFHAND) {
            mc.field_71439_g.field_184622_au = EnumHand.OFF_HAND;
         }

         if (this.swing.getCurrentState() == SwingAnimations.Swing.MAINHAND) {
            mc.field_71439_g.field_184622_au = EnumHand.MAIN_HAND;
         }

         if (this.switchSetting.getCurrentState() == SwingAnimations.Switch.ONEDOTEIGHT && (double)mc.field_71460_t.field_78516_c.field_187470_g >= 0.9D) {
            mc.field_71460_t.field_78516_c.field_187469_f = 1.0F;
            mc.field_71460_t.field_78516_c.field_187467_d = mc.field_71439_g.func_184614_ca();
         }

         if (this.speed.getCurrentState() == SwingAnimations.Speed.SLOW) {
            mc.field_71439_g.func_70690_d(new PotionEffect(MobEffects.field_76419_f, 10));
            mc.field_71439_g.func_184589_d(MobEffects.field_76422_e);
         } else if (this.speed.getCurrentState() == SwingAnimations.Speed.NORMAL) {
            mc.field_71439_g.func_184589_d(MobEffects.field_76419_f);
            mc.field_71439_g.func_184589_d(MobEffects.field_76422_e);
         } else if (this.speed.getCurrentState() == SwingAnimations.Speed.FAST) {
            mc.field_71439_g.func_184589_d(MobEffects.field_76419_f);
            mc.field_71439_g.func_70690_d(new PotionEffect(MobEffects.field_76422_e, 10));
         }

      }
   }

   public void onDisable() {
      mc.field_71439_g.func_184589_d(MobEffects.field_76419_f);
      mc.field_71439_g.func_184589_d(MobEffects.field_76422_e);
   }

   private static enum Speed {
      SLOW,
      NORMAL,
      FAST;
   }

   private static enum Swing {
      MAINHAND,
      OFFHAND;
   }

   private static enum Switch {
      ONEDOTNINE,
      ONEDOTEIGHT;
   }
}
