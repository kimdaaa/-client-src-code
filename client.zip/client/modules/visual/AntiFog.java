package client.modules.visual;

import client.gui.impl.setting.Setting;
import client.modules.Module;
import net.minecraftforge.client.event.EntityViewRenderEvent.FogColors;
import net.minecraftforge.client.event.EntityViewRenderEvent.FogDensity;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AntiFog extends Module {
   private final Setting red = this.register(new Setting("Red", 1.0F, 0.0F, 1.0F));
   private final Setting green = this.register(new Setting("Green", 1.0F, 0.0F, 1.0F));
   private final Setting blue = this.register(new Setting("Blue", 1.0F, 0.0F, 1.0F));
   private final Setting red1 = this.register(new Setting("Nether Red", 1.0F, 0.0F, 1.0F));
   private final Setting green1 = this.register(new Setting("Nether Green", 1.0F, 0.0F, 1.0F));
   private final Setting blue1 = this.register(new Setting("Nether Blue", 1.0F, 0.0F, 1.0F));
   private final Setting red2 = this.register(new Setting("End Red", 1.0F, 0.0F, 1.0F));
   private final Setting green2 = this.register(new Setting("End Green", 1.0F, 0.0F, 1.0F));
   private final Setting blue2 = this.register(new Setting("End Blue", 1.0F, 0.0F, 1.0F));
   private final Setting clear = this.register(new Setting("Remove fog", true));
   private final Setting color = this.register(new Setting("Color fog", true));

   public AntiFog() {
      super("AntiFog", "Removes fog and makes it colored", Module.Category.VISUAL);
   }

   public void onLogin() {
      if (this.isEnabled()) {
         this.disable();
         this.enable();
      }

   }

   @SubscribeEvent
   public void onFogDensity(FogDensity event) {
      if (((Boolean)this.clear.getCurrentState()).booleanValue()) {
         event.setDensity(0.0F);
         event.setCanceled(true);
      }

   }

   @SubscribeEvent
   public void onFogColor(FogColors event) {
      if (((Boolean)this.color.getCurrentState()).booleanValue()) {
         if (mc.field_71439_g.field_71093_bK == 0) {
            event.setRed(((Float)this.red.getCurrentState()).floatValue());
            event.setGreen(((Float)this.green.getCurrentState()).floatValue());
            event.setBlue(((Float)this.blue.getCurrentState()).floatValue());
         } else if (mc.field_71439_g.field_71093_bK == -1) {
            event.setRed(((Float)this.red1.getCurrentState()).floatValue());
            event.setGreen(((Float)this.green1.getCurrentState()).floatValue());
            event.setBlue(((Float)this.blue1.getCurrentState()).floatValue());
         } else if (mc.field_71439_g.field_71093_bK == 1) {
            event.setRed(((Float)this.red2.getCurrentState()).floatValue());
            event.setGreen(((Float)this.green2.getCurrentState()).floatValue());
            event.setBlue(((Float)this.blue2.getCurrentState()).floatValue());
         }
      }

   }
}
