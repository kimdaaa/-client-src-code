package client.modules.visual;

import client.events.ClientEvent;
import client.events.Render2DEvent;
import client.events.Render3DEvent;
import client.gui.impl.setting.Setting;
import client.manager.TextManager;
import client.modules.Module;
import client.util.ColorUtil;
import client.util.EntityUtil;
import client.util.RenderUtil;
import com.google.common.collect.Sets;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.util.HashSet;
import java.util.Iterator;
import java.util.function.Predicate;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class ESP extends Module {
   public int updates;
   HashSet bedrockholes = Sets.newHashSet();
   HashSet obsidianholes = Sets.newHashSet();
   public Setting holes = this.register(new Setting("Holes", true));
   public Setting renderPerformance = this.register(new Setting("RenderPerformance", true));
   public Setting range = this.register(new Setting("X-Range", Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(20), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue();
   }));
   public Setting rangeY = this.register(new Setting("Y-Range", Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(20), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue();
   }));
   public Setting updateDelay = this.register(new Setting("UpdateDelay", Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(30), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue();
   }));
   public Setting bedrockBox = this.register(new Setting("BedrockBox", true, (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue();
   }));
   public Setting bedrockFlat = this.register(new Setting("BedrockFlat", true, (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue();
   }));
   public Setting bedrockBoxRed = this.register(new Setting("BedrockBoxRed", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.bedrockBox.getCurrentState()).booleanValue();
   }));
   public Setting bedrockBoxGreen = this.register(new Setting("BedrockBoxGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.bedrockBox.getCurrentState()).booleanValue();
   }));
   public Setting bedrockBoxBlue = this.register(new Setting("BedrockBoxBlue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.bedrockBox.getCurrentState()).booleanValue();
   }));
   public Setting bedrockBoxAlpha = this.register(new Setting("BedrockBoxAlpha", Integer.valueOf(120), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.bedrockBox.getCurrentState()).booleanValue();
   }));
   public Setting bedrockOutline = this.register(new Setting("BedrockOutline", true, (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue();
   }));
   public Setting bedrockOutlineRed = this.register(new Setting("BedrockOutlineRed", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.bedrockOutline.getCurrentState()).booleanValue();
   }));
   public Setting bedrockOutlineGreen = this.register(new Setting("BedrockOutlineGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.bedrockOutline.getCurrentState()).booleanValue();
   }));
   public Setting bedrockOutlineBlue = this.register(new Setting("BedrockOutlineBlue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.bedrockOutline.getCurrentState()).booleanValue();
   }));
   public Setting bedrockOutlineAlpha = this.register(new Setting("BedrockOutlineAlpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.bedrockOutline.getCurrentState()).booleanValue();
   }));
   public Setting bedrockOutlineLineWidth = this.register(new Setting("BedrockOutlineLineWidth", Integer.valueOf(1), 0.1D, Integer.valueOf(5), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.bedrockOutline.getCurrentState()).booleanValue();
   }));
   public Setting obsidianBox = this.register(new Setting("ObsidianBox", true, (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue();
   }));
   public Setting obsidianFlat = this.register(new Setting("ObsidianFlat", false, (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue();
   }));
   public Setting obsidianBoxRed = this.register(new Setting("ObsidianBoxRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.obsidianBox.getCurrentState()).booleanValue();
   }));
   public Setting obsidianBoxGreen = this.register(new Setting("ObsidianBoxGreen", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.obsidianBox.getCurrentState()).booleanValue();
   }));
   public Setting obsidianBoxBlue = this.register(new Setting("ObsidianBoxBlue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.obsidianBox.getCurrentState()).booleanValue();
   }));
   public Setting obsidianBoxAlpha = this.register(new Setting("ObsidianBoxAlpha", Integer.valueOf(120), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.obsidianBox.getCurrentState()).booleanValue();
   }));
   public Setting obsidianOutline = this.register(new Setting("ObsidianOutline", true, (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue();
   }));
   public Setting obsidianOutlineRed = this.register(new Setting("ObsidianOutlineRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.obsidianOutline.getCurrentState()).booleanValue();
   }));
   public Setting obsidianOutlineGreen = this.register(new Setting("ObsidianOutlineGreen", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.obsidianOutline.getCurrentState()).booleanValue();
   }));
   public Setting obsidianOutlineBlue = this.register(new Setting("ObsidianOutlineBlue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.obsidianOutline.getCurrentState()).booleanValue();
   }));
   public Setting obsidianOutlineAlpha = this.register(new Setting("ObsidianOutlineAlpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.obsidianOutline.getCurrentState()).booleanValue();
   }));
   public Setting obsidianOutlineLineWidth = this.register(new Setting("obsidianOutlineLineWidth", Integer.valueOf(1), 0.1D, Integer.valueOf(5), (v) -> {
      return ((Boolean)this.holes.getCurrentState()).booleanValue() && ((Boolean)this.obsidianOutline.getCurrentState()).booleanValue();
   }));
   public Setting bottles = this.register(new Setting("Bottles", true));
   public Setting bottlesred = this.register(new Setting("BottlesRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.bottles.getCurrentState()).booleanValue();
   }));
   public Setting bottlesgreen = this.register(new Setting("BottlesGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.bottles.getCurrentState()).booleanValue();
   }));
   public Setting bottlesblue = this.register(new Setting("BottlesBlue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.bottles.getCurrentState()).booleanValue();
   }));
   public Setting bottlesalpha = this.register(new Setting("BottlesAlpha", Integer.valueOf(150), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.bottles.getCurrentState()).booleanValue();
   }));
   public Setting orbs = this.register(new Setting("Orbs", true));
   public Setting o_red = this.register(new Setting("OrbsRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.orbs.getCurrentState()).booleanValue();
   }));
   public Setting o_green = this.register(new Setting("OrbsGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.orbs.getCurrentState()).booleanValue();
   }));
   public Setting o_blue = this.register(new Setting("OrbsBlue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.orbs.getCurrentState()).booleanValue();
   }));
   public Setting o_alpha = this.register(new Setting("OrbsAlpha", Integer.valueOf(150), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.orbs.getCurrentState()).booleanValue();
   }));

   public ESP() {
      super("ESP", "", Module.Category.VISUAL);
   }

   public void onTick() {
      if (((Boolean)this.holes.getCurrentState()).booleanValue()) {
         if (this.updates > ((Integer)this.updateDelay.getCurrentState()).intValue()) {
            this.updates = 0;
         } else {
            ++this.updates;
         }
      }

   }

   @SubscribeEvent
   public void onSettingChange(ClientEvent event) {
      if (!((Boolean)this.holes.getCurrentState()).booleanValue()) {
         this.obsidianholes.clear();
         this.bedrockholes.clear();
         this.updates = 0;
      }

   }

   public void onEnable() {
      this.updates = 0;
   }

   public void onRender3D(Render3DEvent event) {
      Iterator var2 = this.bedrockholes.iterator();

      BlockPos pos;
      while(var2.hasNext()) {
         pos = (BlockPos)var2.next();
         if (((Boolean)this.bedrockFlat.getCurrentState()).booleanValue()) {
            RenderUtil.drawBoxESPFlat(pos, new Color(ColorUtil.toRGBA(((Integer)this.bedrockBoxRed.getCurrentState()).intValue(), ((Integer)this.bedrockBoxGreen.getCurrentState()).intValue(), ((Integer)this.bedrockBoxBlue.getCurrentState()).intValue(), ((Integer)this.bedrockBoxAlpha.getCurrentState()).intValue())), true, new Color(ColorUtil.toRGBA(((Integer)this.bedrockOutlineRed.getCurrentState()).intValue(), ((Integer)this.bedrockOutlineGreen.getCurrentState()).intValue(), ((Integer)this.bedrockOutlineBlue.getCurrentState()).intValue(), ((Integer)this.bedrockOutlineAlpha.getCurrentState()).intValue())), (float)((Integer)this.bedrockOutlineLineWidth.getCurrentState()).intValue(), ((Boolean)this.bedrockOutline.getCurrentState()).booleanValue(), ((Boolean)this.bedrockBox.getCurrentState()).booleanValue(), ((Integer)this.bedrockBoxAlpha.getCurrentState()).intValue(), true);
         } else {
            RenderUtil.drawBoxESP(pos, new Color(ColorUtil.toRGBA(((Integer)this.bedrockBoxRed.getCurrentState()).intValue(), ((Integer)this.bedrockBoxGreen.getCurrentState()).intValue(), ((Integer)this.bedrockBoxBlue.getCurrentState()).intValue(), ((Integer)this.bedrockBoxAlpha.getCurrentState()).intValue())), true, new Color(ColorUtil.toRGBA(((Integer)this.bedrockOutlineRed.getCurrentState()).intValue(), ((Integer)this.bedrockOutlineGreen.getCurrentState()).intValue(), ((Integer)this.bedrockOutlineBlue.getCurrentState()).intValue(), ((Integer)this.bedrockOutlineAlpha.getCurrentState()).intValue())), (float)((Integer)this.bedrockOutlineLineWidth.getCurrentState()).intValue(), ((Boolean)this.bedrockOutline.getCurrentState()).booleanValue(), ((Boolean)this.bedrockBox.getCurrentState()).booleanValue(), ((Integer)this.bedrockBoxAlpha.getCurrentState()).intValue(), true);
         }
      }

      var2 = this.obsidianholes.iterator();

      while(var2.hasNext()) {
         pos = (BlockPos)var2.next();
         if (((Boolean)this.obsidianFlat.getCurrentState()).booleanValue()) {
            RenderUtil.drawBoxESPFlat(pos, new Color(ColorUtil.toRGBA(((Integer)this.obsidianBoxRed.getCurrentState()).intValue(), ((Integer)this.obsidianBoxGreen.getCurrentState()).intValue(), ((Integer)this.obsidianBoxBlue.getCurrentState()).intValue(), ((Integer)this.obsidianBoxAlpha.getCurrentState()).intValue())), true, new Color(ColorUtil.toRGBA(((Integer)this.obsidianOutlineRed.getCurrentState()).intValue(), ((Integer)this.obsidianOutlineGreen.getCurrentState()).intValue(), ((Integer)this.obsidianOutlineBlue.getCurrentState()).intValue(), ((Integer)this.obsidianOutlineAlpha.getCurrentState()).intValue())), (float)((Integer)this.obsidianOutlineLineWidth.getCurrentState()).intValue(), ((Boolean)this.obsidianOutline.getCurrentState()).booleanValue(), ((Boolean)this.obsidianBox.getCurrentState()).booleanValue(), ((Integer)this.obsidianBoxAlpha.getCurrentState()).intValue(), true);
         } else {
            RenderUtil.drawBoxESP(pos, new Color(ColorUtil.toRGBA(((Integer)this.obsidianBoxRed.getCurrentState()).intValue(), ((Integer)this.obsidianBoxGreen.getCurrentState()).intValue(), ((Integer)this.obsidianBoxBlue.getCurrentState()).intValue(), ((Integer)this.obsidianBoxAlpha.getCurrentState()).intValue())), true, new Color(ColorUtil.toRGBA(((Integer)this.obsidianOutlineRed.getCurrentState()).intValue(), ((Integer)this.obsidianOutlineGreen.getCurrentState()).intValue(), ((Integer)this.obsidianOutlineBlue.getCurrentState()).intValue(), ((Integer)this.obsidianOutlineAlpha.getCurrentState()).intValue())), (float)((Integer)this.obsidianOutlineLineWidth.getCurrentState()).intValue(), ((Boolean)this.obsidianOutline.getCurrentState()).booleanValue(), ((Boolean)this.obsidianBox.getCurrentState()).booleanValue(), ((Integer)this.obsidianBoxAlpha.getCurrentState()).intValue(), true);
         }
      }

      if (this.updates > ((Integer)this.updateDelay.getCurrentState()).intValue() && ((Boolean)this.holes.getCurrentState()).booleanValue()) {
         this.obsidianholes.clear();
         this.bedrockholes.clear();
         this.findHoles();
      }

      int i = 0;
      Iterator var5;
      Entity entity;
      AxisAlignedBB bb;
      Vec3d interp;
      if (((Boolean)this.orbs.getCurrentState()).booleanValue()) {
         var5 = mc.field_71441_e.field_72996_f.iterator();

         while(var5.hasNext()) {
            entity = (Entity)var5.next();
            if (entity instanceof EntityXPOrb && mc.field_71439_g.func_70068_e(entity) < 2500.0D) {
               interp = EntityUtil.getInterpolatedRenderPos(entity, mc.func_184121_ak());
               bb = new AxisAlignedBB(entity.func_174813_aQ().field_72340_a - 0.05D - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72338_b - 0.0D - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72339_c - 0.05D - entity.field_70161_v + interp.field_72449_c, entity.func_174813_aQ().field_72336_d + 0.05D - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72337_e + 0.1D - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72334_f + 0.05D - entity.field_70161_v + interp.field_72449_c);
               GlStateManager.func_179094_E();
               GlStateManager.func_179147_l();
               GlStateManager.func_179097_i();
               GlStateManager.func_179120_a(770, 771, 0, 1);
               GlStateManager.func_179090_x();
               GlStateManager.func_179132_a(false);
               GL11.glEnable(2848);
               GL11.glHint(3154, 4354);
               GL11.glLineWidth(1.0F);
               RenderGlobal.func_189696_b(bb, (float)((Integer)this.bottlesred.getCurrentState()).intValue() / 255.0F, (float)((Integer)this.bottlesgreen.getCurrentState()).intValue() / 255.0F, (float)((Integer)this.bottlesblue.getCurrentState()).intValue() / 255.0F, (float)((Integer)this.bottlesalpha.getCurrentState()).intValue() / 255.0F);
               GL11.glDisable(2848);
               GlStateManager.func_179132_a(true);
               GlStateManager.func_179126_j();
               GlStateManager.func_179098_w();
               GlStateManager.func_179084_k();
               GlStateManager.func_179121_F();
               RenderUtil.drawBlockOutline(bb, new Color(((Integer)this.bottlesred.getCurrentState()).intValue(), ((Integer)this.bottlesgreen.getCurrentState()).intValue(), ((Integer)this.bottlesblue.getCurrentState()).intValue(), ((Integer)this.bottlesalpha.getCurrentState()).intValue()), 1.0F);
               ++i;
               if (i >= 50) {
                  break;
               }
            }
         }
      }

      if (((Boolean)this.bottles.getCurrentState()).booleanValue()) {
         i = 0;
         var5 = mc.field_71441_e.field_72996_f.iterator();

         while(var5.hasNext()) {
            entity = (Entity)var5.next();
            if (entity instanceof EntityExpBottle && mc.field_71439_g.func_70068_e(entity) < 2500.0D) {
               interp = EntityUtil.getInterpolatedRenderPos(entity, mc.func_184121_ak());
               bb = new AxisAlignedBB(entity.func_174813_aQ().field_72340_a - 0.05D - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72338_b - 0.0D - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72339_c - 0.05D - entity.field_70161_v + interp.field_72449_c, entity.func_174813_aQ().field_72336_d + 0.05D - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72337_e + 0.1D - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72334_f + 0.05D - entity.field_70161_v + interp.field_72449_c);
               GlStateManager.func_179094_E();
               GlStateManager.func_179147_l();
               GlStateManager.func_179097_i();
               GlStateManager.func_179120_a(770, 771, 0, 1);
               GlStateManager.func_179090_x();
               GlStateManager.func_179132_a(false);
               GL11.glEnable(2848);
               GL11.glHint(3154, 4354);
               GL11.glLineWidth(1.0F);
               RenderGlobal.func_189696_b(bb, (float)((Integer)this.o_red.getCurrentState()).intValue() / 255.0F, (float)((Integer)this.o_green.getCurrentState()).intValue() / 255.0F, (float)((Integer)this.o_blue.getCurrentState()).intValue() / 255.0F, (float)((Integer)this.o_alpha.getCurrentState()).intValue() / 255.0F);
               GL11.glDisable(2848);
               GlStateManager.func_179132_a(true);
               GlStateManager.func_179126_j();
               GlStateManager.func_179098_w();
               GlStateManager.func_179084_k();
               GlStateManager.func_179121_F();
               RenderUtil.drawBlockOutline(bb, new Color(((Integer)this.o_red.getCurrentState()).intValue(), ((Integer)this.o_green.getCurrentState()).intValue(), ((Integer)this.o_blue.getCurrentState()).intValue(), ((Integer)this.o_alpha.getCurrentState()).intValue()), 1.0F);
               ++i;
               if (i >= 50) {
                  break;
               }
            }
         }
      }

   }

   public void onRender2D(Render2DEvent event) {
      if (((Boolean)this.renderPerformance.getCurrentState()).booleanValue()) {
         TextManager var10000 = this.renderer;
         StringBuilder var10001 = (new StringBuilder()).append(ChatFormatting.WHITE).append("ESP ").append(ChatFormatting.DARK_GRAY).append("[").append(ChatFormatting.GRAY).append(this.updates).append(" | ");
         Minecraft var10002 = mc;
         var10000.drawStringWithShadow(var10001.append(Minecraft.func_175610_ah()).append(ChatFormatting.DARK_GRAY).append("]").toString(), 0.0F, 10.0F, 0);
      }

   }

   public void findHoles() {
      assert mc.field_175622_Z != null;

      Vec3i playerPos = new Vec3i(mc.field_175622_Z.field_70165_t, mc.field_175622_Z.field_70163_u, mc.field_175622_Z.field_70161_v);

      for(int x = playerPos.func_177958_n() - ((Integer)this.range.getCurrentState()).intValue(); x < playerPos.func_177958_n() + ((Integer)this.range.getCurrentState()).intValue(); ++x) {
         for(int z = playerPos.func_177952_p() - ((Integer)this.range.getCurrentState()).intValue(); z < playerPos.func_177952_p() + ((Integer)this.range.getCurrentState()).intValue(); ++z) {
            for(int y = playerPos.func_177956_o() + ((Integer)this.rangeY.getCurrentState()).intValue(); y > playerPos.func_177956_o() - ((Integer)this.rangeY.getCurrentState()).intValue(); --y) {
               BlockPos pos = new BlockPos(x, y, z);
               if (this.updates > ((Integer)this.updateDelay.getCurrentState()).intValue()) {
                  if (mc.field_71441_e.func_180495_p(pos.func_177984_a()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h) {
                     this.bedrockholes.add(pos);
                  } else if (mc.field_71441_e.func_180495_p(pos.func_177984_a()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150350_a && (mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150357_h || mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150343_Z) && (mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150357_h) && (mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h) && (mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150357_h) && (mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h)) {
                     this.obsidianholes.add(pos);
                  } else if (mc.field_71441_e.func_180495_p(pos.func_177984_a()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177984_a()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177977_b()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177974_f()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177976_e()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h) {
                     this.bedrockholes.add(pos);
                     this.bedrockholes.add(pos.func_177978_c());
                  } else if (mc.field_71441_e.func_180495_p(pos.func_177984_a()).func_177230_c() != Blocks.field_150350_a || mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177984_a()).func_177230_c() != Blocks.field_150350_a || mc.field_71441_e.func_180495_p(pos).func_177230_c() != Blocks.field_150350_a || mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() != Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() != Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() != Blocks.field_150350_a || mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() != Blocks.field_150343_Z && mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() != Blocks.field_150357_h || mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() != Blocks.field_150343_Z && mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() != Blocks.field_150357_h || mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() != Blocks.field_150343_Z && mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() != Blocks.field_150357_h || mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c()).func_177230_c() != Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c()).func_177230_c() != Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177974_f()).func_177230_c() != Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177974_f()).func_177230_c() != Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177976_e()).func_177230_c() != Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177976_e()).func_177230_c() != Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177977_b()).func_177230_c() != Blocks.field_150343_Z && mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177977_b()).func_177230_c() != Blocks.field_150357_h) {
                     if (mc.field_71441_e.func_180495_p(pos.func_177984_a()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177984_a()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177977_b()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177968_d()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177978_c()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e()).func_177230_c() == Blocks.field_150357_h) {
                        this.bedrockholes.add(pos);
                        this.bedrockholes.add(pos.func_177976_e());
                     } else if (mc.field_71441_e.func_180495_p(pos.func_177984_a()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177984_a()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150350_a && (mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150357_h || mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150343_Z) && (mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177977_b()).func_177230_c() == Blocks.field_150357_h || mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177977_b()).func_177230_c() == Blocks.field_150343_Z) && (mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150357_h || mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150343_Z) && (mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h || mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150343_Z) && mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150350_a && (mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h || mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150343_Z) && (mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177968_d()).func_177230_c() == Blocks.field_150357_h || mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177968_d()).func_177230_c() == Blocks.field_150343_Z) && (mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177978_c()).func_177230_c() == Blocks.field_150357_h || mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177978_c()).func_177230_c() == Blocks.field_150343_Z) && (mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e()).func_177230_c() == Blocks.field_150357_h || mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e()).func_177230_c() == Blocks.field_150343_Z)) {
                        this.obsidianholes.add(pos);
                        this.obsidianholes.add(pos.func_177976_e());
                     }
                  } else {
                     this.obsidianholes.add(pos);
                     this.obsidianholes.add(pos.func_177978_c());
                  }
               }
            }
         }
      }

   }
}
