package client.modules.visual;

import client.Client;
import client.events.Render3DEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.EntityUtil;
import client.util.RenderUtil;
import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Predicate;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public class BurrowESP extends Module {
   private final Setting name = this.register(new Setting("Name", true));
   private final Setting setting;
   private final Setting e_box;
   private final Setting e_boxRed;
   private final Setting e_boxGreen;
   private final Setting e_boxBlue;
   private final Setting e_boxAlpha;
   private final Setting e_outline;
   private final Setting e_outlineWidth;
   private final Setting e_cOutline;
   private final Setting e_outlineRed;
   private final Setting e_outlineGreen;
   private final Setting e_outlineBlue;
   private final Setting e_outlineAlpha;
   private final Setting o_box;
   private final Setting o_boxRed;
   private final Setting o_boxGreen;
   private final Setting o_boxBlue;
   private final Setting o_boxAlpha;
   private final Setting o_outline;
   private final Setting o_outlineWidth;
   private final Setting o_cOutline;
   private final Setting o_outlineRed;
   private final Setting o_outlineGreen;
   private final Setting o_outlineBlue;
   private final Setting o_outlineAlpha;
   private final Map burrowedPlayers;

   public BurrowESP() {
      super("BurrowESP", "Shows info about target", Module.Category.VISUAL);
      this.setting = this.register(new Setting("Setting", BurrowESP.Settings.ECHEST));
      this.e_box = new Setting("Box", true);
      this.e_boxRed = this.register(new Setting("BoxRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.e_box.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.ECHEST;
      }));
      this.e_boxGreen = this.register(new Setting("BoxGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.e_box.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.ECHEST;
      }));
      this.e_boxBlue = this.register(new Setting("BoxBlue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.e_box.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.ECHEST;
      }));
      this.e_boxAlpha = this.register(new Setting("BoxAlpha", Integer.valueOf(127), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.e_box.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.ECHEST;
      }));
      this.e_outline = this.register(new Setting("Outline", true, (v) -> {
         return this.setting.getCurrentState() == BurrowESP.Settings.ECHEST;
      }));
      this.e_outlineWidth = this.register(new Setting("OutlineWidth", 1.0F, 0.0F, 5.0F, (v) -> {
         return this.setting.getCurrentState() == BurrowESP.Settings.ECHEST;
      }));
      this.e_cOutline = this.register(new Setting("CustomOutline", true, (v) -> {
         return this.setting.getCurrentState() == BurrowESP.Settings.ECHEST;
      }));
      this.e_outlineRed = this.register(new Setting("OutlineRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.e_outline.getCurrentState()).booleanValue() && ((Boolean)this.e_cOutline.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.ECHEST;
      }));
      this.e_outlineGreen = this.register(new Setting("OutlineGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.e_outline.getCurrentState()).booleanValue() && ((Boolean)this.e_cOutline.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.ECHEST;
      }));
      this.e_outlineBlue = this.register(new Setting("OutlineBlue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.e_outline.getCurrentState()).booleanValue() && ((Boolean)this.e_cOutline.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.ECHEST;
      }));
      this.e_outlineAlpha = this.register(new Setting("OutlineAlpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.e_outline.getCurrentState()).booleanValue() && ((Boolean)this.e_cOutline.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.ECHEST;
      }));
      this.o_box = new Setting("Box", true);
      this.o_boxRed = this.register(new Setting("BoxRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.o_box.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.OBSIDIAN;
      }));
      this.o_boxGreen = this.register(new Setting("BoxGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.o_box.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.OBSIDIAN;
      }));
      this.o_boxBlue = this.register(new Setting("BoxBlue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.o_box.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.OBSIDIAN;
      }));
      this.o_boxAlpha = this.register(new Setting("BoxAlpha", Integer.valueOf(127), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.o_box.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.OBSIDIAN;
      }));
      this.o_outline = this.register(new Setting("Outline", true, (v) -> {
         return this.setting.getCurrentState() == BurrowESP.Settings.OBSIDIAN;
      }));
      this.o_outlineWidth = this.register(new Setting("OutlineWidth", 1.0F, 0.0F, 5.0F, (v) -> {
         return this.setting.getCurrentState() == BurrowESP.Settings.OBSIDIAN;
      }));
      this.o_cOutline = this.register(new Setting("CustomOutline", true, (v) -> {
         return this.setting.getCurrentState() == BurrowESP.Settings.OBSIDIAN;
      }));
      this.o_outlineRed = this.register(new Setting("OutlineRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.o_outline.getCurrentState()).booleanValue() && ((Boolean)this.o_cOutline.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.OBSIDIAN;
      }));
      this.o_outlineGreen = this.register(new Setting("OutlineGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.o_outline.getCurrentState()).booleanValue() && ((Boolean)this.o_cOutline.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.OBSIDIAN;
      }));
      this.o_outlineBlue = this.register(new Setting("OutlineBlue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.o_outline.getCurrentState()).booleanValue() && ((Boolean)this.o_cOutline.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.OBSIDIAN;
      }));
      this.o_outlineAlpha = this.register(new Setting("OutlineAlpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.o_outline.getCurrentState()).booleanValue() && ((Boolean)this.o_cOutline.getCurrentState()).booleanValue() && this.setting.getCurrentState() == BurrowESP.Settings.OBSIDIAN;
      }));
      this.burrowedPlayers = new HashMap();
   }

   public void onEnable() {
      this.burrowedPlayers.clear();
   }

   public void onUpdate() {
      if (!fullNullCheck()) {
         this.burrowedPlayers.clear();
         this.getPlayers();
      }
   }

   public void onRender3D(Render3DEvent event) {
      if (!this.burrowedPlayers.isEmpty()) {
         this.burrowedPlayers.forEach((key, value) -> {
            this.renderBurrowedBlock(value);
            if (((Boolean)this.name.getCurrentState()).booleanValue()) {
               RenderUtil.drawText(value, key.func_146103_bH().getName());
            }

         });
      }

   }

   private void renderBurrowedBlock(BlockPos pos) {
      if (mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150477_bB) {
         RenderUtil.drawBoxESP(pos, new Color(((Integer)this.e_boxRed.getCurrentState()).intValue(), ((Integer)this.e_boxGreen.getCurrentState()).intValue(), ((Integer)this.e_boxBlue.getCurrentState()).intValue(), ((Integer)this.e_boxAlpha.getCurrentState()).intValue()), true, new Color(((Integer)this.e_outlineRed.getCurrentState()).intValue(), ((Integer)this.e_outlineGreen.getCurrentState()).intValue(), ((Integer)this.e_outlineBlue.getCurrentState()).intValue(), ((Integer)this.e_outlineAlpha.getCurrentState()).intValue()), ((Float)this.e_outlineWidth.getCurrentState()).floatValue(), ((Boolean)this.e_outline.getCurrentState()).booleanValue(), ((Boolean)this.e_box.getCurrentState()).booleanValue(), ((Integer)this.e_boxAlpha.getCurrentState()).intValue(), true);
      }

      if (mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150343_Z) {
         RenderUtil.drawBoxESP(pos, new Color(((Integer)this.o_boxRed.getCurrentState()).intValue(), ((Integer)this.o_boxGreen.getCurrentState()).intValue(), ((Integer)this.o_boxBlue.getCurrentState()).intValue(), ((Integer)this.o_boxAlpha.getCurrentState()).intValue()), true, new Color(((Integer)this.o_outlineRed.getCurrentState()).intValue(), ((Integer)this.o_outlineGreen.getCurrentState()).intValue(), ((Integer)this.o_outlineBlue.getCurrentState()).intValue(), ((Integer)this.o_outlineAlpha.getCurrentState()).intValue()), ((Float)this.o_outlineWidth.getCurrentState()).floatValue(), ((Boolean)this.o_outline.getCurrentState()).booleanValue(), ((Boolean)this.o_box.getCurrentState()).booleanValue(), ((Integer)this.o_boxAlpha.getCurrentState()).intValue(), true);
      }

   }

   private void getPlayers() {
      Iterator var1 = mc.field_71441_e.field_73010_i.iterator();

      while(var1.hasNext()) {
         EntityPlayer player = (EntityPlayer)var1.next();
         if (player != mc.field_71439_g && !Client.friendManager.isFriend(player.func_70005_c_()) && EntityUtil.isLiving(player) && this.isBurrowed(player)) {
            this.burrowedPlayers.put(player, new BlockPos(player.field_70165_t, player.field_70163_u, player.field_70161_v));
         }
      }

   }

   private boolean isBurrowed(EntityPlayer player) {
      BlockPos pos = new BlockPos(Math.floor(player.field_70165_t), Math.floor(player.field_70163_u + 0.2D), Math.floor(player.field_70161_v));
      return mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150477_bB || mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150343_Z;
   }

   public static enum Settings {
      OBSIDIAN,
      ECHEST;
   }
}
