package client.modules.visual;

import client.gui.impl.setting.Bind;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import org.lwjgl.input.Keyboard;

public class ThirdPerson extends Module {
   public Setting onlyHold = this.register(new Setting("OnlyHoldBind", false));
   public Setting bind = this.register(new Setting("Bind:", new Bind(-1)));

   public ThirdPerson() {
      super("ThirdPerson", "Third person camera but hold bind.", Module.Category.VISUAL);
   }

   public void onUpdate() {
      if (((Bind)this.bind.getCurrentState()).getKey() > -1) {
         if (Keyboard.isKeyDown(((Bind)this.bind.getCurrentState()).getKey())) {
            mc.field_71474_y.field_74320_O = 1;
         } else {
            mc.field_71474_y.field_74320_O = 0;
         }
      }

   }

   public void onEnable() {
      if (!((Boolean)this.onlyHold.getCurrentState()).booleanValue()) {
         mc.field_71474_y.field_74320_O = 1;
      }

   }

   public void onDisable() {
      if (!((Boolean)this.onlyHold.getCurrentState()).booleanValue()) {
         mc.field_71474_y.field_74320_O = 0;
      }

   }
}
