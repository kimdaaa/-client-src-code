package client.modules.visual;

import client.gui.impl.setting.Setting;
import client.modules.Module;

public class Viewmodel extends Module {
   public Setting sizeX = this.register(new Setting("SizeX", 1.0F, 0.0F, 2.0F));
   public Setting sizeY = this.register(new Setting("SizeY", 1.0F, 0.0F, 2.0F));
   public Setting sizeZ = this.register(new Setting("SizeZ", 1.0F, 0.0F, 2.0F));
   public final Setting offsetX = this.register(new Setting("OffsetX", 0.0F, -1.0F, 1.0F));
   public final Setting offsetY = this.register(new Setting("OffsetY", 0.0F, -1.0F, 1.0F));
   public final Setting offsetZ = this.register(new Setting("OffsetZ", 0.0F, -1.0F, 1.0F));
   public final Setting offhandX = this.register(new Setting("OffhandX", 0.0F, -1.0F, 1.0F));
   public final Setting offhandY = this.register(new Setting("OffhandY", 0.0F, -1.0F, 1.0F));
   public final Setting offhandZ = this.register(new Setting("OffhandZ", 0.0F, -1.0F, 1.0F));
   private static Viewmodel INSTANCE = new Viewmodel();

   public Viewmodel() {
      super("Viewmodel", "Changes to the size and positions of your hands.", Module.Category.VISUAL);
      this.setInstance();
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public static Viewmodel getINSTANCE() {
      if (INSTANCE == null) {
         INSTANCE = new Viewmodel();
      }

      return INSTANCE;
   }
}
