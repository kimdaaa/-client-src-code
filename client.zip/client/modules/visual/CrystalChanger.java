package client.modules.visual;

import client.events.PacketEvent;
import client.events.RenderEntityModelEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.ColorUtil;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.network.play.server.SPacketDestroyEntities;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class CrystalChanger extends Module {
   private static CrystalChanger INSTANCE;
   public Setting chams = this.register(new Setting("Chams", true));
   public Setting glint = this.register(new Setting("Glint", true));
   public Setting wireframe = this.register(new Setting("Wireframe", true));
   public Setting throughwalls = this.register(new Setting("Walls", true));
   public Setting XQZ = this.register(new Setting("Depth", true));
   public Setting red = this.register(new Setting("Red", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.chams.getCurrentState()).booleanValue();
   }));
   public Setting green = this.register(new Setting("Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.chams.getCurrentState()).booleanValue();
   }));
   public Setting blue = this.register(new Setting("Blue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.chams.getCurrentState()).booleanValue();
   }));
   public Setting alpha = this.register(new Setting("Alpha", Integer.valueOf(150), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.chams.getCurrentState()).booleanValue();
   }));
   public Setting w_red = this.register(new Setting("WireframeRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.wireframe.getCurrentState()).booleanValue();
   }));
   public Setting w_green = this.register(new Setting("WireframeGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.wireframe.getCurrentState()).booleanValue();
   }));
   public Setting w_blue = this.register(new Setting("WireframeBlue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.wireframe.getCurrentState()).booleanValue();
   }));
   public Setting w_alpha = this.register(new Setting("WireframeAlpha", Integer.valueOf(150), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.wireframe.getCurrentState()).booleanValue();
   }));
   public Setting h_red = this.register(new Setting("WallsRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.throughwalls.getCurrentState()).booleanValue();
   }));
   public Setting h_green = this.register(new Setting("WallsGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.throughwalls.getCurrentState()).booleanValue();
   }));
   public Setting h_blue = this.register(new Setting("WallsBlue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.throughwalls.getCurrentState()).booleanValue();
   }));
   public Setting h_alpha = this.register(new Setting("WallsAlpha", Integer.valueOf(150), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.throughwalls.getCurrentState()).booleanValue();
   }));
   public Setting width = this.register(new Setting("Width", 3.0D, 0.1D, 5.0D));
   public Setting scale = this.register(new Setting("Scale", 1.0D, 0.1D, 3.0D));
   public Map scaleMap = new ConcurrentHashMap();
   private final int color;
   private final int wireColor;
   private final int hiddenColor;

   public CrystalChanger() {
      super("CrystalChanger", "Modifies looks of end crystals.", Module.Category.VISUAL);
      this.color = ColorUtil.toRGBA(((Integer)this.red.getCurrentState()).intValue(), ((Integer)this.green.getCurrentState()).intValue(), ((Integer)this.blue.getCurrentState()).intValue(), ((Integer)this.alpha.getCurrentState()).intValue());
      this.wireColor = ColorUtil.toRGBA(((Integer)this.w_red.getCurrentState()).intValue(), ((Integer)this.w_green.getCurrentState()).intValue(), ((Integer)this.w_blue.getCurrentState()).intValue(), ((Integer)this.w_alpha.getCurrentState()).intValue());
      this.hiddenColor = ColorUtil.toRGBA(((Integer)this.h_red.getCurrentState()).intValue(), ((Integer)this.h_green.getCurrentState()).intValue(), ((Integer)this.h_blue.getCurrentState()).intValue(), ((Integer)this.h_alpha.getCurrentState()).intValue());
      this.setInstance();
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public static CrystalChanger getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new CrystalChanger();
      }

      return INSTANCE;
   }

   public void onUpdate() {
      Iterator var1 = mc.field_71441_e.field_72996_f.iterator();

      while(var1.hasNext()) {
         Entity crystal = (Entity)var1.next();
         if (crystal instanceof EntityEnderCrystal) {
            if (!this.scaleMap.containsKey(crystal)) {
               this.scaleMap.put((EntityEnderCrystal)crystal, 3.125E-4F);
            } else {
               try {
                  this.scaleMap.put((EntityEnderCrystal)crystal, ((Float)this.scaleMap.get(crystal)).floatValue() + 3.125E-4F);
               } catch (Exception var4) {
                  var4.printStackTrace();
               }
            }

            if ((double)((Float)this.scaleMap.get(crystal)).floatValue() >= 0.0625D * ((Double)this.scale.getCurrentState()).doubleValue()) {
               this.scaleMap.remove(crystal);
            }
         }
      }

   }

   @SubscribeEvent
   public void onPacket(PacketEvent.Receive event) {
      if (event.getPacket() instanceof SPacketDestroyEntities) {
         SPacketDestroyEntities packet = (SPacketDestroyEntities)event.getPacket();
         int[] var3 = packet.func_149098_c();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            int id = var3[var5];

            try {
               Entity entity = mc.field_71441_e.func_73045_a(id);
               if (entity instanceof EntityEnderCrystal) {
                  this.scaleMap.remove(entity);
               }
            } catch (Exception var8) {
               ;
            }
         }
      }

   }

   public void onRenderModel(RenderEntityModelEvent event) {
      if (event.getStage() == 0 && event.entity instanceof EntityEnderCrystal && ((Boolean)this.wireframe.getCurrentState()).booleanValue()) {
         mc.field_71474_y.field_74347_j = false;
         mc.field_71474_y.field_74333_Y = 10000.0F;
         GL11.glPushMatrix();
         GL11.glPushAttrib(1048575);
         GL11.glPolygonMode(1032, 6913);
         GL11.glDisable(3553);
         GL11.glDisable(2896);
         if (((Boolean)this.throughwalls.getCurrentState()).booleanValue()) {
            GL11.glDisable(2929);
         }

         GL11.glEnable(2848);
         GL11.glEnable(3042);
         GlStateManager.func_179112_b(770, 771);
         GlStateManager.func_179131_c((float)((Integer)this.red.getCurrentState()).intValue() / 255.0F, (float)((Integer)this.green.getCurrentState()).intValue() / 255.0F, (float)((Integer)this.blue.getCurrentState()).intValue() / 255.0F, (float)((Integer)this.alpha.getCurrentState()).intValue() / 255.0F);
         GlStateManager.func_187441_d(((Double)this.width.getCurrentState()).floatValue());
         event.modelBase.func_78088_a(event.entity, event.limbSwing, event.limbSwingAmount, event.age, event.headYaw, event.headPitch, event.scale);
         GL11.glPopAttrib();
         GL11.glPopMatrix();
      }
   }
}
