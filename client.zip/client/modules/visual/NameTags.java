package client.modules.visual;

import client.Client;
import client.events.Render3DEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.EntityUtil;
import client.util.PlayerUtil;
import client.util.RenderUtil;
import client.util.RotationUtil;
import java.util.Iterator;
import java.util.Objects;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;

public class NameTags extends Module {
   public static NameTags INSTANCE = new NameTags();
   public Setting healthSetting = this.register(new Setting("Health", true));
   public Setting armor = this.register(new Setting("Armor", true));
   public Setting ping = this.register(new Setting("Ping", true));
   public Setting size = this.register(new Setting("Size", 0.3D, 0.1D, 20.0D));

   public NameTags() {
      super("NameTags", "", Module.Category.VISUAL);
      this.setInstance();
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public static NameTags getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new NameTags();
      }

      return INSTANCE;
   }

   public void onRender3D(Render3DEvent event) {
      if (!fullNullCheck()) {
         Iterator var2 = mc.field_71441_e.field_73010_i.iterator();

         while(true) {
            EntityPlayer player;
            do {
               do {
                  do {
                     do {
                        if (!var2.hasNext()) {
                           return;
                        }

                        player = (EntityPlayer)var2.next();
                     } while(player == null);
                  } while(player.equals(mc.field_71439_g));
               } while(!player.func_70089_S());
            } while(player.func_82150_aj() && !RotationUtil.isInFov((Entity)player));

            double x = RenderUtil.interpolate(player.field_70142_S, player.field_70165_t, event.getPartialTicks()) - mc.func_175598_ae().field_78725_b;
            double y = RenderUtil.interpolate(player.field_70137_T, player.field_70163_u, event.getPartialTicks()) - mc.func_175598_ae().field_78726_c;
            double z = RenderUtil.interpolate(player.field_70136_U, player.field_70161_v, event.getPartialTicks()) - mc.func_175598_ae().field_78723_d;
            this.renderFinalResult(player, x, y, z, event.getPartialTicks());
         }
      }
   }

   private void renderFinalResult(EntityPlayer player, double x, double y, double z, float delta) {
      if (!fullNullCheck()) {
         if (player.func_70005_c_() != "FakePlayer") {
            float health = (float)Math.ceil((double)EntityUtil.getHealth(player));
            String color = health > 18.0F ? "§a" : (health > 16.0F ? "§2" : (health > 12.0F ? "§e" : (health > 8.0F ? "§6" : (health > 5.0F ? "§c" : "§4"))));
            double theY = y + (player.func_70093_af() ? 0.5D : 0.7D);
            Entity camera = mc.func_175606_aa();

            assert camera != null;

            double originalPositionX = camera.field_70165_t;
            double originalPositionY = camera.field_70163_u;
            double originalPositionZ = camera.field_70161_v;
            camera.field_70165_t = RenderUtil.interpolate(camera.field_70169_q, camera.field_70165_t, delta);
            camera.field_70163_u = RenderUtil.interpolate(camera.field_70167_r, camera.field_70163_u, delta);
            camera.field_70161_v = RenderUtil.interpolate(camera.field_70166_s, camera.field_70161_v, delta);
            int width = this.renderer.getStringWidth(player.func_145748_c_().func_150254_d() + " " + (((Boolean)this.ping.getCurrentState()).booleanValue() ? ((NetHandlerPlayClient)Objects.requireNonNull(mc.func_147114_u())).func_175102_a(player.func_110124_au()).func_178853_c() + "ms" : "") + " " + (((Boolean)this.healthSetting.getCurrentState()).booleanValue() ? color + health : "")) / 2;
            double distance = camera.func_70011_f(x + mc.func_175598_ae().field_78730_l, y + mc.func_175598_ae().field_78731_m, z + mc.func_175598_ae().field_78728_n);
            double scale = (0.0018D + ((Double)this.size.getCurrentState()).doubleValue() * distance * 0.2D) / 1000.0D;
            if (distance <= 8.0D) {
               scale = 0.0245D;
            }

            GlStateManager.func_179094_E();
            RenderHelper.func_74519_b();
            GlStateManager.func_179088_q();
            GlStateManager.func_179136_a(1.0F, -1500000.0F);
            GlStateManager.func_179140_f();
            GlStateManager.func_179109_b((float)x, (float)theY + 1.4F, (float)z);
            GlStateManager.func_179114_b(-mc.func_175598_ae().field_78735_i, 0.0F, 1.0F, 0.0F);
            float var10001 = mc.field_71474_y.field_74320_O == 2 ? -1.0F : 1.0F;
            GlStateManager.func_179114_b(mc.func_175598_ae().field_78732_j, var10001, 0.0F, 0.0F);
            GlStateManager.func_179139_a(-scale, -scale, scale);
            GlStateManager.func_179097_i();
            GlStateManager.func_179147_l();
            GlStateManager.func_179118_c();
            RenderUtil.drawRect((float)(-width - 2), (float)(-(mc.field_71466_p.field_78288_b + 1)), (float)width + 2.0F, 1.0F, 1426063360);
            GlStateManager.func_179141_d();
            ItemStack renderMainHand = player.func_184614_ca().func_77946_l();
            if (renderMainHand.func_77962_s() && (renderMainHand.func_77973_b() instanceof ItemTool || renderMainHand.func_77973_b() instanceof ItemArmor)) {
               renderMainHand.field_77994_a = 1;
            }

            GlStateManager.func_179094_E();
            int xOffset = -8;
            Iterator var27 = player.field_71071_by.field_70460_b.iterator();

            while(var27.hasNext()) {
               ItemStack stack = (ItemStack)var27.next();
               if (stack != null) {
                  xOffset -= 8;
               }
            }

            xOffset -= 8;
            ItemStack renderOffhand = player.func_184592_cb().func_77946_l();
            if (renderOffhand.func_77962_s() && (renderOffhand.func_77973_b() instanceof ItemTool || renderOffhand.func_77973_b() instanceof ItemArmor)) {
               renderOffhand.field_77994_a = 1;
            }

            this.renderItems(renderOffhand, xOffset, ((Boolean)this.armor.getCurrentState()).booleanValue());
            xOffset += 16;
            Iterator var32 = player.field_71071_by.field_70460_b.iterator();

            while(true) {
               ItemStack stack;
               do {
                  if (!var32.hasNext()) {
                     this.renderItems(renderMainHand, xOffset, ((Boolean)this.armor.getCurrentState()).booleanValue());
                     GlStateManager.func_179121_F();
                     this.renderer.drawStringWithShadow(player.func_145748_c_().func_150254_d() + " " + (((Boolean)this.ping.getCurrentState()).booleanValue() ? ((NetHandlerPlayClient)Objects.requireNonNull(mc.func_147114_u())).func_175102_a(player.func_110124_au()).func_178853_c() + "ms" : "") + " " + (((Boolean)this.healthSetting.getCurrentState()).booleanValue() ? color + health : ""), (float)(-width), -8.0F, Client.friendManager.isFriend(player) ? -11157267 : -1);
                     camera.field_70165_t = originalPositionX;
                     camera.field_70163_u = originalPositionY;
                     camera.field_70161_v = originalPositionZ;
                     GlStateManager.func_179126_j();
                     GlStateManager.func_179145_e();
                     GlStateManager.func_179084_k();
                     GlStateManager.func_179145_e();
                     GlStateManager.func_179113_r();
                     GlStateManager.func_179136_a(1.0F, 1500000.0F);
                     GlStateManager.func_179121_F();
                     return;
                  }

                  stack = (ItemStack)var32.next();
               } while(stack == null);

               ItemStack armourStack = stack.func_77946_l();
               if (armourStack.func_77962_s() && (armourStack.func_77973_b() instanceof ItemTool || armourStack.func_77973_b() instanceof ItemArmor)) {
                  armourStack.field_77994_a = 1;
               }

               this.renderItems(armourStack, xOffset, ((Boolean)this.armor.getCurrentState()).booleanValue());
               xOffset += 16;
            }
         }
      }
   }

   private void renderItems(ItemStack stack, int x, boolean item) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179086_m(256);
      RenderHelper.func_74519_b();
      mc.func_175599_af().field_77023_b = -150.0F;
      GlStateManager.func_179118_c();
      GlStateManager.func_179126_j();
      GlStateManager.func_179129_p();
      if (item) {
         mc.func_175599_af().func_180450_b(stack, x, -26);
         mc.func_175599_af().func_175030_a(mc.field_71466_p, stack, x, -26);
      }

      mc.func_175599_af().field_77023_b = 0.0F;
      RenderHelper.func_74518_a();
      GlStateManager.func_179089_o();
      GlStateManager.func_179141_d();
      GlStateManager.func_179152_a(0.5F, 0.5F, 0.5F);
      GlStateManager.func_179097_i();
      this.renderArmorPercentage(stack, x);
      GlStateManager.func_179126_j();
      GlStateManager.func_179152_a(1.5F, 1.5F, 1.5F);
      GlStateManager.func_179121_F();
   }

   private void renderArmorPercentage(ItemStack stack, int x) {
      if (PlayerUtil.hasDurability(stack)) {
         String percentColor = PlayerUtil.getRoundedDamage(stack) >= 60 ? "§a" : (PlayerUtil.getRoundedDamage(stack) >= 25 ? "§e" : "§c");
         this.renderer.drawStringWithShadow(percentColor + PlayerUtil.getRoundedDamage(stack) + "%", (float)(x * 2), -30.0F, -1);
      }

   }
}
