package client.modules;

import client.Client;
import client.command.Command;
import client.events.ClientEvent;
import client.events.Render2DEvent;
import client.events.Render3DEvent;
import client.gui.impl.setting.Bind;
import client.gui.impl.setting.Setting;
import client.modules.client.Notify;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.common.MinecraftForge;

public class Module extends Feature {
   private final String description;
   private final Module.Category category;
   public Setting enabled = this.register(new Setting("Enabled", false));
   public Setting bind = this.register(new Setting("Keybind", new Bind(-1)));
   public Setting drawn = this.register(new Setting("Drawn", true));
   public Setting displayName;
   public boolean hasListener;
   public boolean alwaysListening;
   public boolean hidden;
   public float arrayListOffset = 0.0F;
   public float arrayListVOffset = 0.0F;
   public float offset;
   public float vOffset;
   public boolean sliding;

   public Module(String name, String description, Module.Category category) {
      super(name);
      this.displayName = this.register(new Setting("DisplayName", name));
      this.description = description;
      this.category = category;
   }

   public boolean isSliding() {
      return this.sliding;
   }

   public void onEnable() {
   }

   public void onDisable() {
   }

   public void onToggle() {
   }

   public void onLoad() {
   }

   public void onTick() {
   }

   public void onLogin() {
   }

   public void onLogout() {
   }

   public void onUpdate() {
   }

   public void onRender2D(Render2DEvent event) {
   }

   public void onRender3D(Render3DEvent event) {
   }

   public void onUnload() {
   }

   public String getDisplayInfo() {
      return null;
   }

   public boolean isOn() {
      return ((Boolean)this.enabled.getCurrentState()).booleanValue();
   }

   public boolean isOff() {
      return !((Boolean)this.enabled.getCurrentState()).booleanValue();
   }

   public void setEnabled(boolean enabled) {
      if (enabled) {
         this.enable();
      } else {
         this.disable();
      }

   }

   public void enable() {
      MinecraftForge.EVENT_BUS.register(this);
      this.enabled.setValue(Boolean.TRUE);
      this.onToggle();
      this.onEnable();
      if (((Boolean)Notify.getInstance().chatMessages.getCurrentState()).booleanValue() && Notify.getInstance().isOn()) {
         TextComponentString text = new TextComponentString(Client.commandManager.getClientMessage() + " " + ChatFormatting.WHITE + ChatFormatting.BOLD + this.getDisplayName() + ChatFormatting.RESET + ChatFormatting.GREEN + " enabled.");
         mc.field_71456_v.func_146158_b().func_146234_a(text, 1);
      }

   }

   public void disable() {
      this.enabled.setValue(false);
      if (((Boolean)Notify.getInstance().chatMessages.getCurrentState()).booleanValue() && Notify.getInstance().isOn()) {
         TextComponentString text = new TextComponentString(Client.commandManager.getClientMessage() + " " + ChatFormatting.WHITE + ChatFormatting.BOLD + this.getDisplayName() + ChatFormatting.RESET + ChatFormatting.RED + " disabled.");
         mc.field_71456_v.func_146158_b().func_146234_a(text, 1);
      }

      this.onToggle();
      this.onDisable();
      MinecraftForge.EVENT_BUS.unregister(this);
   }

   public void toggle() {
      ClientEvent event = new ClientEvent(!this.isEnabled() ? 1 : 0, this);
      MinecraftForge.EVENT_BUS.post(event);
      if (!event.isCanceled()) {
         this.setEnabled(!this.isEnabled());
      }

   }

   public String getDisplayName() {
      return (String)this.displayName.getCurrentState();
   }

   public void setDisplayName(String name) {
      Module module = Client.moduleManager.getModuleByDisplayName(name);
      Module originalModule = Client.moduleManager.getModuleByName(name);
      if (module == null && originalModule == null) {
         Command.sendMessage(this.getDisplayName() + ", name: " + this.getName() + ", has been renamed to: " + name);
         this.displayName.setValue(name);
      } else {
         Command.sendMessage(ChatFormatting.RED + "A module of this name already exists.");
      }
   }

   public String getDescription() {
      return this.description;
   }

   public Module.Category getCategory() {
      return this.category;
   }

   public String getInfo() {
      return null;
   }

   public Bind getBind() {
      return (Bind)this.bind.getCurrentState();
   }

   public void setBind(int key) {
      this.bind.setValue(new Bind(key));
   }

   public boolean isDrawn() {
      return ((Boolean)this.drawn.getCurrentState()).booleanValue();
   }

   public void setDrawn(boolean drawn) {
      this.drawn.setValue(drawn);
   }

   public boolean listening() {
      return this.hasListener && this.isOn() || this.alwaysListening;
   }

   public String getFullArrayString() {
      return this.getDisplayName() + ChatFormatting.GRAY + (this.getDisplayInfo() != null ? " " + ChatFormatting.WHITE + this.getDisplayInfo() : "");
   }

   public static enum Category {
      COMBAT("Combat"),
      MISC("Miscellaneous"),
      MOVEMENT("Movement"),
      PLAYER("Player"),
      VISUAL("Visual"),
      CORE("Core");

      private final String name;

      private Category(String name) {
         this.name = name;
      }

      public String getName() {
         return this.name;
      }
   }
}
