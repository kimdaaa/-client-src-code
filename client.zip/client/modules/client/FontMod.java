package client.modules.client;

import client.Client;
import client.command.Command;
import client.events.ClientEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.GraphicsEnvironment;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class FontMod extends Module {
   private static FontMod INSTANCE = new FontMod();
   public Setting fontName = this.register(new Setting("FontName: ", "Dialog"));
   public Setting antiAlias = this.register(new Setting("AntiAlias", true));
   public Setting fractionalMetrics = this.register(new Setting("Metrics", true));
   public Setting fontSize = this.register(new Setting("Size", Integer.valueOf(17), Integer.valueOf(12), Integer.valueOf(30)));
   public Setting fontStyle = this.register(new Setting("Style", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(3)));
   private boolean reloadFont = false;

   public FontMod() {
      super("CustomFont", "CustomFont for all of the clients text. Use the font command.", Module.Category.CORE);
      this.setInstance();
   }

   public static FontMod getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new FontMod();
      }

      return INSTANCE;
   }

   public static boolean checkFont(String font, boolean message) {
      String[] var3 = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         String s = var3[var5];
         if (!message && s.equals(font)) {
            return true;
         }

         if (message) {
            Command.sendMessage(s);
         }
      }

      return false;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   @SubscribeEvent
   public void onSettingChange(ClientEvent event) {
      Setting setting;
      if (event.getStage() == 2 && (setting = event.getSetting()) != null && setting.getFeature().equals(this)) {
         if (setting.getName().equals("FontName") && !checkFont(setting.getPlannedValue().toString(), false)) {
            Command.sendMessage(ChatFormatting.RED + "That font doesnt exist.");
            event.setCanceled(true);
            return;
         }

         this.reloadFont = true;
      }

   }

   public void onTick() {
      if (this.reloadFont) {
         Client.textManager.init(false);
         this.reloadFont = false;
      }

   }
}
