package client.modules.client;

import client.DiscordPresence;
import client.modules.Module;

public class RPC extends Module {
   public static RPC INSTANCE;

   public RPC() {
      super("RPC", "Displays client 2.0.0 as your Discord activity.", Module.Category.CORE);
      INSTANCE = this;
   }

   public void onLogin() {
      if (INSTANCE.isOn()) {
         INSTANCE.disable();
         INSTANCE.enable();
      }

   }

   public void onEnable() {
      DiscordPresence.start();
   }

   public void onDisable() {
      DiscordPresence.stop();
   }
}
