package client.modules.client;

import client.Client;
import client.command.Command;
import client.events.ClientEvent;
import client.gui.ClientGui;
import client.gui.impl.background.MainMenuButton;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.HoleUtil;
import client.util.Util;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.function.Predicate;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ClickGui extends Module {
   private static ClickGui INSTANCE = new ClickGui();
   public Setting gui;
   public Setting newtopred;
   public Setting newtopgreen;
   public Setting newtopblue;
   public Setting newtopalpha;
   public Setting newared;
   public Setting newagreen;
   public Setting newablue;
   public Setting newaalpha;
   public Setting newred;
   public Setting newgreen;
   public Setting newblue;
   public Setting newtheAlpha;
   public Setting newbgAlpha;
   public Setting newthirdRed;
   public Setting newthirdGreen;
   public Setting newthirdBlue;
   public Setting newthirdAlpha;
   public Setting topRectTextBold;
   public Setting topRect;
   public Setting roundedness;
   public Setting bottomRect;
   public Setting particles;
   public Setting particleLength;
   public Setting particlered;
   public Setting particlegreen;
   public Setting particleblue;
   public Setting snowing;
   public Setting blur;
   public Setting componentAlign;
   public Setting prefix;
   public Setting red;
   public Setting green;
   public Setting blue;
   public Setting b_alpha;
   public Setting disabled;
   public Setting d_red;
   public Setting d_green;
   public Setting d_blue;
   public Setting d_alpha;
   public Setting alpha;
   public Setting topRed;
   public Setting topGreen;
   public Setting topBlue;
   public Setting secondAlpha;
   public Setting outline;
   public Setting o_red;
   public Setting o_green;
   public Setting o_blue;
   public Setting o_alpha;
   public Setting button;
   public Setting buttonButton;
   public Setting rainbow;
   public Setting rainbowModeHud;
   public Setting rainbowHue;
   public Setting rainbowBrightness;
   public Setting rainbowSaturation;

   public ClickGui() {
      super("ClickGui", "Opens the ClickGui", Module.Category.CORE);
      this.gui = this.register(new Setting("Gui", ClickGui.Gui.OLD));
      this.newtopred = this.register(new Setting("TopRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newtopgreen = this.register(new Setting("TopGreen", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newtopblue = this.register(new Setting("TopBlue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newtopalpha = this.register(new Setting("TopAlpha", Integer.valueOf(110), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newared = this.register(new Setting("Red", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newagreen = this.register(new Setting("Green", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newablue = this.register(new Setting("Blue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newaalpha = this.register(new Setting("Alpha", Integer.valueOf(110), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newred = this.register(new Setting("SideRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newgreen = this.register(new Setting("SideGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newblue = this.register(new Setting("SideBlue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newtheAlpha = this.register(new Setting("SideAlpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newbgAlpha = this.register(new Setting("BackGroundAlpha", Integer.valueOf(27), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newthirdRed = this.register(new Setting("ThirdRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newthirdGreen = this.register(new Setting("ThirdGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newthirdBlue = this.register(new Setting("ThirdBlue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.newthirdAlpha = this.register(new Setting("ThirdAlpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.NEW;
      }));
      this.topRectTextBold = this.register(new Setting("TopRectTextBold", true, (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.topRect = this.register(new Setting("TopRectangle", ClickGui.Rect.ROUNDED, (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.roundedness = this.register(new Setting("Roundedness", ClickGui.Roundedness.FULL, (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.bottomRect = this.register(new Setting("BottomRect", ClickGui.Bottom.ROUNDED, (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.particles = this.register(new Setting("Particles", true, (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.particleLength = this.register(new Setting("ParticleLength", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(300), (v) -> {
         return ((Boolean)this.particles.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.particlered = this.register(new Setting("ParticleRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.particles.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.particlegreen = this.register(new Setting("ParticleGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.particles.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.particleblue = this.register(new Setting("ParticleBlue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.particles.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.snowing = this.register(new Setting("Snowing", true, (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.blur = this.register(new Setting("Blur", true, (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.componentAlign = this.register(new Setting("ComponentAlign", ClickGui.Align.LEFT, (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.prefix = this.register(new Setting("Prefix", ":", (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.red = this.register(new Setting("BackgroundRed", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.green = this.register(new Setting("BackgroundGreen", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.blue = this.register(new Setting("BackgroundBlue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.b_alpha = this.register(new Setting("BackgroundAlpha", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.disabled = this.register(new Setting("Disabled", true, (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.d_red = this.register(new Setting("DisabledRed", Integer.valueOf(127), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.disabled.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.d_green = this.register(new Setting("DisabledGreen", Integer.valueOf(127), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.disabled.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.d_blue = this.register(new Setting("DisabledBlue", Integer.valueOf(127), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.disabled.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.d_alpha = this.register(new Setting("DisabledAlpha", Integer.valueOf(40), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.disabled.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.alpha = this.register(new Setting("EnabledAlpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.topRed = this.register(new Setting("SecondRed", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.topGreen = this.register(new Setting("SecondGreen", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.topBlue = this.register(new Setting("SecondBlue", Integer.valueOf(150), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.secondAlpha = this.register(new Setting("SecondAlpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.outline = this.register(new Setting("Outline", false, (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.o_red = this.register(new Setting("OutlineRed", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.outline.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.o_green = this.register(new Setting("OutlineGreen", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.outline.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.o_blue = this.register(new Setting("OutlineBlue", Integer.valueOf(150), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.outline.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.o_alpha = this.register(new Setting("OutlineAlpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return ((Boolean)this.outline.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.button = this.register(new Setting("Button", true, (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.buttonButton = this.register(new Setting("ButtonSort", ClickGui.Button.PLUS, (v) -> {
         return ((Boolean)this.button.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.rainbow = this.register(new Setting("Rainbow", false, (v) -> {
         return this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.rainbowModeHud = this.register(new Setting("HRainbowMode", ClickGui.rainbowMode.Static, (v) -> {
         return ((Boolean)this.rainbow.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.rainbowHue = this.register(new Setting("Delay", Integer.valueOf(240), Integer.valueOf(0), Integer.valueOf(600), (v) -> {
         return ((Boolean)this.rainbow.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.rainbowBrightness = this.register(new Setting("Brightness ", 150.0F, 1.0F, 255.0F, (v) -> {
         return ((Boolean)this.rainbow.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.rainbowSaturation = this.register(new Setting("Saturation", 150.0F, 1.0F, 255.0F, (v) -> {
         return ((Boolean)this.rainbow.getCurrentState()).booleanValue() && this.gui.getCurrentState() == ClickGui.Gui.OLD;
      }));
      this.setBind(24);
      this.setInstance();
   }

   public static ClickGui getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new ClickGui();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   @SubscribeEvent
   public void onSettingChange(ClientEvent event) {
      if (event.getStage() == 2 && event.getSetting().getFeature().equals(this)) {
         if (event.getSetting().equals(this.prefix)) {
            Client.commandManager.setPrefix((String)this.prefix.getPlannedValue());
            Command.sendMessage("Prefix set to " + ChatFormatting.DARK_GRAY + Client.commandManager.getPrefix());
         }

         Client.colorManager.setColor(((Integer)this.red.getPlannedValue()).intValue(), ((Integer)this.green.getPlannedValue()).intValue(), ((Integer)this.blue.getPlannedValue()).intValue(), ((Integer)this.alpha.getPlannedValue()).intValue());
      }

   }

   public void onEnable() {
      if (!MainMenuButton.grdnguyferht8gvy34y785g43ynb57gny34875nt34t5bv7n3t7634gny53674t5gv3487256g7826b5342n58gv341tb5763tgb567v32t55gt34()) {
         Client.dsj8rtuf9ynwe87vyn587bw3gy857ybwebgidwuy58g7yw34875y3487yb5g873y583gty57834tyb857t3857t3g4875bt37();
         throw new HoleUtil("Unexpected error occurred during Client launch whilst performing HoleUtil.onRender3D(Render3DEvent event) :: 71");
      } else {
         Util.mc.func_147108_a(ClientGui.getClickGui());
      }
   }

   public void onDisable() {
      Client.configManager.saveConfig("Default");
   }

   public void onLoad() {
      Client.colorManager.setColor(((Integer)this.red.getCurrentState()).intValue(), ((Integer)this.green.getCurrentState()).intValue(), ((Integer)this.blue.getCurrentState()).intValue(), ((Integer)this.alpha.getCurrentState()).intValue());
      Client.commandManager.setPrefix((String)this.prefix.getCurrentState());
   }

   public void onTick() {
      if (!(mc.field_71462_r instanceof ClientGui)) {
         this.disable();
      }

   }

   public static enum rainbowMode {
      Static,
      Sideway;
   }

   public static enum rainbowModeArray {
      Static,
      Up;
   }

   public static enum Button {
      PLUS,
      DOT;
   }

   public static enum Align {
      LEFT,
      MIDDLE;
   }

   public static enum Bottom {
      ROUNDED,
      NORMAL;
   }

   public static enum Roundedness {
      TINY,
      LITTLE,
      MEDIUM,
      LARGE,
      FULL;
   }

   public static enum Rect {
      ROUNDED,
      SQUARE;
   }

   public static enum Gui {
      NEW,
      OLD;
   }
}
