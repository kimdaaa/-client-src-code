package client.modules.client;

import client.Client;
import client.events.ClientEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.TextUtil;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Notify extends Module {
   private static Notify INSTANCE = new Notify();
   public Setting chatMessages = this.register(new Setting("ToggleMessages", true));
   public Setting rainbowPrefix = this.register(new Setting("RainbowPrefix", true));
   public Setting command = this.register(new Setting("NotifyString", "Client 2.0.0"));
   public Setting commandBracket = this.register(new Setting("Bracket", "<"));
   public Setting commandBracket2 = this.register(new Setting("Bracket2", ">"));
   public Setting commandColor;
   public Setting bracketColor;

   public Notify() {
      super("Notify", "Notifies things in chat.", Module.Category.CORE);
      this.commandColor = this.register(new Setting("NameColor", TextUtil.Color.WHITE));
      this.bracketColor = this.register(new Setting("BracketColor", TextUtil.Color.WHITE));
      this.setInstance();
   }

   public static Notify getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new Notify();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public void onLoad() {
      Client.commandManager.setClientMessage(this.getCommandMessage());
   }

   @SubscribeEvent
   public void onSettingChange(ClientEvent event) {
      if (event.getStage() == 2 && this.equals(event.getSetting().getFeature())) {
         Client.commandManager.setClientMessage(this.getCommandMessage());
      }

   }

   public String getCommandMessage() {
      return TextUtil.coloredString((String)this.commandBracket.getPlannedValue(), (TextUtil.Color)this.bracketColor.getPlannedValue()) + TextUtil.coloredString((String)this.command.getPlannedValue(), (TextUtil.Color)this.commandColor.getPlannedValue()) + TextUtil.coloredString((String)this.commandBracket2.getPlannedValue(), (TextUtil.Color)this.bracketColor.getPlannedValue());
   }

   public String getRainbowCommandMessage() {
      StringBuilder stringBuilder = new StringBuilder(this.getRawCommandMessage());
      stringBuilder.insert(0, "§+");
      stringBuilder.append("§r");
      return stringBuilder.toString();
   }

   public String getRawCommandMessage() {
      return (String)this.commandBracket.getCurrentState() + (String)this.command.getCurrentState() + (String)this.commandBracket2.getCurrentState();
   }
}
