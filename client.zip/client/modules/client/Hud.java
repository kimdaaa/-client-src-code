package client.modules.client;

import client.Client;
import client.events.Render2DEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.ColorUtil;
import client.util.RenderUtil;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.ToIntFunction;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.GameSettings.Options;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;

public class Hud extends Module {
   private static Hud INSTANCE = new Hud();
   private int color;
   private static final ItemStack totem;
   private static final ItemStack crystals;
   private static final ItemStack gapples;
   private static final ItemStack exp;
   public Setting rainbow = this.register(new Setting("Rainbow", true));
   public Setting sideway = this.register(new Setting("RainbowSideway", true, (v) -> {
      return ((Boolean)this.rainbow.getCurrentState()).booleanValue();
   }));
   public Setting rainbowDelay = this.register(new Setting("Delay", Integer.valueOf(200), Integer.valueOf(0), Integer.valueOf(600), (v) -> {
      return ((Boolean)this.rainbow.getCurrentState()).booleanValue();
   }));
   public Setting rainbowBrightness = this.register(new Setting("Brightness ", 150.0F, 1.0F, 255.0F, (v) -> {
      return ((Boolean)this.rainbow.getCurrentState()).booleanValue();
   }));
   public Setting rainbowSaturation = this.register(new Setting("Saturation", 150.0F, 1.0F, 255.0F, (v) -> {
      return ((Boolean)this.rainbow.getCurrentState()).booleanValue();
   }));
   public Setting fovSetting = this.register(new Setting("Fov", false));
   public Setting fov = this.register(new Setting("FovValue", 150.0F, 0.0F, 180.0F));
   Setting red = this.register(new Setting("Red", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting green = this.register(new Setting("Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting blue = this.register(new Setting("Blue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting alpha = this.register(new Setting("Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting watermark = this.register(new Setting("Watermark", false));
   public Setting watermarkX = this.register(new Setting("WatermarkX", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(900), (v) -> {
      return ((Boolean)this.watermark.getCurrentState()).booleanValue();
   }));
   public Setting watermarkY = this.register(new Setting("WatermarkY", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(530), (v) -> {
      return ((Boolean)this.watermark.getCurrentState()).booleanValue();
   }));
   public Setting welcomer = this.register(new Setting("Welcomer", false));
   public Setting welcomerX = this.register(new Setting("WelcomerX", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(900), (v) -> {
      return ((Boolean)this.welcomer.getCurrentState()).booleanValue() && !((Boolean)this.welcomerAlign.getCurrentState()).booleanValue();
   }));
   public Setting welcomerY = this.register(new Setting("WelcomerY", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(530), (v) -> {
      return ((Boolean)this.welcomer.getCurrentState()).booleanValue() && !((Boolean)this.welcomerAlign.getCurrentState()).booleanValue();
   }));
   public Setting welcomerAlign = this.register(new Setting("WelcomerAlign", false, (v) -> {
      return ((Boolean)this.welcomer.getCurrentState()).booleanValue();
   }));
   public Setting nameHider = this.register(new Setting("NameHider", false));
   public Setting name = this.register(new Setting("Name...", "popbob"));
   private final Setting potionEffects = this.register(new Setting("PotionEffects", false));
   private final Setting bottomAlign = this.register(new Setting("BottomAlign", false, (v) -> {
      return ((Boolean)this.potionEffects.getCurrentState()).booleanValue();
   }));
   private final Setting coords = this.register(new Setting("Coords", false, "Your current coordinates"));
   private final Setting armor = this.register(new Setting("Armor", false, "ArmorHUD"));
   private final Setting percent = this.register(new Setting("Percent", true, (v) -> {
      return ((Boolean)this.armor.getCurrentState()).booleanValue();
   }));
   private final Setting itemInfo = this.register(new Setting("ItemInfo", true));

   public Hud() {
      super("Hud", "Displays strings on your screen", Module.Category.CORE);
      this.setInstance();
   }

   public static Hud getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new Hud();
      }

      return INSTANCE;
   }

   public void onUpdate() {
      if (((Boolean)this.fovSetting.getCurrentState()).booleanValue()) {
         mc.field_71474_y.func_74304_a(Options.FOV, ((Float)this.fov.getCurrentState()).floatValue());
      }

   }

   private void setInstance() {
      INSTANCE = this;
   }

   public void onRender2D(Render2DEvent event) {
      if (!fullNullCheck()) {
         this.color = ColorUtil.toRGBA(((Integer)this.red.getCurrentState()).intValue(), ((Integer)this.green.getCurrentState()).intValue(), ((Integer)this.blue.getCurrentState()).intValue(), ((Integer)this.alpha.getCurrentState()).intValue());
         String string = "Client 2.0.0-b12";
         String welcome = ((Boolean)this.nameHider.getCurrentState()).booleanValue() ? "Weclome to Client 2.0.0-b12 " + (String)this.name.getCurrentState() : "Weclome to Client 2.0.0-b12 " + mc.field_71439_g.func_70005_c_();
         char[] var7;
         int posY;
         int posZ;
         char c;
         if (((Boolean)this.watermark.getCurrentState()).booleanValue()) {
            if (((Boolean)this.rainbow.getCurrentState()).booleanValue()) {
               if (!((Boolean)this.sideway.getCurrentState()).booleanValue()) {
                  this.renderer.drawString(string, (float)((Integer)this.watermarkX.getCurrentState()).intValue(), (float)((Integer)this.watermarkY.getCurrentState()).intValue(), ColorUtil.rainbowHud(((Integer)this.rainbowDelay.getCurrentState()).intValue()).getRGB(), true);
               } else {
                  int[] arrayOfInt = new int[]{1};
                  char[] stringToCharArray = string.toCharArray();
                  float f = 0.0F;
                  var7 = stringToCharArray;
                  posY = stringToCharArray.length;

                  for(posZ = 0; posZ < posY; ++posZ) {
                     c = var7[posZ];
                     this.renderer.drawString(String.valueOf(c), (float)((Integer)this.watermarkX.getCurrentState()).intValue() + f, (float)((Integer)this.watermarkY.getCurrentState()).intValue(), ColorUtil.rainbowHud(arrayOfInt[0] * ((Integer)this.rainbowDelay.getCurrentState()).intValue()).getRGB(), true);
                     f += (float)this.renderer.getStringWidth(String.valueOf(c));
                     ++arrayOfInt[0];
                  }
               }
            } else {
               this.renderer.drawString(string, (float)((Integer)this.watermarkX.getCurrentState()).intValue(), (float)((Integer)this.watermarkY.getCurrentState()).intValue(), this.color, true);
            }
         }

         if (((Boolean)this.welcomer.getCurrentState()).booleanValue()) {
            float f = 0.0F;
            if (((Boolean)this.rainbow.getCurrentState()).booleanValue()) {
               if (!((Boolean)this.sideway.getCurrentState()).booleanValue()) {
                  this.renderer.drawString(welcome, ((Boolean)this.welcomerAlign.getCurrentState()).booleanValue() ? 400.0F + f : (float)((Integer)this.welcomerX.getCurrentState()).intValue() + f, (float)((Integer)this.welcomerY.getCurrentState()).intValue(), ColorUtil.rainbowHud(((Integer)this.rainbowDelay.getCurrentState()).intValue()).getRGB(), true);
               } else {
                  int[] arrayOfInt = new int[]{1};
                  char[] stringToCharArray = welcome.toCharArray();
                  var7 = stringToCharArray;
                  posY = stringToCharArray.length;

                  for(posZ = 0; posZ < posY; ++posZ) {
                     c = var7[posZ];
                     this.renderer.drawString(String.valueOf(c), ((Boolean)this.welcomerAlign.getCurrentState()).booleanValue() ? 400.0F + f : (float)((Integer)this.welcomerX.getCurrentState()).intValue() + f, (float)((Integer)this.welcomerY.getCurrentState()).intValue(), ColorUtil.rainbowHud(arrayOfInt[0] * ((Integer)this.rainbowDelay.getCurrentState()).intValue()).getRGB(), true);
                     f += (float)this.renderer.getStringWidth(String.valueOf(c));
                     ++arrayOfInt[0];
                  }
               }
            } else {
               this.renderer.drawString(welcome, ((Boolean)this.welcomerAlign.getCurrentState()).booleanValue() ? 400.0F + f : (float)((Integer)this.welcomerX.getCurrentState()).intValue() + f, (float)((Integer)this.welcomerY.getCurrentState()).intValue(), this.color, true);
            }
         }

         int i;
         int height;
         if (((Boolean)this.potionEffects.getCurrentState()).booleanValue()) {
            if (fullNullCheck()) {
               return;
            }

            int width = this.renderer.scaledWidth;
            i = this.renderer.scaledHeight;
            this.color = ColorUtil.toRGBA(((Integer)this.red.getCurrentState()).intValue(), ((Integer)this.green.getCurrentState()).intValue(), ((Integer)this.blue.getCurrentState()).intValue(), ((Integer)this.alpha.getCurrentState()).intValue());
            height = mc.field_71462_r instanceof GuiChat && ((Boolean)this.bottomAlign.getCurrentState()).booleanValue() ? 13 : (((Boolean)this.bottomAlign.getCurrentState()).booleanValue() ? -3 : 0);
            List effects = new ArrayList(Minecraft.func_71410_x().field_71439_g.func_70651_bq());
            Iterator var32;
            PotionEffect potionEffect;
            String str;
            if (((Boolean)this.bottomAlign.getCurrentState()).booleanValue()) {
               var32 = effects.iterator();

               while(var32.hasNext()) {
                  potionEffect = (PotionEffect)var32.next();
                  str = Client.potionManager.getColoredPotionString(potionEffect);
                  height += 10;
                  this.renderer.drawString(str, (float)(width - this.renderer.getStringWidth(str) - 2), (float)(i - 2 - height), potionEffect.func_188419_a().func_76401_j(), true);
               }
            } else {
               var32 = effects.iterator();

               while(var32.hasNext()) {
                  potionEffect = (PotionEffect)var32.next();
                  str = Client.potionManager.getColoredPotionString(potionEffect);
                  this.renderer.drawString(str, (float)(width - this.renderer.getStringWidth(str) - 2), (float)(2 + height++ * 10), potionEffect.func_188419_a().func_76401_j(), true);
               }
            }
         }

         boolean inHell = mc.field_71441_e.func_180494_b(mc.field_71439_g.func_180425_c()).func_185359_l().equals("Hell");
         i = mc.field_71462_r instanceof GuiChat ? 14 : 0;
         height = this.renderer.scaledHeight;
         int posX = (int)mc.field_71439_g.field_70165_t;
         posY = (int)mc.field_71439_g.field_70163_u;
         posZ = (int)mc.field_71439_g.field_70161_v;
         float nether = !inHell ? 0.125F : 8.0F;
         int hposX = (int)(mc.field_71439_g.field_70165_t * (double)nether);
         int hposZ = (int)(mc.field_71439_g.field_70161_v * (double)nether);
         String coordinates = ChatFormatting.WHITE + "XYZ " + ChatFormatting.RESET + (inHell ? posX + ", " + posY + ", " + posZ + ChatFormatting.WHITE + " [" + ChatFormatting.RESET + hposX + ", " + hposZ + ChatFormatting.WHITE + "]" + ChatFormatting.RESET : posX + ", " + posY + ", " + posZ + ChatFormatting.WHITE + " [" + ChatFormatting.RESET + hposX + ", " + hposZ + ChatFormatting.WHITE + "]");
         String coords = ((Boolean)this.coords.getCurrentState()).booleanValue() ? coordinates : "";
         i += 10;
         if (((Boolean)ClickGui.getInstance().rainbow.getCurrentState()).booleanValue()) {
            String rainbowCoords = ((Boolean)this.coords.getCurrentState()).booleanValue() ? "XYZ " + (inHell ? posX + ", " + posY + ", " + posZ + " [" + hposX + ", " + hposZ + "]" : posX + ", " + posY + ", " + posZ + " [" + hposX + ", " + hposZ + "]") : "";
            if (ClickGui.getInstance().rainbowModeHud.getCurrentState() == ClickGui.rainbowMode.Static) {
               this.renderer.drawString(rainbowCoords, 2.0F, (float)(height - i), ColorUtil.rainbow(((Integer)ClickGui.getInstance().rainbowHue.getCurrentState()).intValue()).getRGB(), true);
            } else {
               int[] counter3 = new int[]{1};
               char[] stringToCharArray2 = rainbowCoords.toCharArray();
               float u = 0.0F;
               char[] var19 = stringToCharArray2;
               int var20 = stringToCharArray2.length;

               for(int var21 = 0; var21 < var20; ++var21) {
                  char c = var19[var21];
                  this.renderer.drawString(String.valueOf(c), 2.0F + u, (float)(height - i), ColorUtil.rainbow(counter3[0] * ((Integer)ClickGui.getInstance().rainbowHue.getCurrentState()).intValue()).getRGB(), true);
                  u += (float)this.renderer.getStringWidth(String.valueOf(c));
                  ++counter3[0];
               }
            }
         } else {
            this.renderer.drawString(coords, 2.0F, (float)(height - i), this.color, true);
         }

         if (((Boolean)this.armor.getCurrentState()).booleanValue()) {
            this.renderArmorHUD(((Boolean)this.percent.getCurrentState()).booleanValue());
         }

         if (((Boolean)this.itemInfo.getCurrentState()).booleanValue()) {
            this.renderTotemHUD();
            this.renderCrystalHud();
            this.renderExpHud();
            this.renderGapsHud();
         }

      }
   }

   public void renderArmorHUD(boolean percent) {
      int width = this.renderer.scaledWidth;
      int height = this.renderer.scaledHeight;
      GlStateManager.func_179098_w();
      int i = width / 2;
      int iteration = 0;
      int y = height - 55 - (mc.field_71439_g.func_70090_H() && mc.field_71442_b.func_78763_f() ? 10 : 0);
      Iterator var7 = mc.field_71439_g.field_71071_by.field_70460_b.iterator();

      while(var7.hasNext()) {
         ItemStack is = (ItemStack)var7.next();
         ++iteration;
         if (!is.func_190926_b()) {
            int x = i - 90 + (9 - iteration) * 20 + 2;
            GlStateManager.func_179126_j();
            RenderUtil.itemRender.field_77023_b = 200.0F;
            RenderUtil.itemRender.func_180450_b(is, x, y);
            RenderUtil.itemRender.func_180453_a(mc.field_71466_p, is, x, y, "");
            RenderUtil.itemRender.field_77023_b = 0.0F;
            GlStateManager.func_179098_w();
            GlStateManager.func_179140_f();
            GlStateManager.func_179097_i();
            String s = is.func_190916_E() > 1 ? is.func_190916_E() + "" : "";
            this.renderer.drawStringWithShadow(s, (float)(x + 19 - 2 - this.renderer.getStringWidth(s)), (float)(y + 9), 16777215);
            if (percent) {
               float green = ((float)is.func_77958_k() - (float)is.func_77952_i()) / (float)is.func_77958_k();
               float red = 1.0F - green;
               int dmg = 100 - (int)(red * 100.0F);
               this.renderer.drawStringWithShadow(dmg + "", (float)(x + 8 - this.renderer.getStringWidth(dmg + "") / 2), (float)(y - 11), ColorUtil.toRGBA((int)(red * 255.0F), (int)(green * 255.0F), 0));
            }
         }
      }

      GlStateManager.func_179126_j();
      GlStateManager.func_179140_f();
   }

   public void renderTotemHUD() {
      int totems = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter((itemStack) -> {
         return itemStack.func_77973_b() == Items.field_190929_cY;
      }).mapToInt(ItemStack::func_190916_E).sum();
      if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY) {
         totems += mc.field_71439_g.func_184592_cb().func_190916_E();
      }

      if (totems > 0) {
         GlStateManager.func_179098_w();
         GlStateManager.func_179126_j();
         RenderUtil.itemRender.field_77023_b = 200.0F;
         RenderUtil.itemRender.func_180450_b(totem, 0, 20);
         RenderUtil.itemRender.func_180453_a(mc.field_71466_p, totem, 0, 20, "");
         RenderUtil.itemRender.field_77023_b = 0.0F;
         GlStateManager.func_179098_w();
         GlStateManager.func_179140_f();
         GlStateManager.func_179097_i();
         this.renderer.drawStringWithShadow(totems + "", 10.0F, 30.0F, 16777215);
         GlStateManager.func_179126_j();
         GlStateManager.func_179140_f();
      }

   }

   public void renderCrystalHud() {
      int totems = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter((itemStack) -> {
         return itemStack.func_77973_b() == Items.field_185158_cP;
      }).mapToInt(ItemStack::func_190916_E).sum();
      if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
         totems += mc.field_71439_g.func_184592_cb().func_190916_E();
      }

      if (totems > 0) {
         GlStateManager.func_179098_w();
         GlStateManager.func_179126_j();
         RenderUtil.itemRender.field_77023_b = 200.0F;
         RenderUtil.itemRender.func_180450_b(crystals, 0, 37);
         RenderUtil.itemRender.func_180453_a(mc.field_71466_p, crystals, 0, 37, "");
         RenderUtil.itemRender.field_77023_b = 0.0F;
         GlStateManager.func_179098_w();
         GlStateManager.func_179140_f();
         GlStateManager.func_179097_i();
         this.renderer.drawStringWithShadow(totems + "", 10.0F, 47.0F, 16777215);
         GlStateManager.func_179126_j();
         GlStateManager.func_179140_f();
      }

   }

   public void renderExpHud() {
      int totems = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter((itemStack) -> {
         return itemStack.func_77973_b() == Items.field_151062_by;
      }).mapToInt(ItemStack::func_190916_E).sum();
      if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151062_by) {
         totems += mc.field_71439_g.func_184592_cb().func_190916_E();
      }

      if (totems > 0) {
         GlStateManager.func_179098_w();
         GlStateManager.func_179126_j();
         RenderUtil.itemRender.field_77023_b = 200.0F;
         RenderUtil.itemRender.func_180450_b(exp, 0, 54);
         RenderUtil.itemRender.func_180453_a(mc.field_71466_p, exp, 10, 54, "");
         RenderUtil.itemRender.field_77023_b = 0.0F;
         GlStateManager.func_179098_w();
         GlStateManager.func_179140_f();
         GlStateManager.func_179097_i();
         this.renderer.drawStringWithShadow(totems + "", 10.0F, 64.0F, 16777215);
         GlStateManager.func_179126_j();
         GlStateManager.func_179140_f();
      }

   }

   public void renderGapsHud() {
      int totems = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter((itemStack) -> {
         return itemStack.func_77973_b() == Items.field_151153_ao;
      }).mapToInt(ItemStack::func_190916_E).sum();
      if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao) {
         totems += mc.field_71439_g.func_184592_cb().func_190916_E();
      }

      if (totems > 0) {
         GlStateManager.func_179098_w();
         GlStateManager.func_179126_j();
         RenderUtil.itemRender.field_77023_b = 200.0F;
         RenderUtil.itemRender.func_180450_b(gapples, 0, 69);
         RenderUtil.itemRender.func_180453_a(mc.field_71466_p, gapples, 0, 69, "");
         RenderUtil.itemRender.field_77023_b = 0.0F;
         GlStateManager.func_179098_w();
         GlStateManager.func_179140_f();
         GlStateManager.func_179097_i();
         this.renderer.drawStringWithShadow(totems + "", 10.0F, 79.0F, 16777215);
         GlStateManager.func_179126_j();
         GlStateManager.func_179140_f();
      }

   }

   static {
      totem = new ItemStack(Items.field_190929_cY);
      crystals = new ItemStack(Items.field_185158_cP);
      gapples = new ItemStack(Items.field_151153_ao);
      exp = new ItemStack(Items.field_151062_by);
   }
}
