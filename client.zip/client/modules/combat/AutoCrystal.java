package client.modules.combat;

import client.events.PacketEvent;
import client.events.Render3DEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.modules.client.ClickGui;
import client.util.BlockUtil;
import client.util.ColorUtil;
import client.util.EntityUtil;
import client.util.PlayerUtil;
import client.util.RenderUtil;
import client.util.Timer;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketUseEntity.Action;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.network.play.server.SPacketSpawnObject;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AutoCrystal extends Module {
   public Setting setting;
   public Setting speedFactor;
   public Setting doBreak;
   public Setting doPlace;
   public Setting targetRange;
   public Setting cancel;
   public Setting breakRange;
   public Setting breakWallRange;
   public Setting breakDelay;
   public Setting instant;
   public Setting priority;
   public Setting placeRange;
   public Setting placeRangeWall;
   public Setting armorPercent;
   public Setting facePlaceHP;
   public Setting minDamage;
   public Setting maxSelfDamage;
   public Setting swing;
   public Setting announceOnly;
   public Setting text;
   public Setting box;
   public Setting renderMode;
   public Setting accel;
   public Setting moveSpeed;
   public Setting fade;
   public Setting red;
   public Setting green;
   public Setting blue;
   public Setting alpha;
   public Setting rainbow;
   public Setting outline;
   public Setting cRed;
   public Setting cGreen;
   public Setting cBlue;
   public Setting cAlpha;
   public Setting lineWidth;
   public Setting cRainbow;
   public Set placeSet;
   public Timer clearTimer;
   public Timer breakTimer;
   public int predictedId;
   public BlockPos renderPos;
   public BlockPos pos2;
   public EntityPlayer target;
   public boolean offhand;
   public boolean mainhand;
   public static AutoCrystal INSTANCE = new AutoCrystal();
   private final ArrayList renderMap = new ArrayList();
   private final ArrayList currentTargets = new ArrayList();
   private BlockPos lastRenderPos;
   private AxisAlignedBB renderBB;
   private float timePassed;

   public AutoCrystal() {
      super("AutoCrystal", "Automatically places/breaks crystals to deal damage to opponents.", Module.Category.COMBAT);
      this.setting = this.register(new Setting("Setting", AutoCrystal.Settings.AUTOCRYSTAL));
      this.speedFactor = this.register(new Setting("SpeedFactor", AutoCrystal.SpeedFactor.UPDATE));
      this.doPlace = this.register(new Setting("Place", true, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.doBreak = this.register(new Setting("Break", true, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.breakRange = this.register(new Setting("BreakRange", 5.0F, 1.0F, 6.0F, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.placeRange = this.register(new Setting("PlaceRange", 5.0F, 1.0F, 6.0F, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.targetRange = this.register(new Setting("TargetRange", 9.0F, 1.0F, 15.0F, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.breakWallRange = this.register(new Setting("BreakRangeWall", 5.0F, 1.0F, 6.0F, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.placeRangeWall = this.register(new Setting("PlaceRangeWall", 5.0F, 1.0F, 6.0F, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.breakDelay = this.register(new Setting("BreakDelay", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(200), (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.instant = this.register(new Setting("Predict", false, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.priority = this.register(new Setting("PrioritizeSelf", AutoCrystal.Priority.SELF, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.cancel = this.register(new Setting("Cancel", true, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.armorPercent = this.register(new Setting("Armor%", Integer.valueOf(10), Integer.valueOf(0), Integer.valueOf(100), (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.facePlaceHP = this.register(new Setting("FaceplaceHP", 8.0F, 0.0F, 36.0F, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.minDamage = this.register(new Setting("MinDamage", 4.0F, 1.0F, 36.0F, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.maxSelfDamage = this.register(new Setting("MaxSelfDmg", 8.0F, 1.0F, 36.0F, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.swing = this.register(new Setting("Swing", false, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.announceOnly = this.register(new Setting("AnnounceOnly", false, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.AUTOCRYSTAL;
      }));
      this.renderMode = this.register(new Setting("RenderMode", AutoCrystal.RenderMode.NORMAL, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER;
      }));
      this.box = this.register(new Setting("Box", true, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER;
      }));
      this.fade = this.register(new Setting("Fade", AutoCrystal.Enum.FAST, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER && this.renderMode.getCurrentState() == AutoCrystal.RenderMode.FADE;
      }));
      this.accel = this.register(new Setting("Deceleration", 0.8F, 0.0F, 1.0F, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER && this.renderMode.getCurrentState() == AutoCrystal.RenderMode.GLIDE;
      }));
      this.moveSpeed = this.register(new Setting("Speed", 900.0F, 0.0F, 1500.0F, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER && this.renderMode.getCurrentState() == AutoCrystal.RenderMode.GLIDE;
      }));
      this.red = this.register(new Setting("BoxRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER;
      }));
      this.green = this.register(new Setting("BoxGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER;
      }));
      this.blue = this.register(new Setting("BoxBlue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER;
      }));
      this.alpha = this.register(new Setting("BoxAlpha", Integer.valueOf(120), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER;
      }));
      this.rainbow = this.register(new Setting("BoxRainbow", true, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER;
      }));
      this.outline = this.register(new Setting("Outline", true, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER;
      }));
      this.cRed = this.register(new Setting("OutlineRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER;
      }));
      this.cGreen = this.register(new Setting("OutlineGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER;
      }));
      this.cBlue = this.register(new Setting("OutlineBlue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER;
      }));
      this.cAlpha = this.register(new Setting("OutlineAlpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER;
      }));
      this.lineWidth = this.register(new Setting("OutlineWidth", Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(5), (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER;
      }));
      this.cRainbow = this.register(new Setting("OutlineRainbow", true, (v) -> {
         return this.setting.getCurrentState() == AutoCrystal.Settings.RENDER;
      }));
      this.placeSet = new HashSet();
      this.clearTimer = new Timer();
      this.breakTimer = new Timer();
      this.predictedId = -1;
      this.renderPos = null;
      this.pos2 = null;
      this.target = null;
      INSTANCE = this;
   }

   public static AutoCrystal getInstance() {
      return INSTANCE;
   }

   private boolean update() {
      if (fullNullCheck()) {
         return false;
      } else {
         if (this.clearTimer.hasReached(500L)) {
            this.placeSet.clear();
            this.predictedId = -1;
            this.renderPos = null;
            this.clearTimer.reset();
         }

         this.offhand = mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP;
         this.mainhand = mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP;
         return true;
      }
   }

   public void onToggle() {
      this.placeSet.clear();
      this.predictedId = -1;
      this.renderPos = null;
   }

   public void onUpdate() {
      if (this.update()) {
         this.target = EntityUtil.getTarget(((Float)this.targetRange.getCurrentState()).floatValue());
         if (this.target != null) {
            if (this.speedFactor.getCurrentState() == AutoCrystal.SpeedFactor.UPDATE && !((Boolean)this.announceOnly.getCurrentState()).booleanValue()) {
               if (((Boolean)this.doPlace.getCurrentState()).booleanValue()) {
                  this.doPlace();
               }

               if (((Boolean)this.doBreak.getCurrentState()).booleanValue()) {
                  this.doBreak();
               }
            }

         }
      }
   }

   public void onDisable() {
      this.lastRenderPos = null;
   }

   public void onTick() {
      if (this.speedFactor.getCurrentState() == AutoCrystal.SpeedFactor.TICK && !((Boolean)this.announceOnly.getCurrentState()).booleanValue()) {
         if (((Boolean)this.doPlace.getCurrentState()).booleanValue()) {
            this.doPlace();
         }

         if (((Boolean)this.doBreak.getCurrentState()).booleanValue()) {
            this.doBreak();
         }
      }

   }

   private void doPlace() {
      BlockPos placePos = null;
      float maxDamage = 0.5F;
      List sphere = BlockUtil.getSphere((double)((Float)this.placeRange.getCurrentState()).floatValue(), true);
      int size = sphere.size();

      for(int i = 0; i < size; ++i) {
         BlockPos pos = (BlockPos)sphere.get(i);
         float self = this.calculate((BlockPos)pos, mc.field_71439_g);
         if (BlockUtil.canPlaceCrystal(pos, true)) {
            float damage;
            if (this.priority.getCurrentState() == AutoCrystal.Priority.SELF) {
               if (EntityUtil.getHealth(mc.field_71439_g) > self + 0.5F && ((Float)this.maxSelfDamage.getCurrentState()).floatValue() > self && (damage = this.calculate(pos, this.target)) > maxDamage && damage > self && (damage > ((Float)this.minDamage.getCurrentState()).floatValue() || (((Float)this.facePlaceHP.getCurrentState()).floatValue() > EntityUtil.getHealth(this.target) || PlayerUtil.isArmorLow(this.target, ((Integer)this.armorPercent.getCurrentState()).intValue())) && damage > 2.0F)) {
                  maxDamage = damage;
                  placePos = pos;
                  this.pos2 = pos;
                  this.currentTargets.clear();
                  this.currentTargets.add(pos);
               }
            } else if (this.priority.getCurrentState() == AutoCrystal.Priority.ENEMY && EntityUtil.getHealth(mc.field_71439_g) > self + 0.5F && ((Float)this.maxSelfDamage.getCurrentState()).floatValue() > self && (damage = this.calculate(pos, this.target)) > maxDamage && (damage > ((Float)this.minDamage.getCurrentState()).floatValue() || (((Float)this.facePlaceHP.getCurrentState()).floatValue() > EntityUtil.getHealth(this.target) || PlayerUtil.isArmorLow(this.target, ((Integer)this.armorPercent.getCurrentState()).intValue())) && damage > 2.0F)) {
               maxDamage = damage;
               placePos = pos;
               this.pos2 = pos;
               this.currentTargets.clear();
               this.currentTargets.add(pos);
            }
         }
      }

      if (!this.offhand && !this.mainhand) {
         this.renderPos = null;
      } else {
         if (placePos != null) {
            this.clearMap(placePos);
            ((NetHandlerPlayClient)Objects.requireNonNull(mc.func_147114_u())).func_147297_a(new CPacketPlayerTryUseItemOnBlock(placePos, EnumFacing.UP, this.offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.5F, 0.5F, 0.5F));
            this.renderMap.add(new AutoCrystal.RenderPos(placePos, 0.0D));
            this.placeSet.add(placePos);
            this.renderPos = placePos;
         } else {
            this.renderPos = null;
         }

      }
   }

   private void doBreak() {
      Entity entity = null;
      int size = mc.field_71441_e.field_72996_f.size();

      for(int i = 0; i < size; ++i) {
         Entity crystal = (Entity)mc.field_71441_e.field_72996_f.get(i);
         if (crystal.getClass() == EntityEnderCrystal.class && this.isValid(crystal) && crystal.func_145782_y() != this.predictedId) {
            float self = this.calculate((Entity)crystal, mc.field_71439_g);
            float damage;
            if (this.priority.getCurrentState() == AutoCrystal.Priority.SELF) {
               if (EntityUtil.getHealth(mc.field_71439_g) > self + 0.5F && (damage = this.calculate(crystal, this.target)) > self && damage > self) {
                  if (damage <= ((Float)this.minDamage.getCurrentState()).floatValue() && (((Float)this.facePlaceHP.getCurrentState()).floatValue() <= EntityUtil.getHealth(this.target) && !PlayerUtil.isArmorLow(this.target, ((Integer)this.armorPercent.getCurrentState()).intValue()) || damage <= 2.0F)) {
                     continue;
                  }

                  entity = crystal;
               }
            } else if (this.priority.getCurrentState() == AutoCrystal.Priority.ENEMY && EntityUtil.getHealth(mc.field_71439_g) > self + 0.5F && (damage = this.calculate(crystal, this.target)) > self) {
               if (damage <= ((Float)this.minDamage.getCurrentState()).floatValue() && (((Float)this.facePlaceHP.getCurrentState()).floatValue() <= EntityUtil.getHealth(this.target) && !PlayerUtil.isArmorLow(this.target, ((Integer)this.armorPercent.getCurrentState()).intValue()) || damage <= 2.0F)) {
                  continue;
               }

               entity = crystal;
            }
         }

         if (entity != null && this.breakTimer.passedMs((long)((Integer)this.breakDelay.getCurrentState()).intValue())) {
            BlockPos renderPos = entity.func_180425_c().func_177977_b();
            this.clearMap(renderPos);
            ((NetHandlerPlayClient)Objects.requireNonNull(mc.func_147114_u())).func_147297_a(new CPacketUseEntity(entity));
            this.renderMap.add(new AutoCrystal.RenderPos(renderPos, 0.0D));
            if (((Boolean)this.swing.getCurrentState()).booleanValue()) {
               mc.field_71439_g.func_184609_a(this.offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
            }

            this.breakTimer.reset();
         }
      }

   }

   private boolean isValid(Entity crystal) {
      return (double)(mc.field_71439_g.func_70685_l(crystal) ? ((Float)this.breakRange.getCurrentState()).floatValue() * ((Float)this.breakRange.getCurrentState()).floatValue() : ((Float)this.breakWallRange.getCurrentState()).floatValue() * ((Float)this.breakWallRange.getCurrentState()).floatValue()) > mc.field_71439_g.func_70068_e(crystal);
   }

   private float calculate(Entity crystal, EntityPlayer target) {
      return EntityUtil.calculate(crystal.field_70165_t, crystal.field_70163_u, crystal.field_70161_v, target);
   }

   private float calculate(BlockPos pos, EntityPlayer entity) {
      return EntityUtil.calculate((double)((float)pos.func_177958_n() + 0.5F), (double)(pos.func_177956_o() + 1), (double)((float)pos.func_177952_p() + 0.5F), entity);
   }

   public void instantHit(int id) {
      CPacketUseEntity hitPacket = new CPacketUseEntity();
      hitPacket.field_149567_a = id;
      hitPacket.field_149566_b = Action.ATTACK;
      ((NetHandlerPlayClient)Objects.requireNonNull(mc.func_147114_u())).func_147297_a(hitPacket);
      this.predictedId = id;
      if (((Boolean)this.swing.getCurrentState()).booleanValue()) {
         mc.field_71439_g.func_184609_a(this.offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
      }

   }

   @SubscribeEvent
   public void onPacketReceive(PacketEvent.Receive event) {
      Packet packet;
      if (event.getPacket() instanceof SPacketSpawnObject && ((Boolean)this.instant.getCurrentState()).booleanValue()) {
         packet = event.getPacket();
         BlockPos pos = new BlockPos(((SPacketSpawnObject)packet).func_186880_c(), ((SPacketSpawnObject)packet).func_186882_d(), ((SPacketSpawnObject)packet).func_186881_e());
         if (((SPacketSpawnObject)packet).func_148993_l() == 51 && this.placeSet.contains(pos.func_177977_b())) {
            if (mc.field_71439_g.func_70011_f((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p()) > (double)((Float)this.breakRange.getCurrentState()).floatValue()) {
               return;
            }

            this.instantHit(((SPacketSpawnObject)packet).func_149001_c());
         }
      }

      if (event.getPacket() instanceof SPacketSoundEffect && ((Boolean)this.cancel.getCurrentState()).booleanValue() && ((SPacketSoundEffect)((SPacketSoundEffect)(packet = event.getPacket()))).func_186977_b() == SoundCategory.BLOCKS && ((SPacketSoundEffect)packet).func_186978_a() == SoundEvents.field_187539_bB) {
         ArrayList entities = new ArrayList(mc.field_71441_e.field_72996_f);
         int size = entities.size();

         for(int i = 0; i < size; ++i) {
            Entity entity = (Entity)entities.get(i);
            if (entity instanceof EntityEnderCrystal && entity.func_70092_e(((SPacketSoundEffect)packet).func_149207_d(), ((SPacketSoundEffect)packet).func_149211_e(), ((SPacketSoundEffect)packet).func_149210_f()) < 36.0D) {
               entity.func_70106_y();
            }
         }
      }

   }

   public void onRender3D(Render3DEvent event) {
      if (!this.renderMap.isEmpty()) {
         List toRemove = new ArrayList();
         Iterator it = this.renderMap.iterator();

         while(it.hasNext()) {
            AutoCrystal.RenderPos renderPos = (AutoCrystal.RenderPos)it.next();
            Color color = new Color(((Integer)this.red.getCurrentState()).intValue(), ((Integer)this.green.getCurrentState()).intValue(), ((Integer)this.blue.getCurrentState()).intValue(), (int)Math.max((double)((Integer)this.alpha.getCurrentState()).intValue() - renderPos.alpha, 0.0D));
            Color color2 = new Color(((Integer)this.cRed.getCurrentState()).intValue(), ((Integer)this.cGreen.getCurrentState()).intValue(), ((Integer)this.cBlue.getCurrentState()).intValue(), (int)Math.max((double)((Integer)this.cAlpha.getCurrentState()).intValue() - renderPos.alpha, 0.0D));
            if (this.renderMode.getCurrentState() == AutoCrystal.RenderMode.NORMAL || this.renderMode.getCurrentState() == AutoCrystal.RenderMode.FADE) {
               RenderUtil.drawBoxESP(renderPos.pos, ((Boolean)this.rainbow.getCurrentState()).booleanValue() ? ColorUtil.rainbow(((Integer)ClickGui.getInstance().rainbowHue.getCurrentState()).intValue()) : color, ((Boolean)this.outline.getCurrentState()).booleanValue(), ((Boolean)this.cRainbow.getCurrentState()).booleanValue() ? ColorUtil.rainbow(((Integer)ClickGui.getInstance().rainbowHue.getCurrentState()).intValue()) : color2, (float)((Integer)this.lineWidth.getCurrentState()).intValue(), ((Boolean)this.outline.getCurrentState()).booleanValue(), ((Boolean)this.box.getCurrentState()).booleanValue(), (int)Math.max((double)((Integer)this.cAlpha.getCurrentState()).intValue() - renderPos.alpha, 0.0D), true);
            }

            if (renderPos.alpha > (double)Math.max(((Integer)this.alpha.getCurrentState()).intValue(), ((Boolean)this.rainbow.getCurrentState()).booleanValue() ? ColorUtil.rainbow(((Integer)ClickGui.getInstance().rainbowHue.getCurrentState()).intValue()).getRGB() : ColorUtil.toRGBA(((Integer)this.red.getCurrentState()).intValue(), ((Integer)this.green.getCurrentState()).intValue(), ((Integer)this.blue.getCurrentState()).intValue()))) {
               toRemove.add(renderPos);
            }

            renderPos.alpha += this.fade.getCurrentState() == AutoCrystal.Enum.FAST ? 1.5D : (this.fade.getCurrentState() == AutoCrystal.Enum.SLOW ? 0.5D : 1.0D);
            if (this.currentTargets.contains(renderPos.pos)) {
               renderPos.alpha = 0.0D;
            } else if (this.renderMode.getCurrentState() != AutoCrystal.RenderMode.FADE) {
               toRemove.add(renderPos);
            }
         }

         this.renderMap.removeAll(toRemove);
         if (this.renderMode.getCurrentState() == AutoCrystal.RenderMode.GLIDE && this.renderPos != null) {
            Color color2 = new Color(((Integer)this.cRed.getCurrentState()).intValue(), ((Integer)this.cGreen.getCurrentState()).intValue(), ((Integer)this.cBlue.getCurrentState()).intValue(), ((Integer)this.cAlpha.getCurrentState()).intValue());
            Color color = new Color(((Integer)this.red.getCurrentState()).intValue(), ((Integer)this.green.getCurrentState()).intValue(), ((Integer)this.blue.getCurrentState()).intValue(), ((Integer)this.alpha.getCurrentState()).intValue());
            if (this.lastRenderPos == null || mc.field_71439_g.func_70011_f(this.renderBB.field_72340_a, this.renderBB.field_72338_b, this.renderBB.field_72339_c) > (double)((Float)this.placeRange.getCurrentState()).floatValue()) {
               this.lastRenderPos = this.renderPos;
               this.renderBB = new AxisAlignedBB(this.renderPos);
               this.timePassed = 0.0F;
            }

            if (!this.lastRenderPos.equals(this.renderPos)) {
               this.lastRenderPos = this.renderPos;
               this.timePassed = 0.0F;
            }

            double xDiff = (double)this.renderPos.func_177958_n() - this.renderBB.field_72340_a;
            double yDiff = (double)this.renderPos.func_177956_o() - this.renderBB.field_72338_b;
            double zDiff = (double)this.renderPos.func_177952_p() - this.renderBB.field_72339_c;
            float multiplier = this.timePassed / ((Float)this.moveSpeed.getCurrentState()).floatValue() * ((Float)this.accel.getCurrentState()).floatValue();
            if (multiplier > 1.0F) {
               multiplier = 1.0F;
            }

            this.renderBB = this.renderBB.func_72317_d(xDiff * (double)multiplier, yDiff * (double)multiplier, zDiff * (double)multiplier);
            RenderUtil.drawPerryESP(this.renderBB, color, color2, (float)((Integer)this.lineWidth.getCurrentState()).intValue(), ((Boolean)this.outline.getCurrentState()).booleanValue(), ((Boolean)this.box.getCurrentState()).booleanValue(), 1.0F, 1.0F, 1.0F);
            if (this.renderBB.equals(new AxisAlignedBB(this.renderPos))) {
               this.timePassed = 0.0F;
            } else {
               this.timePassed += 50.0F;
            }
         }

      }
   }

   private void clearMap(BlockPos checkBlock) {
      List toRemove = new ArrayList();
      if (checkBlock != null && !this.renderMap.isEmpty()) {
         Iterator var3 = this.renderMap.iterator();

         while(var3.hasNext()) {
            AutoCrystal.RenderPos pos = (AutoCrystal.RenderPos)var3.next();
            if (pos.pos.func_177958_n() == checkBlock.func_177958_n() && pos.pos.func_177956_o() == checkBlock.func_177956_o() && pos.pos.func_177952_p() == checkBlock.func_177952_p()) {
               toRemove.add(pos);
            }
         }

         this.renderMap.removeAll(toRemove);
      }
   }

   class RenderPos {
      Double damage;
      double alpha;
      BlockPos pos;

      public RenderPos(BlockPos pos, Double damage) {
         this.pos = pos;
         this.damage = damage;
      }
   }

   public static enum Enum {
      FAST,
      MEDIUM,
      SLOW;
   }

   public static enum RenderMode {
      NORMAL,
      FADE,
      GLIDE;
   }

   public static enum Priority {
      SELF,
      ENEMY;
   }

   public static enum SpeedFactor {
      TICK,
      UPDATE;
   }

   public static enum Settings {
      AUTOCRYSTAL,
      RENDER;
   }
}
