package client.modules.combat;

import client.Client;
import client.command.Command;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.BlockUtil;
import client.util.EntityUtil;
import client.util.InventoryUtil;
import client.util.PlayerUtil;
import client.util.Timer;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.block.BlockObsidian;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class Surround extends Module {
   private final Setting delay = this.register(new Setting("Delay", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(250)));
   private final Setting blocksPerTick = this.register(new Setting("BlocksPerTick", Integer.valueOf(20), Integer.valueOf(1), Integer.valueOf(20)));
   private final Setting noGhost = this.register(new Setting("PacketPlace", false));
   private final boolean floor;
   private final Setting centerp = this.register(new Setting("Center", false));
   private final Setting centerPlayer;
   private final Setting rotate;
   private final Timer timer;
   private final Timer retryTimer;
   private final Set extendingBlocks;
   private final Map retries;
   private int isSafe;
   public static boolean isPlacing = false;
   private BlockPos startPos;
   private boolean didPlace;
   private int lastHotbarSlot;
   private boolean isSneaking;
   private int placements;
   private int extenders;
   private int obbySlot;
   private boolean offHand;
   Vec3d center;

   public Surround() {
      super("Surround", "Surrounds you with Obsidian", Module.Category.COMBAT);
      this.centerPlayer = this.register(new Setting("Center", Surround.Center.SMOOTH, (v) -> {
         return ((Boolean)this.centerp.getCurrentState()).booleanValue();
      }));
      this.rotate = this.register(new Setting("Rotate", true));
      this.floor = true;
      this.timer = new Timer();
      this.retryTimer = new Timer();
      this.extendingBlocks = new HashSet();
      this.retries = new HashMap();
      this.didPlace = false;
      this.placements = 0;
      this.extenders = 1;
      this.obbySlot = -1;
      this.offHand = false;
      this.center = Vec3d.field_186680_a;
   }

   public void onEnable() {
      if (fullNullCheck()) {
         this.disable();
      }

      this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
      this.startPos = EntityUtil.getRoundedBlockPos(mc.field_71439_g);
      this.center = PlayerUtil.getCenter(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);
      if (((Boolean)this.centerp.getCurrentState()).booleanValue()) {
         switch((Surround.Center)this.centerPlayer.getCurrentState()) {
         case INSTANT:
            mc.field_71439_g.field_70159_w = 0.0D;
            mc.field_71439_g.field_70179_y = 0.0D;
            mc.field_71439_g.field_71174_a.func_147297_a(new Position(this.center.field_72450_a, this.center.field_72448_b, this.center.field_72449_c, true));
            mc.field_71439_g.func_70107_b(this.center.field_72450_a, this.center.field_72448_b, this.center.field_72449_c);
            break;
         case SMOOTH:
            mc.field_71439_g.field_70159_w = (this.center.field_72450_a - mc.field_71439_g.field_70165_t) / 2.0D;
            mc.field_71439_g.field_70179_y = (this.center.field_72449_c - mc.field_71439_g.field_70161_v) / 2.0D;
         }
      }

      this.retries.clear();
      this.retryTimer.reset();
   }

   public void onTick() {
      this.doSurround();
   }

   public void onUpdate() {
      if (!this.check()) {
         boolean onWeb = mc.field_71441_e.func_180495_p(new BlockPos(mc.field_71439_g.func_174791_d())).func_177230_c() == Blocks.field_150321_G;
         if (!BlockUtil.isSafe(mc.field_71439_g, onWeb ? 1 : 0, this.floor)) {
            this.placeBlocks(mc.field_71439_g.func_174791_d(), BlockUtil.getUnsafeBlockArray(mc.field_71439_g.func_174791_d(), onWeb ? 1 : 0, true), false, false, false);
         }

         boolean inEChest = mc.field_71441_e.func_180495_p(new BlockPos(mc.field_71439_g.func_174791_d())).func_177230_c() == Blocks.field_150477_bB;
         if (mc.field_71439_g.field_70163_u - (double)((int)mc.field_71439_g.field_70163_u) < 0.7D) {
            inEChest = false;
         }

         this.processExtendingBlocks();
         if (this.didPlace) {
            this.timer.reset();
         }

      }
   }

   public void onDisable() {
      if (!nullCheck()) {
         isPlacing = false;
         this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
      }
   }

   public String getDisplayInfo() {
      switch(this.isSafe) {
      case 0:
         return ChatFormatting.RED + "Unsafe";
      case 1:
         return ChatFormatting.YELLOW + "Safe";
      default:
         return ChatFormatting.GREEN + "Safe";
      }
   }

   private void doSurround() {
      if (!this.check()) {
         if (!EntityUtil.isSafe(mc.field_71439_g, 0, true)) {
            this.isSafe = 0;
            this.placeBlocks(mc.field_71439_g.func_174791_d(), EntityUtil.getUnsafeBlockArray(mc.field_71439_g, 0, true), true, false, false);
         } else if (!EntityUtil.isSafe(mc.field_71439_g, -1, false)) {
            this.isSafe = 1;
            this.placeBlocks(mc.field_71439_g.func_174791_d(), EntityUtil.getUnsafeBlockArray(mc.field_71439_g, -1, false), false, false, true);
         } else {
            this.isSafe = 3;
            if (mc.field_71441_e.func_180495_p(EntityUtil.getRoundedBlockPos(mc.field_71439_g)).func_177230_c().equals(Blocks.field_150477_bB) && mc.field_71439_g.field_70163_u != (double)EntityUtil.getRoundedBlockPos(mc.field_71439_g).func_177956_o()) {
               this.placeBlocks(mc.field_71439_g.func_174791_d(), EntityUtil.getUnsafeBlockArray(mc.field_71439_g, 1, false), false, false, true);
            } else {
               this.isSafe = 4;
            }
         }

         this.processExtendingBlocks();
         if (this.didPlace) {
            this.timer.reset();
         }

      }
   }

   private boolean check() {
      if (nullCheck()) {
         return true;
      } else {
         int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
         int eChestSot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
         if (obbySlot == -1 && eChestSot == -1) {
            this.toggle();
         }

         this.offHand = InventoryUtil.isBlock(mc.field_71439_g.func_184592_cb().func_77973_b(), BlockObsidian.class);
         isPlacing = false;
         this.didPlace = false;
         this.extenders = 1;
         this.placements = 0;
         this.obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
         int echestSlot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
         if (this.isOff()) {
            return true;
         } else {
            if (this.retryTimer.passedMs(2500L)) {
               this.retries.clear();
               this.retryTimer.reset();
            }

            if (this.obbySlot == -1 && !this.offHand && echestSlot == -1) {
               Command.sendMessage("No obsidian, toggling");
               this.disable();
               return true;
            } else {
               this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
               if (mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && mc.field_71439_g.field_71071_by.field_70461_c != this.obbySlot && mc.field_71439_g.field_71071_by.field_70461_c != echestSlot) {
                  this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
               }

               if (!this.startPos.equals(EntityUtil.getRoundedBlockPos(mc.field_71439_g))) {
                  this.disable();
                  return true;
               } else {
                  return !this.timer.passedMs((long)((Integer)this.delay.getCurrentState()).intValue());
               }
            }
         }
      }
   }

   private void processExtendingBlocks() {
      if (this.extendingBlocks.size() == 2 && this.extenders < 1) {
         Vec3d[] array = new Vec3d[2];
         int i = 0;

         for(Iterator iterator = this.extendingBlocks.iterator(); iterator.hasNext(); ++i) {
            Vec3d vec3d = array[i] = (Vec3d)iterator.next();
         }

         int placementsBefore = this.placements;
         if (this.areClose(array) != null) {
            this.placeBlocks(this.areClose(array), BlockUtil.getUnsafeBlockArray(this.areClose(array), 0, this.floor), false, false, true);
         }

         if (placementsBefore < this.placements) {
            this.extendingBlocks.clear();
         }
      } else if (this.extendingBlocks.size() > 2 || this.extenders >= 1) {
         this.extendingBlocks.clear();
      }

   }

   private Vec3d areClose(Vec3d[] vec3ds) {
      int matches = 0;
      Vec3d[] var3 = vec3ds;
      int var4 = vec3ds.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         Vec3d vec3d = var3[var5];
         Vec3d[] var7 = BlockUtil.getUnsafeBlockArray(mc.field_71439_g.func_174791_d(), 0, this.floor);
         int var8 = var7.length;

         for(int var9 = 0; var9 < var8; ++var9) {
            Vec3d pos = var7[var9];
            if (vec3d.equals(pos)) {
               ++matches;
            }
         }
      }

      if (matches == 2) {
         return mc.field_71439_g.func_174791_d().func_178787_e(vec3ds[0].func_178787_e(vec3ds[1]));
      } else {
         return null;
      }
   }

   private boolean placeBlocks(Vec3d pos, Vec3d[] vec3ds, boolean hasHelpingBlocks, boolean isHelping, boolean isExtending) {
      boolean gotHelp = true;
      Vec3d[] var7 = vec3ds;
      int var8 = vec3ds.length;

      for(int var9 = 0; var9 < var8; ++var9) {
         Vec3d vec3d = var7[var9];
         gotHelp = true;
         BlockPos position = (new BlockPos(pos)).func_177963_a(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c);
         switch(BlockUtil.isPositionPlaceable(position, false)) {
         case 1:
            if (this.retries.get(position) != null && ((Integer)this.retries.get(position)).intValue() >= 4) {
               if (Client.speedManager.getSpeedKpH() == 0.0D && !isExtending && this.extenders < 1) {
                  this.placeBlocks(mc.field_71439_g.func_174791_d().func_178787_e(vec3d), EntityUtil.getUnsafeBlockArrayFromVec3d(mc.field_71439_g.func_174791_d().func_178787_e(vec3d), 0, true), hasHelpingBlocks, false, true);
                  this.extendingBlocks.add(vec3d);
                  ++this.extenders;
               }
               break;
            }

            this.placeBlock(position);
            this.retries.put(position, this.retries.get(position) == null ? 1 : ((Integer)this.retries.get(position)).intValue() + 1);
            this.retryTimer.reset();
            break;
         case 2:
            if (!hasHelpingBlocks) {
               break;
            }

            gotHelp = this.placeBlocks(pos, BlockUtil.getHelpingBlocks(vec3d), false, true, true);
         case 3:
            if (gotHelp) {
               this.placeBlock(position);
            }

            if (isHelping) {
               return true;
            }
         }
      }

      return false;
   }

   private void placeBlock(BlockPos pos) {
      if (this.placements < ((Integer)this.blocksPerTick.getCurrentState()).intValue()) {
         int originalSlot = mc.field_71439_g.field_71071_by.field_70461_c;
         int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
         int eChestSot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
         if (obbySlot == -1 && eChestSot == -1) {
            this.toggle();
         }

         isPlacing = true;
         mc.field_71439_g.field_71071_by.field_70461_c = obbySlot == -1 ? eChestSot : obbySlot;
         mc.field_71442_b.func_78765_e();
         this.isSneaking = BlockUtil.placeBlock(pos, this.offHand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, ((Boolean)this.rotate.getCurrentState()).booleanValue(), ((Boolean)this.noGhost.getCurrentState()).booleanValue(), this.isSneaking);
         mc.field_71439_g.field_71071_by.field_70461_c = originalSlot;
         mc.field_71442_b.func_78765_e();
         this.didPlace = true;
         ++this.placements;
      }

   }

   private List position() {
      return this.floor ? Arrays.asList((new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(0, -1, 0), (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(1, 0, 0), (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(-1, 0, 0), (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(0, 0, -1), (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(0, 0, 1)) : Arrays.asList((new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(1, 0, 0), (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(-1, 0, 0), (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(0, 0, -1), (new BlockPos(mc.field_71439_g.func_174791_d())).func_177982_a(0, 0, 1));
   }

   public static enum Center {
      INSTANT,
      SMOOTH;
   }
}
