package client.modules.combat;

import client.Client;
import client.command.Command;
import client.events.Render3DEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.modules.client.ClickGui;
import client.util.BlockUtil;
import client.util.ColorUtil;
import client.util.EntityUtil;
import client.util.InventoryUtil;
import client.util.MathUtil;
import client.util.RenderUtil;
import client.util.Timer;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;
import net.minecraft.block.BlockWeb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class AutoWeb extends Module {
   public static boolean isPlacing = false;
   private final Setting delay = this.register(new Setting("Delay", Integer.valueOf(10), Integer.valueOf(0), Integer.valueOf(250)));
   private final Setting blocksPerPlace = this.register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
   private final Setting packet = this.register(new Setting("PacketPlace", false));
   private final Setting offhand = this.register(new Setting("Offhand", false));
   private final Setting disable = this.register(new Setting("AutoDisable", false));
   private final Setting rotate = this.register(new Setting("Rotate", false));
   private final Setting raytrace = this.register(new Setting("Raytrace", false));
   private final Setting lowerbody = this.register(new Setting("Feet", true));
   private final Setting upperBody = this.register(new Setting("Face", false));
   private final Setting render = this.register(new Setting("Render", false));
   public Setting box = this.register(new Setting("Box", false, (v) -> {
      return ((Boolean)this.render.getCurrentState()).booleanValue();
   }));
   private final Setting red = this.register(new Setting("Red", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.box.getCurrentState()).booleanValue();
   }));
   private final Setting green = this.register(new Setting("Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.box.getCurrentState()).booleanValue();
   }));
   private final Setting blue = this.register(new Setting("Blue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.box.getCurrentState()).booleanValue();
   }));
   public Setting Rainbow = this.register(new Setting("Rainbow", false, (v) -> {
      return ((Boolean)this.box.getCurrentState()).booleanValue();
   }));
   private final Setting alpha = this.register(new Setting("Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.box.getCurrentState()).booleanValue();
   }));
   private final Setting boxAlpha = this.register(new Setting("BoxAlpha", Integer.valueOf(125), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.box.getCurrentState()).booleanValue();
   }));
   public Setting outline = this.register(new Setting("Outline", false, (v) -> {
      return ((Boolean)this.render.getCurrentState()).booleanValue();
   }));
   private final Setting cRed = this.register(new Setting("OL-Red", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.outline.getCurrentState()).booleanValue();
   }));
   private final Setting cGreen = this.register(new Setting("OL-Green", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.outline.getCurrentState()).booleanValue();
   }));
   private final Setting cBlue = this.register(new Setting("OL-Blue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.outline.getCurrentState()).booleanValue();
   }));
   public Setting cRainbow = this.register(new Setting("OL-Rainbow", false, (v) -> {
      return ((Boolean)this.outline.getCurrentState()).booleanValue();
   }));
   private final Setting cAlpha = this.register(new Setting("OL-Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), (v) -> {
      return ((Boolean)this.outline.getCurrentState()).booleanValue();
   }));
   private final Setting lineWidth = this.register(new Setting("LineWidth", 1.0F, 0.1F, 5.0F, (v) -> {
      return ((Boolean)this.outline.getCurrentState()).booleanValue();
   }));
   private final Timer timer = new Timer();
   public EntityPlayer target;
   private boolean didPlace = false;
   private boolean switchedItem;
   private boolean isSneaking;
   private int lastHotbarSlot;
   private int placements = 0;
   private BlockPos startPos = null;
   private BlockPos renderPos = null;

   public AutoWeb() {
      super("AutoWeb", "Traps other players in webs", Module.Category.COMBAT);
   }

   public void onEnable() {
      if (!fullNullCheck()) {
         this.startPos = EntityUtil.getRoundedBlockPos(mc.field_71439_g);
         this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
      }
   }

   public void onTick() {
      this.doTrap();
   }

   public String getDisplayInfo() {
      return this.target != null ? this.target.func_70005_c_() : null;
   }

   public void onDisable() {
      isPlacing = false;
      this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
      this.switchItem(true);
   }

   private void doTrap() {
      if (!this.check()) {
         this.doWebTrap();
         if (this.didPlace) {
            this.timer.reset();
         }

      }
   }

   private void doWebTrap() {
      List placeTargets = this.getPlacements();
      this.placeList(placeTargets);
   }

   private List getPlacements() {
      ArrayList list = new ArrayList();
      Vec3d baseVec = this.target.func_174791_d();
      if (((Boolean)this.lowerbody.getCurrentState()).booleanValue()) {
         list.add(baseVec);
      }

      if (((Boolean)this.upperBody.getCurrentState()).booleanValue()) {
         list.add(baseVec.func_72441_c(0.0D, 1.0D, 0.0D));
      }

      return list;
   }

   private void placeList(List list) {
      list.sort((vec3d, vec3d2) -> {
         return Double.compare(mc.field_71439_g.func_70092_e(vec3d2.field_72450_a, vec3d2.field_72448_b, vec3d2.field_72449_c), mc.field_71439_g.func_70092_e(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c));
      });
      list.sort(Comparator.comparingDouble((vec3d) -> {
         return vec3d.field_72448_b;
      }));
      Iterator var2 = list.iterator();

      while(true) {
         BlockPos position;
         int placeability;
         do {
            if (!var2.hasNext()) {
               return;
            }

            Vec3d vec3d3 = (Vec3d)var2.next();
            position = new BlockPos(vec3d3);
            this.renderPos = position;
            placeability = BlockUtil.isPositionPlaceable(position, ((Boolean)this.raytrace.getCurrentState()).booleanValue());
         } while(placeability != 3 && placeability != 1);

         this.placeBlock(position);
      }
   }

   private boolean check() {
      isPlacing = false;
      this.didPlace = false;
      this.placements = 0;
      int obbySlot = InventoryUtil.findHotbarBlock(BlockWeb.class);
      if (this.isOff()) {
         return true;
      } else if (((Boolean)this.disable.getCurrentState()).booleanValue() && !this.startPos.equals(EntityUtil.getRoundedBlockPos(mc.field_71439_g))) {
         this.disable();
         return true;
      } else if (obbySlot == -1) {
         Command.sendMessage("" + this.getDisplayName() + " " + ChatFormatting.RED + "No Webs in hotbar disabling...");
         this.toggle();
         return true;
      } else {
         if (mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && mc.field_71439_g.field_71071_by.field_70461_c != obbySlot) {
            this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
         }

         this.switchItem(true);
         this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
         this.target = this.getTarget(10.0D);
         return this.target == null || !this.timer.passedMs((long)((Integer)this.delay.getCurrentState()).intValue());
      }
   }

   private EntityPlayer getTarget(double range) {
      EntityPlayer target = null;
      double distance = Math.pow(range, 2.0D) + 1.0D;
      Iterator var6 = mc.field_71441_e.field_73010_i.iterator();

      while(var6.hasNext()) {
         EntityPlayer player = (EntityPlayer)var6.next();
         if (!EntityUtil.isntValid(player, range) && !player.field_70134_J && Client.speedManager.getPlayerSpeed(player) <= 30.0D) {
            if (target == null) {
               target = player;
               distance = mc.field_71439_g.func_70068_e(player);
            } else if (mc.field_71439_g.func_70068_e(player) < distance) {
               target = player;
               distance = mc.field_71439_g.func_70068_e(player);
            }
         }
      }

      return target;
   }

   private void placeBlock(BlockPos pos) {
      if (this.placements < ((Integer)this.blocksPerPlace.getCurrentState()).intValue() && mc.field_71439_g.func_174818_b(pos) <= MathUtil.square(6.0D) && this.switchItem(false)) {
         isPlacing = true;
         int originalSlot = mc.field_71439_g.field_71071_by.field_70461_c;
         int webSlot = InventoryUtil.findHotbarBlock(BlockWeb.class);
         if (webSlot == -1) {
            this.toggle();
         }

         mc.field_71439_g.field_71071_by.field_70461_c = webSlot == -1 ? webSlot : webSlot;
         mc.field_71442_b.func_78765_e();
         this.isSneaking = BlockUtil.placeBlock(pos, ((Boolean)this.offhand.getCurrentState()).booleanValue() ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, ((Boolean)this.rotate.getCurrentState()).booleanValue(), ((Boolean)this.packet.getCurrentState()).booleanValue(), this.isSneaking);
         mc.field_71439_g.field_71071_by.field_70461_c = originalSlot;
         mc.field_71442_b.func_78765_e();
         this.didPlace = true;
         ++this.placements;
      }

   }

   private boolean switchItem(boolean back) {
      boolean[] value = InventoryUtil.switchItem(back, this.lastHotbarSlot, this.switchedItem, InventoryUtil.Switch.SILENT, BlockWeb.class);
      this.switchedItem = value[0];
      return value[1];
   }

   public void onLogout() {
      this.disable();
   }

   public void onRender3D(Render3DEvent event) {
      if (((Boolean)this.render.getCurrentState()).booleanValue()) {
         RenderUtil.drawBoxESP(this.renderPos, ((Boolean)this.Rainbow.getCurrentState()).booleanValue() ? ColorUtil.rainbow(((Integer)ClickGui.getInstance().rainbowHue.getCurrentState()).intValue()) : new Color(((Integer)this.red.getCurrentState()).intValue(), ((Integer)this.green.getCurrentState()).intValue(), ((Integer)this.blue.getCurrentState()).intValue(), ((Integer)this.alpha.getCurrentState()).intValue()), ((Boolean)this.outline.getCurrentState()).booleanValue(), ((Boolean)this.cRainbow.getCurrentState()).booleanValue() ? ColorUtil.rainbow(((Integer)ClickGui.getInstance().rainbowHue.getCurrentState()).intValue()) : new Color(((Integer)this.cRed.getCurrentState()).intValue(), ((Integer)this.cGreen.getCurrentState()).intValue(), ((Integer)this.cBlue.getCurrentState()).intValue(), ((Integer)this.cAlpha.getCurrentState()).intValue()), ((Float)this.lineWidth.getCurrentState()).floatValue(), ((Boolean)this.outline.getCurrentState()).booleanValue(), ((Boolean)this.box.getCurrentState()).booleanValue(), ((Integer)this.boxAlpha.getCurrentState()).intValue(), true);
      }

   }
}
