package client.modules.combat;

import client.events.PacketEvent;
import client.gui.impl.setting.Setting;
import client.manager.ModuleManager;
import client.modules.Module;
import client.util.BlockUtil;
import client.util.EntityUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.block.BlockRedstoneTorch;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemEndCrystal;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class PistonAura extends Module {
   public Setting rotate = this.register(new Setting("Rotate", false));
   public Setting blockPlayer = this.register(new Setting("TrapPlayer", true));
   public Setting antiWeakness = this.register(new Setting("AntiWeakness", false));
   public Setting enemyRange = this.register(new Setting("Range", 5.9D, 0.0D, 6.0D));
   public Setting blocksPerTick = this.register(new Setting("BlocksPerTick", Integer.valueOf(4), Integer.valueOf(0), Integer.valueOf(20)));
   public Setting startDelay = this.register(new Setting("StartDelay", Integer.valueOf(4), Integer.valueOf(0), Integer.valueOf(20)));
   public Setting trapDelay = this.register(new Setting("TrapDelay", Integer.valueOf(4), Integer.valueOf(0), Integer.valueOf(20)));
   public Setting pistonDelay = this.register(new Setting("PistonDelay", Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(20)));
   public Setting crystalDelay = this.register(new Setting("CrystalDelay", Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(20)));
   public Setting hitDelay = this.register(new Setting("HitDelay", Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(20)));
   public Setting breakMode;
   private boolean isSneaking;
   private boolean firstRun;
   private boolean noMaterials;
   private boolean hasMoved;
   private boolean isHole;
   private boolean enoughSpace;
   private int oldSlot;
   private int[] slot_mat;
   private int[] delayTable;
   private int stage;
   private int delayTimeTicks;
   private PistonAura.structureTemp toPlace;
   int[][] disp_surblock;
   Double[][] sur_block;
   private int stuck;
   boolean broken;
   boolean brokenCrystalBug;
   boolean brokenRedstoneTorch;
   public static ModuleManager moduleManager;
   private static PistonAura instance;
   private EntityPlayer closestTarget;
   double[] coordsD;
   private static boolean isSpoofingAngles;
   private static double yaw;
   private static double pitch;

   public PistonAura() {
      super("PistonAura", "Use Pistons and Crystals to pvp.", Module.Category.COMBAT);
      this.breakMode = this.register(new Setting("Break Mode", PistonAura.BreakModes.swing));
      this.isSneaking = false;
      this.firstRun = false;
      this.noMaterials = false;
      this.hasMoved = false;
      this.isHole = true;
      this.enoughSpace = true;
      this.oldSlot = -1;
      this.disp_surblock = new int[][]{{1, 0, 0}, {-1, 0, 0}, {0, 0, 1}, {0, 0, -1}};
      this.stuck = 0;
      instance = this;
   }

   public static PistonAura getInstance() {
      if (instance == null) {
         instance = new PistonAura();
      }

      return instance;
   }

   public void onEnable() {
      this.coordsD = new double[3];
      this.delayTable = new int[]{((Integer)this.startDelay.getCurrentState()).intValue(), ((Integer)this.trapDelay.getCurrentState()).intValue(), ((Integer)this.pistonDelay.getCurrentState()).intValue(), ((Integer)this.crystalDelay.getCurrentState()).intValue(), ((Integer)this.hitDelay.getCurrentState()).intValue()};
      this.toPlace = new PistonAura.structureTemp(0.0D, 0, (List)null);
      boolean b = true;
      this.firstRun = true;
      this.isHole = true;
      boolean b2 = false;
      this.brokenRedstoneTorch = false;
      this.brokenCrystalBug = false;
      this.broken = false;
      this.hasMoved = false;
      this.slot_mat = new int[]{-1, -1, -1, -1, -1};
      int stage = false;
      this.stuck = 0;
      this.delayTimeTicks = 0;
      this.stage = 0;
      if (mc.field_71439_g == null) {
         this.disable();
      } else {
         this.oldSlot = mc.field_71439_g.field_71071_by.field_70461_c;
      }
   }

   public void onDisable() {
      if (mc.field_71439_g != null) {
         if (this.isSneaking) {
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.STOP_SNEAKING));
            this.isSneaking = false;
         }

         if (this.oldSlot != mc.field_71439_g.field_71071_by.field_70461_c && this.oldSlot != -1) {
            mc.field_71439_g.field_71071_by.field_70461_c = this.oldSlot;
            this.oldSlot = -1;
         }

         this.noMaterials = false;
         this.firstRun = true;
      }
   }

   public void onUpdate() {
      if (mc.field_71439_g == null) {
         this.disable();
      } else {
         if (this.firstRun) {
            this.closestTarget = EntityUtil.getTargetDouble(((Double)this.enemyRange.getCurrentState()).doubleValue());
            if (this.closestTarget == null) {
               return;
            }

            this.firstRun = false;
            if (this.getMaterialsSlot()) {
               if (this.is_in_hole()) {
                  this.enoughSpace = this.createStructure();
               } else {
                  this.isHole = false;
               }
            } else {
               this.noMaterials = true;
            }
         } else {
            if (this.delayTable == null) {
               return;
            }

            if (this.delayTimeTicks < this.delayTable[this.stage]) {
               ++this.delayTimeTicks;
               return;
            }

            this.delayTimeTicks = 0;
         }

         if (!this.noMaterials && this.isHole && this.enoughSpace && !this.hasMoved) {
            if (this.trapPlayer()) {
               BlockPos targetPos;
               if (this.stage == 1) {
                  targetPos = this.compactBlockPos(this.stage);
                  this.placeBlock(targetPos, this.stage, (double)this.toPlace.offsetX, (double)this.toPlace.offsetZ);
                  ++this.stage;
               } else if (this.stage == 2) {
                  targetPos = this.compactBlockPos(this.stage - 1);
                  if (!(this.get_block((double)targetPos.func_177958_n(), (double)targetPos.func_177956_o(), (double)targetPos.func_177952_p()) instanceof BlockPistonBase)) {
                     --this.stage;
                  } else {
                     BlockPos targetPos2 = this.compactBlockPos(this.stage);
                     if (this.placeBlock(targetPos2, this.stage, (double)this.toPlace.offsetX, (double)this.toPlace.offsetZ)) {
                        ++this.stage;
                     }
                  }
               } else if (this.stage == 3) {
                  Iterator var3 = mc.field_71441_e.field_72996_f.iterator();

                  while(var3.hasNext()) {
                     Entity t = (Entity)var3.next();
                     if (t instanceof EntityEnderCrystal && (int)t.field_70165_t == (int)((Vec3d)this.toPlace.to_place.get(this.toPlace.supportBlock + 1)).field_72450_a && (int)t.field_70161_v == (int)((Vec3d)this.toPlace.to_place.get(this.toPlace.supportBlock + 1)).field_72449_c) {
                        --this.stage;
                        break;
                     }
                  }

                  if (this.stage == 3) {
                     targetPos = this.compactBlockPos(this.stage);
                     this.placeBlock(targetPos, this.stage, (double)this.toPlace.offsetX, (double)this.toPlace.offsetZ);
                     ++this.stage;
                  }
               } else if (this.stage == 4) {
                  this.destroyLeCrystal();
               }
            }

         } else {
            this.disable();
         }
      }
   }

   public void destroyLeCrystal() {
      Entity crystal = null;
      Iterator var2 = mc.field_71441_e.field_72996_f.iterator();

      while(true) {
         Entity t;
         do {
            do {
               if (!var2.hasNext()) {
                  boolean found;
                  if (this.broken && crystal == null) {
                     found = false;
                     this.stuck = 0;
                     this.stage = 0;
                     this.broken = false;
                  }

                  if (crystal != null) {
                     this.breakCrystalPiston(crystal);
                     this.broken = true;
                  } else if (++this.stuck >= 35) {
                     found = false;
                     Iterator var10 = mc.field_71441_e.field_72996_f.iterator();

                     while(var10.hasNext()) {
                        Entity t2 = (Entity)var10.next();
                        if (t2 instanceof EntityEnderCrystal && (int)t2.field_70165_t == (int)((Vec3d)this.toPlace.to_place.get(this.toPlace.supportBlock + 1)).field_72450_a && (int)t2.field_70161_v == (int)((Vec3d)this.toPlace.to_place.get(this.toPlace.supportBlock + 1)).field_72449_c) {
                           found = true;
                           break;
                        }
                     }

                     if (!found) {
                        BlockPos offsetPosPist = new BlockPos((Vec3d)this.toPlace.to_place.get(this.toPlace.supportBlock + 2));
                        BlockPos pos = (new BlockPos(this.closestTarget.func_174791_d())).func_177982_a(offsetPosPist.func_177958_n(), offsetPosPist.func_177956_o(), offsetPosPist.func_177952_p());
                        if (this.brokenRedstoneTorch && this.get_block((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p()) instanceof BlockAir) {
                           this.stage = 1;
                           this.brokenRedstoneTorch = false;
                        } else {
                           EnumFacing side = BlockUtil.getPlaceableSide(pos);
                           if (side != null) {
                              if (((Boolean)this.rotate.getCurrentState()).booleanValue()) {
                                 BlockPos neighbour = pos.func_177972_a(side);
                                 EnumFacing opposite = side.func_176734_d();
                                 Vec3d hitVec = (new Vec3d(neighbour)).func_72441_c(0.5D, 1.0D, 0.5D).func_178787_e((new Vec3d(opposite.func_176730_m())).func_186678_a(0.5D));
                                 BlockUtil.faceVectorPacketInstant(hitVec);
                              }

                              mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                              mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(net.minecraft.network.play.client.CPacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, side));
                              mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(net.minecraft.network.play.client.CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, side));
                              this.brokenRedstoneTorch = true;
                           }
                        }
                     } else {
                        boolean ext = false;
                        Iterator var14 = mc.field_71441_e.field_72996_f.iterator();

                        while(var14.hasNext()) {
                           Entity t3 = (Entity)var14.next();
                           if (t3 instanceof EntityEnderCrystal && (int)t3.field_70165_t == (int)((Vec3d)this.toPlace.to_place.get(this.toPlace.supportBlock + 1)).field_72450_a && (int)t3.field_70161_v == (int)((Vec3d)this.toPlace.to_place.get(this.toPlace.supportBlock + 1)).field_72449_c) {
                              ext = true;
                              break;
                           }
                        }

                        int n3 = false;
                        this.stuck = 0;
                        this.stage = 0;
                        this.brokenCrystalBug = false;
                        if (ext) {
                           this.breakCrystalPiston((Entity)null);
                           this.brokenCrystalBug = true;
                        }
                     }
                  }

                  return;
               }

               t = (Entity)var2.next();
            } while(!(t instanceof EntityEnderCrystal));
         } while((t.field_70165_t != (double)((int)t.field_70165_t) && (int)t.field_70165_t != (int)this.closestTarget.field_70165_t || (int)((double)((int)t.field_70165_t) - 0.1D) != (int)this.closestTarget.field_70165_t && (int)((double)((int)t.field_70165_t) + 0.1D) != (int)this.closestTarget.field_70165_t || (int)t.field_70161_v != (int)this.closestTarget.field_70161_v) && (t.field_70161_v != (double)((int)t.field_70161_v) && (int)t.field_70161_v != (int)this.closestTarget.field_70161_v || (int)((double)((int)t.field_70161_v) - 0.1D) != (int)this.closestTarget.field_70161_v && (int)((double)((int)t.field_70161_v) + 0.1D) != (int)this.closestTarget.field_70161_v || (int)t.field_70165_t != (int)this.closestTarget.field_70165_t));

         crystal = t;
      }
   }

   public BlockPos compactBlockPos(int step) {
      BlockPos offsetPos = new BlockPos((Vec3d)this.toPlace.to_place.get(this.toPlace.supportBlock + step - 1));
      return (new BlockPos(this.closestTarget.func_174791_d())).func_177982_a(offsetPos.func_177958_n(), offsetPos.func_177956_o(), offsetPos.func_177952_p());
   }

   private void breakCrystalPiston(Entity crystal) {
      if (((Boolean)this.antiWeakness.getCurrentState()).booleanValue()) {
         mc.field_71439_g.field_71071_by.field_70461_c = this.slot_mat[4];
      }

      if (((Boolean)this.rotate.getCurrentState()).booleanValue()) {
         this.lookAtPacket(crystal.field_70165_t, crystal.field_70163_u, crystal.field_70161_v, mc.field_71439_g);
      }

      if (((PistonAura.BreakModes)this.breakMode.getCurrentState()).equals(PistonAura.BreakModes.swing)) {
         this.breakCrystal(crystal);
         mc.field_71439_g.field_71174_a.func_147297_a(new CPacketUseEntity(crystal));
         mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
      }

      if (((Boolean)this.rotate.getCurrentState()).booleanValue()) {
         resetRotation();
      }

   }

   private boolean trapPlayer() {
      int i = 0;
      int blockPlaced = 0;
      if (this.toPlace.to_place.size() > 0 && this.toPlace.supportBlock > 0) {
         do {
            BlockPos offsetPos = new BlockPos((Vec3d)this.toPlace.to_place.get(i));
            BlockPos targetPos = (new BlockPos(this.closestTarget.func_174791_d())).func_177982_a(offsetPos.func_177958_n(), offsetPos.func_177956_o(), offsetPos.func_177952_p());
            if (this.placeBlock(targetPos, 0, 0.0D, 0.0D)) {
               ++blockPlaced;
            }

            if (blockPlaced == ((Integer)this.blocksPerTick.getCurrentState()).intValue()) {
               return false;
            }

            ++i;
         } while(i < this.toPlace.supportBlock);

         this.stage = this.stage == 0 ? 1 : this.stage;
         return true;
      } else {
         this.stage = this.stage == 0 ? 1 : this.stage;
         return true;
      }
   }

   private boolean placeBlock(BlockPos pos, int step, double offsetX, double offsetZ) {
      Block block = mc.field_71441_e.func_180495_p(pos).func_177230_c();
      EnumFacing side = BlockUtil.getPlaceableSide(pos);
      if (!(block instanceof BlockAir) && !(block instanceof BlockLiquid)) {
         return false;
      } else if (side == null) {
         return false;
      } else {
         BlockPos neighbour = pos.func_177972_a(side);
         EnumFacing opposite = side.func_176734_d();
         if (!BlockUtil.canBeClicked(neighbour)) {
            return false;
         } else {
            Vec3d hitVec = (new Vec3d(neighbour)).func_72441_c(0.5D + offsetX, 1.0D, 0.5D + offsetZ).func_178787_e((new Vec3d(opposite.func_176730_m())).func_186678_a(0.5D));
            Block neighbourBlock = mc.field_71441_e.func_180495_p(neighbour).func_177230_c();
            if (mc.field_71439_g.field_71071_by.func_70301_a(this.slot_mat[step]) != ItemStack.field_190927_a) {
               if (mc.field_71439_g.field_71071_by.field_70461_c != this.slot_mat[step]) {
                  mc.field_71439_g.field_71071_by.field_70461_c = this.slot_mat[step] == 11 ? mc.field_71439_g.field_71071_by.field_70461_c : this.slot_mat[step];
               }

               if (!this.isSneaking && BlockUtil.blackList.contains(neighbourBlock) || BlockUtil.shulkerList.contains(neighbourBlock)) {
                  mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.START_SNEAKING));
                  this.isSneaking = true;
               }

               if (((Boolean)this.rotate.getCurrentState()).booleanValue() || step == 1) {
                  Vec3d positionHit = hitVec;
                  if (!((Boolean)this.rotate.getCurrentState()).booleanValue() && step == 1) {
                     positionHit = new Vec3d(mc.field_71439_g.field_70165_t + offsetX, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v + offsetZ);
                  }

                  BlockUtil.faceVectorPacketInstant(positionHit);
               }

               EnumHand handSwing = EnumHand.MAIN_HAND;
               if (this.slot_mat[step] == 11) {
                  handSwing = EnumHand.OFF_HAND;
               }

               mc.field_71442_b.func_187099_a(mc.field_71439_g, mc.field_71441_e, neighbour, opposite, hitVec, handSwing);
               mc.field_71439_g.func_184609_a(handSwing);
               return true;
            } else {
               return false;
            }
         }
      }
   }

   private boolean getMaterialsSlot() {
      if (mc.field_71439_g.func_184592_cb().func_77973_b() instanceof ItemEndCrystal) {
         this.slot_mat[2] = 11;
      }

      int i;
      for(i = 0; i < 9; ++i) {
         ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
         if (stack != ItemStack.field_190927_a) {
            if (stack.func_77973_b() instanceof ItemEndCrystal) {
               this.slot_mat[2] = i;
            } else if (((Boolean)this.antiWeakness.getCurrentState()).booleanValue() && stack.func_77973_b() instanceof ItemSword) {
               this.slot_mat[4] = i;
            } else if (stack.func_77973_b() instanceof ItemBlock) {
               Block block = ((ItemBlock)stack.func_77973_b()).func_179223_d();
               if (block instanceof BlockObsidian) {
                  this.slot_mat[0] = i;
               } else if (block instanceof BlockPistonBase) {
                  this.slot_mat[1] = i;
               } else if (block instanceof BlockRedstoneTorch || block.field_149770_b.equals("blockRedstone")) {
                  this.slot_mat[3] = i;
               }
            }
         }
      }

      i = 0;
      int[] var6 = this.slot_mat;
      int var7 = var6.length;

      for(int var4 = 0; var4 < var7; ++var4) {
         int val = var6[var4];
         if (val != -1) {
            ++i;
         }
      }

      return i == 4 + (((Boolean)this.antiWeakness.getCurrentState()).booleanValue() ? 1 : 0);
   }

   private boolean is_in_hole() {
      this.sur_block = new Double[][]{{this.closestTarget.field_70165_t + 1.0D, this.closestTarget.field_70163_u, this.closestTarget.field_70161_v}, {this.closestTarget.field_70165_t - 1.0D, this.closestTarget.field_70163_u, this.closestTarget.field_70161_v}, {this.closestTarget.field_70165_t, this.closestTarget.field_70163_u, this.closestTarget.field_70161_v + 1.0D}, {this.closestTarget.field_70165_t, this.closestTarget.field_70163_u, this.closestTarget.field_70161_v - 1.0D}};
      return !(this.get_block(this.sur_block[0][0].doubleValue(), this.sur_block[0][1].doubleValue(), this.sur_block[0][2].doubleValue()) instanceof BlockAir) && !(this.get_block(this.sur_block[1][0].doubleValue(), this.sur_block[1][1].doubleValue(), this.sur_block[1][2].doubleValue()) instanceof BlockAir) && !(this.get_block(this.sur_block[2][0].doubleValue(), this.sur_block[2][1].doubleValue(), this.sur_block[2][2].doubleValue()) instanceof BlockAir) && !(this.get_block(this.sur_block[3][0].doubleValue(), this.sur_block[3][1].doubleValue(), this.sur_block[3][2].doubleValue()) instanceof BlockAir);
   }

   private boolean createStructure() {
      PistonAura.structureTemp addedStructure = new PistonAura.structureTemp(Double.MAX_VALUE, 0, (List)null);
      int i = 0;
      int[] meCord = new int[]{(int)mc.field_71439_g.field_70165_t, (int)mc.field_71439_g.field_70163_u, (int)mc.field_71439_g.field_70161_v};
      if ((double)meCord[1] - this.closestTarget.field_70163_u > -1.0D) {
         Double[][] var4 = this.sur_block;
         int var5 = var4.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            Double[] cord_b = var4[var6];
            double[] crystalCords = new double[]{cord_b[0].doubleValue(), cord_b[1].doubleValue() + 1.0D, cord_b[2].doubleValue()};
            BlockPos positionCrystal = new BlockPos(crystalCords[0], crystalCords[1], crystalCords[2]);
            double distance_now;
            if ((distance_now = mc.field_71439_g.func_70011_f(crystalCords[0], crystalCords[1], crystalCords[2])) < addedStructure.distance && (positionCrystal.func_177956_o() != meCord[1] || meCord[0] != positionCrystal.func_177958_n() || Math.abs(meCord[2] - positionCrystal.func_177952_p()) > 3 && meCord[2] != positionCrystal.func_177952_p() || Math.abs(meCord[0] - positionCrystal.func_177958_n()) > 3)) {
               cord_b[1] = cord_b[1].doubleValue() + 1.0D;
               if (this.get_block(crystalCords[0], crystalCords[1], crystalCords[2]) instanceof BlockAir) {
                  double[] pistonCord = new double[]{crystalCords[0] + (double)this.disp_surblock[i][0], crystalCords[1], crystalCords[2] + (double)this.disp_surblock[i][2]};
                  Block blockPiston = this.get_block(pistonCord[0], pistonCord[1], pistonCord[2]);
                  if ((blockPiston instanceof BlockAir || blockPiston instanceof BlockPistonBase) && this.someoneInCoords(pistonCord[0], pistonCord[1], pistonCord[2])) {
                     boolean b;
                     label184: {
                        b = false;
                        if (((Boolean)this.rotate.getCurrentState()).booleanValue()) {
                           if ((int)pistonCord[0] == meCord[0]) {
                              if (this.closestTarget.field_70161_v > mc.field_71439_g.field_70161_v == this.closestTarget.field_70161_v > pistonCord[2] && Math.abs((int)this.closestTarget.field_70161_v - (int)mc.field_71439_g.field_70161_v) != 1) {
                                 break label184;
                              }
                           } else if ((int)pistonCord[2] == meCord[2] && (this.closestTarget.field_70165_t > mc.field_71439_g.field_70165_t == this.closestTarget.field_70165_t > pistonCord[0] && Math.abs((int)this.closestTarget.field_70165_t - (int)mc.field_71439_g.field_70165_t) != 1 || Math.abs((int)this.closestTarget.field_70165_t - (int)mc.field_71439_g.field_70165_t) > 1 && pistonCord[0] > this.closestTarget.field_70165_t == (double)meCord[0] > this.closestTarget.field_70165_t)) {
                              break label184;
                           }
                        }

                        b = true;
                     }

                     if (b) {
                        boolean b2;
                        label167: {
                           b2 = false;
                           if (((Boolean)this.rotate.getCurrentState()).booleanValue()) {
                              if (meCord[0] != (int)this.closestTarget.field_70165_t && meCord[2] != (int)this.closestTarget.field_70161_v) {
                                 if (meCord[0] == (int)pistonCord[0] && Math.abs((int)this.closestTarget.field_70161_v - (int)mc.field_71439_g.field_70161_v) != 1 && (meCord[2] != (int)pistonCord[2] || Math.abs((int)this.closestTarget.field_70161_v - (int)mc.field_71439_g.field_70161_v) == 1)) {
                                    break label167;
                                 }
                              } else if (mc.field_71439_g.func_70011_f(crystalCords[0], crystalCords[1], crystalCords[2]) > 3.5D && meCord[0] != (int)crystalCords[0] && meCord[2] != (int)crystalCords[2]) {
                                 break label167;
                              }
                           }

                           b2 = true;
                        }

                        if (b2) {
                           int[] poss = null;
                           int[][] var19 = this.disp_surblock;
                           int supportBlock = var19.length;

                           for(int var21 = 0; var21 < supportBlock; ++var21) {
                              int[] possibilites = var19[var21];
                              double[] coordinatesTemp = new double[]{cord_b[0].doubleValue() + (double)this.disp_surblock[i][0] + (double)possibilites[0], cord_b[1].doubleValue(), cord_b[2].doubleValue() + (double)this.disp_surblock[i][2] + (double)possibilites[2]};
                              int[] torchCoords = new int[]{(int)coordinatesTemp[0], (int)coordinatesTemp[1], (int)coordinatesTemp[2]};
                              int[] crystalCoords = new int[]{(int)crystalCords[0], (int)crystalCords[1], (int)crystalCords[2]};
                              if (this.get_block(coordinatesTemp[0], coordinatesTemp[1], coordinatesTemp[2]) instanceof BlockAir && (torchCoords[0] != crystalCoords[0] || torchCoords[1] != crystalCoords[1] || crystalCoords[2] != torchCoords[2]) && this.someoneInCoords(coordinatesTemp[0], coordinatesTemp[1], coordinatesTemp[2])) {
                                 poss = possibilites;
                                 break;
                              }
                           }

                           if (poss != null) {
                              List toPlaceTemp = new ArrayList();
                              supportBlock = 0;
                              if (this.get_block(cord_b[0].doubleValue() + (double)this.disp_surblock[i][0], cord_b[1].doubleValue() - 1.0D, cord_b[2].doubleValue() + (double)this.disp_surblock[i][2]) instanceof BlockAir) {
                                 toPlaceTemp.add(new Vec3d((double)(this.disp_surblock[i][0] * 2), (double)this.disp_surblock[i][1], (double)(this.disp_surblock[i][2] * 2)));
                                 ++supportBlock;
                              }

                              if (this.get_block(cord_b[0].doubleValue() + (double)this.disp_surblock[i][0] + (double)poss[0], cord_b[1].doubleValue() - 1.0D, cord_b[2].doubleValue() + (double)this.disp_surblock[i][2] + (double)poss[2]) instanceof BlockAir) {
                                 toPlaceTemp.add(new Vec3d((double)(this.disp_surblock[i][0] * 2 + poss[0]), (double)this.disp_surblock[i][1], (double)(this.disp_surblock[i][2] * 2 + poss[2])));
                                 ++supportBlock;
                              }

                              toPlaceTemp.add(new Vec3d((double)(this.disp_surblock[i][0] * 2), (double)(this.disp_surblock[i][1] + 1), (double)(this.disp_surblock[i][2] * 2)));
                              toPlaceTemp.add(new Vec3d((double)this.disp_surblock[i][0], (double)(this.disp_surblock[i][1] + 1), (double)this.disp_surblock[i][2]));
                              toPlaceTemp.add(new Vec3d((double)(this.disp_surblock[i][0] * 2 + poss[0]), (double)(this.disp_surblock[i][1] + 1), (double)(this.disp_surblock[i][2] * 2 + poss[2])));
                              float offsetX;
                              float offsetZ;
                              if (this.disp_surblock[i][0] != 0) {
                                 offsetX = ((Boolean)this.rotate.getCurrentState()).booleanValue() ? (float)this.disp_surblock[i][0] / 2.0F : (float)this.disp_surblock[i][0];
                                 if (((Boolean)this.rotate.getCurrentState()).booleanValue()) {
                                    if (mc.field_71439_g.func_70092_e(pistonCord[0], pistonCord[1], pistonCord[2] + 0.5D) > mc.field_71439_g.func_70092_e(pistonCord[0], pistonCord[1], pistonCord[2] - 0.5D)) {
                                       offsetZ = -0.5F;
                                    } else {
                                       offsetZ = 0.5F;
                                    }
                                 } else {
                                    offsetZ = (float)this.disp_surblock[i][2];
                                 }
                              } else {
                                 offsetZ = ((Boolean)this.rotate.getCurrentState()).booleanValue() ? (float)this.disp_surblock[i][2] / 2.0F : (float)this.disp_surblock[i][2];
                                 if (((Boolean)this.rotate.getCurrentState()).booleanValue()) {
                                    if (mc.field_71439_g.func_70092_e(pistonCord[0] + 0.5D, pistonCord[1], pistonCord[2]) > mc.field_71439_g.func_70092_e(pistonCord[0] - 0.5D, pistonCord[1], pistonCord[2])) {
                                       offsetX = -0.5F;
                                    } else {
                                       offsetX = 0.5F;
                                    }
                                 } else {
                                    offsetX = (float)this.disp_surblock[i][0];
                                 }
                              }

                              addedStructure.replaceValues(distance_now, supportBlock, toPlaceTemp, -1, offsetX, offsetZ);
                           }
                        }
                     }
                  }
               }
            }

            ++i;
         }

         if (addedStructure.to_place != null) {
            if (((Boolean)this.blockPlayer.getCurrentState()).booleanValue()) {
               Vec3d valuesStart = (Vec3d)addedStructure.to_place.get(addedStructure.supportBlock + 1);
               int[] valueBegin = new int[]{(int)(-valuesStart.field_72450_a), (int)valuesStart.field_72448_b, (int)(-valuesStart.field_72449_c)};
               addedStructure.to_place.add(0, new Vec3d(0.0D, 2.0D, 0.0D));
               addedStructure.to_place.add(0, new Vec3d((double)valueBegin[0], (double)(valueBegin[1] + 1), (double)valueBegin[2]));
               addedStructure.to_place.add(0, new Vec3d((double)valueBegin[0], (double)valueBegin[1], (double)valueBegin[2]));
               addedStructure.supportBlock += 3;
            }

            this.toPlace = addedStructure;
            return true;
         }
      }

      return false;
   }

   private boolean someoneInCoords(double x, double y, double z) {
      int xCheck = (int)x;
      int yCheck = (int)y;
      int zCheck = (int)z;
      List playerList = mc.field_71441_e.field_73010_i;
      Iterator var11 = playerList.iterator();

      EntityPlayer player;
      do {
         if (!var11.hasNext()) {
            return true;
         }

         player = (EntityPlayer)var11.next();
      } while((int)player.field_70165_t != xCheck || (int)player.field_70161_v != zCheck || (int)player.field_70163_u < yCheck - 1 || (int)player.field_70163_u > yCheck + 1);

      return false;
   }

   private Block get_block(double x, double y, double z) {
      return mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
   }

   private void lookAtPacket(double px, double py, double pz, EntityPlayer me) {
      double[] v = calculateLookAt(px, py, pz, me);
      setYawAndPitch((float)v[0], (float)v[1]);
   }

   public static double[] calculateLookAt(double px, double py, double pz, EntityPlayer me) {
      double dirx = me.field_70165_t - px;
      double diry = me.field_70163_u - py;
      double dirz = me.field_70161_v - pz;
      double len = Math.sqrt(dirx * dirx + diry * diry + dirz * dirz);
      dirx /= len;
      diry /= len;
      dirz /= len;
      double pitch = Math.asin(diry);
      double yaw = Math.atan2(dirz, dirx);
      pitch = pitch * 180.0D / 3.141592653589793D;
      yaw = yaw * 180.0D / 3.141592653589793D;
      yaw += 90.0D;
      return new double[]{yaw, pitch};
   }

   private static void setYawAndPitch(float yaw1, float pitch1) {
      yaw = (double)yaw1;
      pitch = (double)pitch1;
      isSpoofingAngles = true;
   }

   private void breakCrystal(Entity crystal) {
      mc.field_71442_b.func_78764_a(mc.field_71439_g, crystal);
      mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send event) {
      Packet packet = event.getPacket();
      if (packet instanceof CPacketPlayer && isSpoofingAngles) {
         ((CPacketPlayer)packet).field_149476_e = (float)yaw;
         ((CPacketPlayer)packet).field_149473_f = (float)pitch;
      }

   }

   private static void resetRotation() {
      if (isSpoofingAngles) {
         yaw = (double)mc.field_71439_g.field_70177_z;
         pitch = (double)mc.field_71439_g.field_70125_A;
         isSpoofingAngles = false;
      }

   }

   private static enum BreakModes {
      packet,
      swing;
   }

   static class structureTemp {
      public double distance;
      public int supportBlock;
      public List to_place;
      public int direction;
      public float offsetX;
      public float offsetZ;

      public structureTemp(double distance, int supportBlock, List to_place) {
         this.distance = distance;
         this.supportBlock = supportBlock;
         this.to_place = to_place;
         this.direction = -1;
      }

      public void replaceValues(double distance, int supportBlock, List to_place, int direction, float offsetX, float offsetZ) {
         this.distance = distance;
         this.supportBlock = supportBlock;
         this.to_place = to_place;
         this.direction = direction;
         this.offsetX = offsetX;
         this.offsetZ = offsetZ;
      }
   }
}
