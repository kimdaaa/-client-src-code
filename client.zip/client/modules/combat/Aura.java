package client.modules.combat;

import client.Client;
import client.events.UpdateWalkingPlayerEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.EntityUtil;
import client.util.MathUtil;
import client.util.PlayerUtil;
import client.util.Timer;
import java.util.Iterator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Aura extends Module {
   public static Entity target;
   private final Timer timer = new Timer();
   public Setting range = this.register(new Setting("Range", 6.0F, 0.1F, 7.0F));
   public Setting wallRange = this.register(new Setting("WallRange", 6.0F, 0.1F, 7.0F));
   public Setting delay = this.register(new Setting("Delay", true));
   public Setting rotate = this.register(new Setting("Rotate", true));
   public Setting swordOnly = this.register(new Setting("SwordOnly", true));
   public Setting players = this.register(new Setting("Players", true));
   public Setting mobs = this.register(new Setting("Mobs", false));
   public Setting animals = this.register(new Setting("Animals", false));
   public Setting vehicles = this.register(new Setting("Entities", false));
   public Setting projectiles = this.register(new Setting("Projectiles", false));
   public Setting tps = this.register(new Setting("TpsSync", true));
   public Setting packet = this.register(new Setting("Packet", false));

   public Aura() {
      super("Aura", "Attacks enemies.", Module.Category.COMBAT);
   }

   public void onTick() {
      if (!((Boolean)this.rotate.getCurrentState()).booleanValue()) {
         this.attackEnemy();
      }

   }

   @SubscribeEvent
   public void onUpdateWalkingPlayerEvent(UpdateWalkingPlayerEvent event) {
      if (event.getStage() == 0 && ((Boolean)this.rotate.getCurrentState()).booleanValue()) {
         this.attackEnemy();
      }

   }

   private void attackEnemy() {
      if (((Boolean)this.swordOnly.getCurrentState()).booleanValue() && !EntityUtil.holdingWeapon(mc.field_71439_g)) {
         target = null;
      } else {
         int wait = !((Boolean)this.delay.getCurrentState()).booleanValue() ? 0 : (int)((float)EntityUtil.getCooldownByWeapon(mc.field_71439_g) * (((Boolean)this.tps.getCurrentState()).booleanValue() ? Client.serverManager.getTpsFactor() : 1.0F));
         if (this.timer.passedMs((long)wait)) {
            target = this.getTarget();
            if (target != null) {
               if (((Boolean)this.rotate.getCurrentState()).booleanValue()) {
                  Client.rotationManager.lookAtEntity(target);
               }

               EntityUtil.attackEntity(target, ((Boolean)this.packet.getCurrentState()).booleanValue(), true);
               this.timer.reset();
            }
         }
      }
   }

   private Entity getTarget() {
      Entity target = null;
      double distance = (double)((Float)this.range.getCurrentState()).floatValue();
      double maxHealth = 36.0D;
      Iterator var6 = mc.field_71441_e.field_73010_i.iterator();

      while(var6.hasNext()) {
         Entity entity = (Entity)var6.next();
         if ((((Boolean)this.players.getCurrentState()).booleanValue() && entity instanceof EntityPlayer || ((Boolean)this.animals.getCurrentState()).booleanValue() && EntityUtil.isPassive(entity) || ((Boolean)this.mobs.getCurrentState()).booleanValue() && EntityUtil.isMobAggressive(entity) || ((Boolean)this.vehicles.getCurrentState()).booleanValue() && EntityUtil.isVehicle(entity) || ((Boolean)this.projectiles.getCurrentState()).booleanValue() && EntityUtil.isProjectile(entity)) && (!(entity instanceof EntityLivingBase) || !EntityUtil.isntValid(entity, distance)) && (mc.field_71439_g.func_70685_l(entity) || EntityUtil.canEntityFeetBeSeen(entity) || mc.field_71439_g.func_70068_e(entity) <= MathUtil.square((double)((Float)this.wallRange.getCurrentState()).floatValue()))) {
            if (target == null) {
               target = entity;
               distance = mc.field_71439_g.func_70068_e(entity);
               maxHealth = (double)EntityUtil.getHealth(entity);
            } else {
               if (entity instanceof EntityPlayer && PlayerUtil.isArmorLow((EntityPlayer)entity, 18)) {
                  target = entity;
                  break;
               }

               if (mc.field_71439_g.func_70068_e(entity) < distance) {
                  target = entity;
                  distance = mc.field_71439_g.func_70068_e(entity);
                  maxHealth = (double)EntityUtil.getHealth(entity);
               }

               if ((double)EntityUtil.getHealth(entity) < maxHealth) {
                  target = entity;
                  distance = mc.field_71439_g.func_70068_e(entity);
                  maxHealth = (double)EntityUtil.getHealth(entity);
               }
            }
         }
      }

      return target;
   }

   public String getDisplayInfo() {
      return target instanceof EntityPlayer ? target.func_70005_c_() : null;
   }
}
