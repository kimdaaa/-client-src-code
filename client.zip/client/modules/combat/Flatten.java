package client.modules.combat;

import client.Client;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.BlockUtil;
import client.util.InventoryUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.BlockObsidian;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class Flatten extends Module {
   private final Setting blocksPerTick = this.register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
   private final Setting rotate = this.register(new Setting("Rotate", false));
   private final Setting packet = this.register(new Setting("PacketPlace", false));
   private final Vec3d[] offsetsDefault = new Vec3d[]{new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(0.0D, 0.0D, 1.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(-1.0D, 0.0D, 0.0D)};
   private int offsetStep = 0;
   private int oldSlot = -1;
   private boolean placing = false;

   public Flatten() {
      super("Flatten", "Flatter than 19xp's 14yr old girlfriend", Module.Category.COMBAT);
   }

   public void onEnable() {
      this.oldSlot = mc.field_71439_g.field_71071_by.field_70461_c;
   }

   public void onDisable() {
      this.oldSlot = -1;
   }

   public void onTick() {
      int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
      if (obbySlot == -1) {
         this.toggle();
      }

   }

   public void onUpdate() {
      int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
      if (obbySlot == -1) {
         this.toggle();
      }

      EntityPlayer closest_target = this.findClosestTarget();
      if (closest_target != null) {
         List place_targets = new ArrayList();
         Collections.addAll(place_targets, this.offsetsDefault);

         for(int blocks_placed = 0; blocks_placed < ((Integer)this.blocksPerTick.getCurrentState()).intValue(); this.placing = false) {
            if (this.offsetStep >= place_targets.size()) {
               this.offsetStep = 0;
               break;
            }

            this.placing = true;
            BlockPos offset_pos = new BlockPos((Vec3d)place_targets.get(this.offsetStep));
            BlockPos target_pos = (new BlockPos(closest_target.func_174791_d())).func_177977_b().func_177982_a(offset_pos.func_177958_n(), offset_pos.func_177956_o(), offset_pos.func_177952_p());
            boolean should_try_place = mc.field_71441_e.func_180495_p(target_pos).func_185904_a().func_76222_j();
            Iterator var8 = mc.field_71441_e.func_72839_b((Entity)null, new AxisAlignedBB(target_pos)).iterator();

            while(var8.hasNext()) {
               Entity entity = (Entity)var8.next();
               if (!(entity instanceof EntityItem) && !(entity instanceof EntityXPOrb)) {
                  should_try_place = false;
                  break;
               }
            }

            if (should_try_place) {
               this.place(target_pos, obbySlot, this.oldSlot);
               ++blocks_placed;
            }

            ++this.offsetStep;
         }

      }
   }

   private void place(BlockPos pos, int slot, int oldSlot) {
      mc.field_71439_g.field_71071_by.field_70461_c = slot;
      mc.field_71442_b.func_78765_e();
      BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getCurrentState()).booleanValue(), ((Boolean)this.packet.getCurrentState()).booleanValue(), mc.field_71439_g.func_70093_af());
      mc.field_71439_g.field_71071_by.field_70461_c = oldSlot;
      mc.field_71442_b.func_78765_e();
   }

   public void onLogout() {
      if (this.isOn()) {
         this.disable();
      }

   }

   private EntityPlayer findClosestTarget() {
      if (mc.field_71441_e.field_73010_i.isEmpty()) {
         return null;
      } else {
         EntityPlayer closestTarget = null;
         Iterator var2 = mc.field_71441_e.field_73010_i.iterator();

         while(true) {
            EntityPlayer target;
            do {
               do {
                  do {
                     do {
                        do {
                           do {
                              if (!var2.hasNext()) {
                                 return closestTarget;
                              }

                              target = (EntityPlayer)var2.next();
                           } while(target == mc.field_71439_g);
                        } while(!target.func_70089_S());
                     } while(Client.friendManager.isFriend(target.func_70005_c_()));
                  } while(target.func_110143_aJ() <= 0.0F);
               } while(mc.field_71439_g.func_70032_d(target) > 5.0F);
            } while(closestTarget != null && mc.field_71439_g.func_70032_d(target) > mc.field_71439_g.func_70032_d(closestTarget));

            closestTarget = target;
         }
      }
   }
}
