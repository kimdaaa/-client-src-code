package client.modules.combat;

import client.events.Render3DEvent;
import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.BlockUtil;
import client.util.EntityUtil;
import client.util.InventoryUtil;
import client.util.RenderUtil;
import client.util.RotationUtil;
import com.google.common.eventbus.Subscribe;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.ToDoubleFunction;
import net.minecraft.block.Block;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;

public class Holefiller extends Module {
   public Setting bpt = this.register(new Setting("Blocks Per Tick", Integer.valueOf(10), Integer.valueOf(1), Integer.valueOf(20)));
   public Setting range = this.register(new Setting("Range", 5.0F, 1.0F, 6.0F));
   public Setting distance = this.register(new Setting("Smart range", 2.0F, 1.0F, 7.0F));
   public Setting rotate = this.register(new Setting("Rotate", false));
   public Setting packet = this.register(new Setting("Packet", true));
   public Setting render = this.register(new Setting("Render", true));
   public Setting red = this.register(new Setting("Red", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting green = this.register(new Setting("Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting blue = this.register(new Setting("Blue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting alpha = this.register(new Setting("Alpha", Integer.valueOf(120), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting boxAlpha = this.register(new Setting("BoxAlpha", Integer.valueOf(120), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting lineWidth = this.register(new Setting("LineWidth", Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(5)));
   public Setting fov = this.register(new Setting("inFov", true));
   public Setting box = this.register(new Setting("Box", true));
   public Setting outline = this.register(new Setting("Outline", true));
   public Setting cRed = this.register(new Setting("OutlineRed", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting cGreen = this.register(new Setting("OutlineGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting cBlue = this.register(new Setting("OutlineBlue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
   public Setting cAlpha = this.register(new Setting("OutlineAlpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
   private int placeAmount = 0;
   private int blockSlot = -1;
   private boolean isSneaking;
   private static final BlockPos[] surroundOffset = BlockUtil.toBlockPos(BlockUtil.getOffsets(0, true));
   private static final List unSafeBlocks;

   public Holefiller() {
      super("HoleFiller", "Fills holes near enemies.", Module.Category.COMBAT);
   }

   @Subscribe
   public void onUpdate() {
      if (this.check()) {
         EntityPlayer currentTarget = EntityUtil.getTarget(10.0F);
         if (currentTarget == null) {
            return;
         }

         if (EntityUtil.isInHole(currentTarget)) {
            return;
         }

         List holes = this.calcHoles();
         currentTarget.getClass();
         holes.sort(Comparator.comparingDouble(currentTarget::func_174818_b));
         if (holes.size() == 0) {
            return;
         }

         int lastSlot = mc.field_71439_g.field_71071_by.field_70461_c;
         this.blockSlot = InventoryUtil.getItemFromHotbar(Item.func_150898_a(Blocks.field_150343_Z));
         if (this.blockSlot == -1) {
            return;
         }

         BlockPos hole = null;
         Iterator var5 = holes.iterator();

         while(var5.hasNext()) {
            BlockPos pos = (BlockPos)var5.next();
            if (currentTarget.func_70011_f((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p()) < (double)((Float)this.distance.getCurrentState()).floatValue()) {
               hole = pos;
            }
         }

         if (hole != null) {
            ((NetHandlerPlayClient)Objects.requireNonNull(mc.func_147114_u())).func_147297_a(new CPacketHeldItemChange(this.blockSlot));
            this.placeBlock(hole);
            mc.func_147114_u().func_147297_a(new CPacketHeldItemChange(lastSlot));
         }
      }

   }

   private void placeBlock(BlockPos pos) {
      if (((Integer)this.bpt.getCurrentState()).intValue() > this.placeAmount) {
         BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getCurrentState()).booleanValue(), ((Boolean)this.packet.getCurrentState()).booleanValue(), this.isSneaking);
         ++this.placeAmount;
      }

   }

   private boolean check() {
      if (mc.field_71439_g == null) {
         return false;
      } else {
         this.placeAmount = 0;
         this.blockSlot = InventoryUtil.getItemFromHotbar(Item.func_150898_a(Blocks.field_150343_Z));
         return true;
      }
   }

   public List calcHoles() {
      ArrayList safeSpots = new ArrayList();
      List positions = BlockUtil.getCock(((Float)this.range.getCurrentState()).floatValue(), false);
      Iterator var3 = positions.iterator();

      while(true) {
         BlockPos pos;
         do {
            do {
               do {
                  do {
                     if (!var3.hasNext()) {
                        return safeSpots;
                     }

                     pos = (BlockPos)var3.next();
                  } while(BlockUtil.isPositionPlaceable(pos, true) == 1);
               } while(!mc.field_71441_e.func_180495_p(pos).func_177230_c().equals(Blocks.field_150350_a));
            } while(!mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 1, 0)).func_177230_c().equals(Blocks.field_150350_a));
         } while(!mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 2, 0)).func_177230_c().equals(Blocks.field_150350_a));

         boolean isSafe = true;
         BlockPos[] var6 = surroundOffset;
         int var7 = var6.length;

         for(int var8 = 0; var8 < var7; ++var8) {
            BlockPos offset = var6[var8];
            Block block = mc.field_71441_e.func_180495_p(pos.func_177971_a(offset)).func_177230_c();
            if (block != Blocks.field_150357_h && block != Blocks.field_150343_Z) {
               isSafe = false;
            }
         }

         if (isSafe) {
            safeSpots.add(pos);
         }
      }
   }

   public void onRender3D(Render3DEvent event) {
      assert mc.field_175622_Z != null;

      Vec3i playerPos = new Vec3i(mc.field_175622_Z.field_70165_t, mc.field_175622_Z.field_70163_u, mc.field_175622_Z.field_70161_v);

      for(int x = playerPos.func_177958_n() - 5; (float)x < (float)playerPos.func_177958_n() + ((Float)this.range.getCurrentState()).floatValue(); ++x) {
         for(int z = playerPos.func_177952_p() - 5; (float)z < (float)playerPos.func_177952_p() + ((Float)this.range.getCurrentState()).floatValue(); ++z) {
            for(int y = playerPos.func_177956_o() + 5; y > playerPos.func_177956_o() - 5; --y) {
               BlockPos pos = new BlockPos(x, y, z);
               if (mc.field_71441_e.func_180495_p(pos).func_177230_c().equals(Blocks.field_150350_a) && mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 1, 0)).func_177230_c().equals(Blocks.field_150350_a) && mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 2, 0)).func_177230_c().equals(Blocks.field_150350_a) && (!pos.equals(new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v)) || isPosInFov(pos).booleanValue() || !((Boolean)this.fov.getCurrentState()).booleanValue())) {
                  if (mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150357_h) {
                     RenderUtil.drawBoxESP(pos, new Color(((Integer)this.red.getCurrentState()).intValue(), ((Integer)this.green.getCurrentState()).intValue(), ((Integer)this.blue.getCurrentState()).intValue(), ((Integer)this.alpha.getCurrentState()).intValue()), ((Boolean)this.outline.getCurrentState()).booleanValue(), new Color(((Integer)this.cRed.getCurrentState()).intValue(), ((Integer)this.cGreen.getCurrentState()).intValue(), ((Integer)this.cBlue.getCurrentState()).intValue(), ((Integer)this.cAlpha.getCurrentState()).intValue()), ((Integer)this.lineWidth.getCurrentState()).floatValue(), ((Boolean)this.outline.getCurrentState()).booleanValue(), ((Boolean)this.box.getCurrentState()).booleanValue(), ((Integer)this.boxAlpha.getCurrentState()).intValue(), true);
                  } else if (!isBlockUnSafe(mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c()) && !isBlockUnSafe(mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c()) && !isBlockUnSafe(mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c()) && !isBlockUnSafe(mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c()) && !isBlockUnSafe(mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c())) {
                     RenderUtil.drawBoxESP(pos, new Color(((Integer)this.red.getCurrentState()).intValue(), ((Integer)this.green.getCurrentState()).intValue(), ((Integer)this.blue.getCurrentState()).intValue(), ((Integer)this.alpha.getCurrentState()).intValue()), ((Boolean)this.outline.getCurrentState()).booleanValue(), new Color(((Integer)this.cRed.getCurrentState()).intValue(), ((Integer)this.cGreen.getCurrentState()).intValue(), ((Integer)this.cBlue.getCurrentState()).intValue(), ((Integer)this.cAlpha.getCurrentState()).intValue()), ((Integer)this.lineWidth.getCurrentState()).floatValue(), ((Boolean)this.outline.getCurrentState()).booleanValue(), ((Boolean)this.box.getCurrentState()).booleanValue(), ((Integer)this.boxAlpha.getCurrentState()).intValue(), true);
                  }
               }
            }
         }
      }

   }

   private static boolean isBlockUnSafe(Block block) {
      return !unSafeBlocks.contains(block);
   }

   private static Boolean isPosInFov(BlockPos pos) {
      int dirnumber = RotationUtil.getDirection4D();
      if (dirnumber == 0 && (double)pos.func_177952_p() - BlockUtil.mc.field_71439_g.func_174791_d().field_72449_c < 0.0D) {
         return false;
      } else if (dirnumber == 1 && (double)pos.func_177958_n() - BlockUtil.mc.field_71439_g.func_174791_d().field_72450_a > 0.0D) {
         return false;
      } else {
         return dirnumber == 2 && (double)pos.func_177952_p() - BlockUtil.mc.field_71439_g.func_174791_d().field_72449_c > 0.0D ? false : dirnumber != 3 || (double)pos.func_177958_n() - BlockUtil.mc.field_71439_g.func_174791_d().field_72450_a >= 0.0D;
      }
   }

   static {
      unSafeBlocks = Arrays.asList(Blocks.field_150343_Z, Blocks.field_150357_h, Blocks.field_150477_bB, Blocks.field_150467_bQ);
   }
}
