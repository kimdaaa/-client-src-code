package client.modules.combat;

import client.gui.impl.setting.Setting;
import client.modules.Module;
import client.util.BlockUtil;
import client.util.EntityUtil;
import client.util.InventoryUtil;
import net.minecraft.block.BlockObsidian;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class AntiCity extends Module {
   public Setting packet = this.register(new Setting("Packet", true));
   public Setting rotate = this.register(new Setting("Rotate", false));

   public AntiCity() {
      super("AntiCity", "", Module.Category.COMBAT);
   }

   public void onUpdate() {
      BlockPos pos = EntityUtil.getPlayerPos(mc.field_71439_g);
      int preSlot = AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c;
      int whileSlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
      if (EntityUtil.isSafe(mc.field_71439_g)) {
         if (mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150343_Z && mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c().func_177977_b()).func_177230_c() == Blocks.field_150357_h) && whileSlot > -1) {
            AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = whileSlot;
            AutoTrap.mc.field_71442_b.func_78765_e();
            BlockUtil.placeBlock(pos.func_177978_c().func_177978_c(), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getCurrentState()).booleanValue(), ((Boolean)this.packet.getCurrentState()).booleanValue(), false);
            AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = preSlot;
            AutoTrap.mc.field_71442_b.func_78765_e();
         }

         if (mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150343_Z && mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f().func_177977_b()).func_177230_c() == Blocks.field_150357_h) && whileSlot > -1) {
            AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = whileSlot;
            AutoTrap.mc.field_71442_b.func_78765_e();
            BlockUtil.placeBlock(pos.func_177974_f().func_177974_f(), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getCurrentState()).booleanValue(), ((Boolean)this.packet.getCurrentState()).booleanValue(), false);
            AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = preSlot;
            AutoTrap.mc.field_71442_b.func_78765_e();
         }

         if (mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150343_Z && mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d().func_177977_b()).func_177230_c() == Blocks.field_150357_h) && whileSlot > -1) {
            AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = whileSlot;
            AutoTrap.mc.field_71442_b.func_78765_e();
            BlockUtil.placeBlock(pos.func_177968_d().func_177968_d(), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getCurrentState()).booleanValue(), ((Boolean)this.packet.getCurrentState()).booleanValue(), false);
            AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = preSlot;
            AutoTrap.mc.field_71442_b.func_78765_e();
         }

         if (mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150343_Z && mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e()).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e().func_177984_a()).func_177230_c() == Blocks.field_150350_a && (mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e().func_177977_b()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e().func_177977_b()).func_177230_c() == Blocks.field_150357_h) && whileSlot > -1) {
            AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = whileSlot;
            AutoTrap.mc.field_71442_b.func_78765_e();
            BlockUtil.placeBlock(pos.func_177976_e().func_177976_e(), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getCurrentState()).booleanValue(), ((Boolean)this.packet.getCurrentState()).booleanValue(), false);
            AutoTrap.mc.field_71439_g.field_71071_by.field_70461_c = preSlot;
            AutoTrap.mc.field_71442_b.func_78765_e();
         }
      }

   }
}
