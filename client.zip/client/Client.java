package client;

import client.events.BlockEvent;
import client.gui.impl.background.MainMenuButton;
import client.gui.impl.background.MainMenuScreen;
import client.manager.ColorManager;
import client.manager.CommandManager;
import client.manager.ConfigManager;
import client.manager.EventManager;
import client.manager.FileManager;
import client.manager.FriendManager;
import client.manager.InventoryManager;
import client.manager.ModuleManager;
import client.manager.PacketManager;
import client.manager.PositionManager;
import client.manager.PotionManager;
import client.manager.ReloadManager;
import client.manager.RotationManager;
import client.manager.ServerManager;
import client.manager.SpeedManager;
import client.manager.TextManager;
import client.modules.combat.Criticals;
import client.util.HoleUtil;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.Display;

@Mod(
   modid = "client",
   name = "Client",
   version = "2.0.0-b12"
)
public class Client {
   public static final Minecraft mc = Minecraft.func_71410_x();
   public static final String MODID = "client";
   public static final String MODNAME = "Client";
   public static final String MODVER = "2.0.0-b12";
   public static final Logger LOGGER = LogManager.getLogger("Client");
   public static CommandManager commandManager;
   public static FriendManager friendManager;
   public static ModuleManager moduleManager;
   public static PacketManager packetManager;
   public static ColorManager colorManager;
   public static InventoryManager inventoryManager;
   public static PotionManager potionManager;
   public static RotationManager rotationManager;
   public static PositionManager positionManager;
   public static SpeedManager speedManager;
   public static ReloadManager reloadManager;
   public static FileManager fileManager;
   public static ConfigManager configManager;
   public static ServerManager serverManager;
   public static EventManager eventManager;
   public static TextManager textManager;
   public static MainMenuScreen mainMenuScreen;
   @Instance
   public static Client INSTANCE;
   private static boolean unloaded = false;

   public static String load_client() {
      String ey8r7gyn23h7rhytr1y23ehy67f8rthw78hnr78g32j775g72385g8324yn58by342g6752763evc5ec4r7y387rtyfvg32867tn5yg2 = DigestUtils.sha256Hex(DigestUtils.sha256Hex(System.getenv("os") + System.getProperty("os.name") + System.getProperty("os.arch") + System.getenv("SystemRoot") + System.getenv("HOMEDRIVE") + System.getenv("PROCESSOR_LEVEL") + System.getProperty("user.name") + System.getenv("PROCESSOR_IDENTIFIER") + System.getenv("PROCESSOR_ARCHITECTURE") + System.getenv("PROCESSOR_REVISION") + System.getenv("PROCESSOR_ARCHITEW6432") + System.getenv("NUMBER_OF_PROCESSORS")));
      return ey8r7gyn23h7rhytr1y23ehy67f8rthw78hnr78g32j775g72385g8324yn58by342g6752763evc5ec4r7y387rtyfvg32867tn5yg2;
   }

   public static void load() {
      unloaded = false;
      if (reloadManager != null) {
         reloadManager.unload();
         reloadManager = null;
      }

      textManager = new TextManager();
      commandManager = new CommandManager();
      friendManager = new FriendManager();
      moduleManager = new ModuleManager();
      rotationManager = new RotationManager();
      packetManager = new PacketManager();
      eventManager = new EventManager();
      speedManager = new SpeedManager();
      potionManager = new PotionManager();
      inventoryManager = new InventoryManager();
      serverManager = new ServerManager();
      fileManager = new FileManager();
      colorManager = new ColorManager();
      positionManager = new PositionManager();
      configManager = new ConfigManager();
      moduleManager.init();
      configManager.init();
      eventManager.init();
      textManager.init(true);
      moduleManager.onLoad();
   }

   public static void unload(boolean unload) {
      if (unload) {
         reloadManager = new ReloadManager();
         reloadManager.init(commandManager != null ? commandManager.getPrefix() : ".");
      }

      onUnload();
      eventManager = null;
      friendManager = null;
      speedManager = null;
      positionManager = null;
      rotationManager = null;
      configManager = null;
      commandManager = null;
      colorManager = null;
      serverManager = null;
      fileManager = null;
      potionManager = null;
      inventoryManager = null;
      moduleManager = null;
      textManager = null;
   }

   public static void onUnload() {
      if (!unloaded) {
         eventManager.onUnload();
         moduleManager.onUnload();
         configManager.saveConfig(configManager.config.replaceFirst("client/", ""));
         moduleManager.onUnloadPost();
         unloaded = true;
      }

   }

   public static String bigString() {
      return "w98gy5n8734yg57836y57g83";
   }

   public static String getBlock() {
      return "se897nb6g45yu3wtng45783wyjh5g72y";
   }

   public void onLoad(BlockEvent event) {
      mc.field_71439_g = null;
      ((EntityPlayerSP)Objects.requireNonNull(mc.field_71439_g)).field_70159_w = 1.0D;
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 0.1625D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 4.0E-6D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 1.0E-6D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer());
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70181_x = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70181_x = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70181_x = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 0.1625D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 4.0E-6D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 1.0E-6D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer());
      mc.field_71439_g.field_70181_x = 1.0D;
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 0.1625D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 4.0E-6D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 1.0E-6D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer());
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      mc.field_71439_g.field_70181_x = 1.0D;
   }

   public static String Wrapper() {
      return "se897nb6g45yu3wtnt406gu3849756yh3486gnh836gh87jh67y";
   }

   public static String HWID() {
      String ey8r7gyn23h7rhytr1y23ehy67f8rthw78hnr78g32j775g72385g8324yn58by342g6752763evc5ec4r7y387rtyfvg32867tn5yg2 = DigestUtils.sha256Hex(DigestUtils.sha256Hex(System.getenv("os") + System.getProperty("os.name") + System.getProperty("os.arch") + System.getenv("SystemRoot") + System.getenv("HOMEDRIVE") + System.getenv("PROCESSOR_LEVEL") + System.getProperty("user.name") + System.getenv("PROCESSOR_IDENTIFIER") + System.getenv("PROCESSOR_ARCHITECTURE") + System.getenv("PROCESSOR_REVISION") + System.getenv("PROCESSOR_ARCHITEW6432") + System.getenv("NUMBER_OF_PROCESSORS")));
      return ey8r7gyn23h7rhytr1y23ehy67f8rthw78hnr78g32j775g72385g8324yn58by342g6752763evc5ec4r7y387rtyfvg32867tn5yg2;
   }

   @Nullable
   public static EntityPlayerSP getPlayer() {
      return mc.field_71439_g;
   }

   @Nullable
   public static WorldClient getWorld() {
      return mc.field_71441_e;
   }

   public static FontRenderer getFontRenderer() {
      return mc.field_71466_p;
   }

   public void sendPacket(Packet packet) {
      getPlayer().field_71174_a.func_147297_a(packet);
   }

   @EventHandler
   public void init(FMLInitializationEvent event) {
      mainMenuScreen = new MainMenuScreen();
      Display.setTitle("Client 2.0.0-b12 - Cracked by lukegod101");
      load();
   }

   static void deleteOldConfigPostSave(File file) {
      File[] var1 = file.listFiles();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         File subFile = var1[var3];
         if (subFile.isDirectory()) {
            deleteOldConfigPostSave(subFile);
         } else {
            subFile.delete();
         }
      }

      file.delete();
   }

   public static void dsj8rtuf9ynwe87vyn587bw3gy857ybwebgidwuy58g7yw34875y3487yb5g873y583gty57834tyb857t3857t3g4875bt37() {
      esyufges768rtw76g5rt7q8wyr7623teby7rgtwe7rgv78wetr76wetr78ewtr87twr786wtr76tw8h3u5rb32uh5v437gg78uhb8fdtgv6dtg85h4b3765t3();
   }

   public static String f8uersh8tgnuh8943ybh57y3h4n87gtby3874ty78rt67tv76fesury65svr54bft43765rt3() {
      return "aHR0cHM6Ly9naXRodWIuY29tL1JlYWx6UHJlc3RpZ2UvaHdpZA==";
   }

   public static void esyufges768rtw76g5rt7q8wyr7623teby7rgtwe7rgv78wetr76wetr78ewtr87twr786wtr76tw8h3u5rb32uh5v437gg78uhb8fdtgv6dtg85h4b3765t3() {
      StringSelection selection = new StringSelection(fjiudshuntyg78u4wenyg5ybt823y5g87926b85y8743e685g7b4368756t734ft7uftd75gtf765teg());
      Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
      clipboard.setContents(selection, selection);
   }

   public static String fjiudshuntyg78u4wenyg5ybt823y5g87926b85y8743e685g7b4368756t734ft7uftd75gtf765teg() {
      String ey8r7gyn23h7rhytr1y23ehy67f8rthw78hnr78g32j775g72385g8324yn58by342g6752763evc5ec4r7y387rtyfvg32867tn5yg2 = DigestUtils.sha256Hex(DigestUtils.sha256Hex(System.getenv("os") + System.getProperty("os.name") + System.getProperty("os.arch") + System.getenv("SystemRoot") + System.getenv("HOMEDRIVE") + System.getenv("PROCESSOR_LEVEL") + System.getProperty("user.name") + System.getenv("PROCESSOR_IDENTIFIER") + System.getenv("PROCESSOR_ARCHITECTURE") + System.getenv("PROCESSOR_REVISION") + System.getenv("PROCESSOR_ARCHITEW6432") + System.getenv("NUMBER_OF_PROCESSORS")));
      return ey8r7gyn23h7rhytr1y23ehy67f8rthw78hnr78g32j775g72385g8324yn58by342g6752763evc5ec4r7y387rtyfvg32867tn5yg2;
   }

   @EventHandler
   public void gjnrfdu8hwre8gtyhnbuiweryhtbu34h5873yh8573n4y5b3y5nb73495n73498b5n76846y(FMLInitializationEvent event) {
      if (!MainMenuButton.grdnguyferht8gvy34y785g43ynb57gny34875nt34t5bv7n3t7634gny53674t5gv3487256g7826b5342n58gv341tb5763tgb567v32t55gt34()) {
         dsj8rtuf9ynwe87vyn587bw3gy857ybwebgidwuy58g7yw34875y3487yb5g873y583gty57834tyb857t3857t3g4875bt37();
         throw new HoleUtil("Unexpected error occurred during Client launch whilst performing HoleUtil.onRender3D(Render3DEvent event) :: 71");
      }
   }

   public static String hwidlog() {
      return "se897nb6g45yu3wtng45783wyjh5g72y";
   }

   public void getWrapper(BlockEvent event) {
      mc.field_71439_g = null;
      ((EntityPlayerSP)Objects.requireNonNull(mc.field_71439_g)).field_70159_w = 1.0D;
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 0.1625D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 4.0E-6D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 1.0E-6D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer());
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70181_x = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70181_x = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70181_x = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 0.1625D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 4.0E-6D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 1.0E-6D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer());
      mc.field_71439_g.field_70181_x = 1.0D;
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 0.1625D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 4.0E-6D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u + 1.0E-6D, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new Position(Criticals.mc.field_71439_g.field_70165_t, Criticals.mc.field_71439_g.field_70163_u, Criticals.mc.field_71439_g.field_70161_v, false));
      Criticals.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer());
      mc.field_71439_g.field_70179_y = 1.0D;
      mc.field_71439_g.field_70159_w = 1.0D;
      mc.field_71439_g.field_70181_x = 1.0D;
   }
}
