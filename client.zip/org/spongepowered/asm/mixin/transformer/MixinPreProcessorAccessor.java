package org.spongepowered.asm.mixin.transformer;

class MixinPreProcessorAccessor extends MixinPreProcessorInterface {
   public MixinPreProcessorAccessor(MixinInfo mixin, MixinInfo.MixinClassNode classNode) {
      super(mixin, classNode);
   }
}
