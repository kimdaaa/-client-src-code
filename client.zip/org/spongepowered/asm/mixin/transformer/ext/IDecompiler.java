package org.spongepowered.asm.mixin.transformer.ext;

import java.io.File;

public interface IDecompiler {
   void decompile(File var1);
}
