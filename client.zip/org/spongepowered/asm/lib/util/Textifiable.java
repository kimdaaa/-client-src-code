package org.spongepowered.asm.lib.util;

import java.util.Map;

public interface Textifiable {
   void textify(StringBuffer var1, Map var2);
}
