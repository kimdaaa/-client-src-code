package org.spongepowered.asm.util;

public interface ITokenProvider {
   Integer getToken(String var1);
}
